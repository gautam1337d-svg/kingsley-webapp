import { useState, useEffect, useCallback } from "react";
import type { University, Program, Article, SuccessStory } from "@/types";

// Cache for data
let universitiesCache: University[] | null = null;
let programsCache: Program[] | null = null;

export function useUniversities() {
  const [universities, setUniversities] = useState<University[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchUniversities() {
      if (universitiesCache) {
        setUniversities(universitiesCache);
        setLoading(false);
        return;
      }

      try {
        const response = await fetch("/data/universities.json");
        if (!response.ok) throw new Error("Failed to fetch universities");
        const data = await response.json();
        universitiesCache = data;
        setUniversities(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    }

    fetchUniversities();
  }, []);

  return { universities, loading, error };
}

export function usePrograms() {
  const [programs, setPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchPrograms() {
      if (programsCache) {
        setPrograms(programsCache);
        setLoading(false);
        return;
      }

      try {
        const response = await fetch("/data/programs.json");
        if (!response.ok) throw new Error("Failed to fetch programs");
        const data = await response.json();
        programsCache = data;
        setPrograms(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    }

    fetchPrograms();
  }, []);

  return { programs, loading, error };
}

export function useUniversityById(id: string) {
  const { universities, loading, error } = useUniversities();
  const university = universities.find((u) => u.id === id);
  return { university, loading, error };
}

export function useProgramsByUniversity(universityId: string) {
  const { programs, loading, error } = usePrograms();
  const universityPrograms = programs.filter(
    (p) => p.universityId === universityId
  );
  return { programs: universityPrograms, loading, error };
}

export function useFilteredPrograms(filters: {
  country?: string;
  studyLevel?: string;
  courseArea?: string;
  searchQuery?: string;
}) {
  const { programs, loading, error } = usePrograms();

  const filteredPrograms = programs.filter((program) => {
    if (filters.country && program.country !== filters.country) return false;
    if (filters.studyLevel && program.studyLevel !== filters.studyLevel)
      return false;
    if (filters.courseArea && program.courseArea !== filters.courseArea)
      return false;
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchesName = program.programName.toLowerCase().includes(query);
      const matchesUni = program.universityName.toLowerCase().includes(query);
      const matchesArea = program.courseArea.toLowerCase().includes(query);
      if (!matchesName && !matchesUni && !matchesArea) return false;
    }
    return true;
  });

  return { programs: filteredPrograms, loading, error };
}

export function useCountries() {
  const { universities, loading, error } = useUniversities();

  const countries = universities.reduce((acc, uni) => {
    if (!acc.find((c) => c.slug === uni.country)) {
      acc.push({
        slug: uni.country,
        name: uni.countryDisplay,
        universityCount: universities.filter((u) => u.country === uni.country)
          .length,
      });
    }
    return acc;
  }, [] as { slug: string; name: string; universityCount: number }[]);

  return { countries, loading, error };
}

export function useCourseAreas() {
  const { programs, loading, error } = usePrograms();

  const courseAreas = programs.reduce((acc, program) => {
    if (program.courseArea && !acc.includes(program.courseArea)) {
      acc.push(program.courseArea);
    }
    return acc;
  }, [] as string[]);

  return { courseAreas: courseAreas.sort(), loading, error };
}

// Articles from localStorage
export function useArticles() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("kingsley_articles");
    if (stored) {
      setArticles(JSON.parse(stored));
    }
    setLoading(false);
  }, []);

  const saveArticle = useCallback((article: Article) => {
    setArticles((prev) => {
      const exists = prev.find((a) => a.id === article.id);
      let updated;
      if (exists) {
        updated = prev.map((a) => (a.id === article.id ? article : a));
      } else {
        updated = [...prev, article];
      }
      localStorage.setItem("kingsley_articles", JSON.stringify(updated));
      return updated;
    });
  }, []);

  const deleteArticle = useCallback((id: string) => {
    setArticles((prev) => {
      const updated = prev.filter((a) => a.id !== id);
      localStorage.setItem("kingsley_articles", JSON.stringify(updated));
      return updated;
    });
  }, []);

  return { articles, loading, saveArticle, deleteArticle };
}

export function useArticleBySlug(slug: string) {
  const { articles, loading } = useArticles();
  const article = articles.find((a) => a.slug === slug);
  return { article, loading };
}

// Success stories from localStorage
export function useSuccessStories() {
  const [stories, setStories] = useState<SuccessStory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("kingsley_stories");
    if (stored) {
      setStories(JSON.parse(stored));
    }
    setLoading(false);
  }, []);

  const saveStory = useCallback((story: SuccessStory) => {
    setStories((prev) => {
      const exists = prev.find((s) => s.id === story.id);
      let updated;
      if (exists) {
        updated = prev.map((s) => (s.id === story.id ? story : s));
      } else {
        updated = [...prev, story];
      }
      localStorage.setItem("kingsley_stories", JSON.stringify(updated));
      return updated;
    });
  }, []);

  return { stories, loading, saveStory };
}

export function useSuccessStoryById(id: string) {
  const { stories, loading } = useSuccessStories();
  const story = stories.find((s) => s.id === id);
  return { story, loading };
}

// Intersection Observer for animations
export function useInView(options?: IntersectionObserverInit) {
  const [isInView, setIsInView] = useState(false);
  const [ref, setRef] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (!ref) return;

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true);
        observer.disconnect();
      }
    }, options);

    observer.observe(ref);

    return () => observer.disconnect();
  }, [ref, options]);

  return { ref: setRef, isInView };
}

// Animated counter hook
export function useAnimatedCounter(
  end: number,
  duration: number = 2000,
  start: number = 0
) {
  const [count, setCount] = useState(start);
  const [isAnimating, setIsAnimating] = useState(false);

  const startAnimation = useCallback(() => {
    if (isAnimating) return;
    setIsAnimating(true);

    const startTime = Date.now();
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentCount = Math.floor(start + (end - start) * easeOutQuart);

      setCount(currentCount);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [end, duration, start, isAnimating]);

  return { count, startAnimation };
}
