// Data normalization utilities to standardize ENUM values across the application

// Country slug mapping - standardizes country identifiers
export const countrySlugMap: Record<string, string> = {
  uk: "uk",
  unitedkingdom: "uk",
  "united kingdom": "uk",
  britain: "uk",
  australia: "australia",
  germany: "germany",
  deutschland: "germany",
  france: "france",
  ireland: "ireland",
  netherlands: "netherlands",
  holland: "netherlands",
  italy: "italy",
  italia: "italy",
  spain: "spain",
  españa: "spain",
  sweden: "sweden",
  newzealand: "newzealand",
  "new zealand": "newzealand",
  austria: "austria",
  österreich: "austria",
  belgium: "belgium",
  belgië: "belgium",
  finland: "finland",
  norway: "norway",
  portugal: "portugal",
};

// Study level normalization
export const normalizeStudyLevel = (level: string): string => {
  if (!level) return "";
  const normalized = level.toUpperCase().trim();
  if (normalized.includes("UG") || normalized.includes("UNDERGRADUATE") || normalized.includes("BACHELOR")) {
    return "UG";
  }
  if (normalized.includes("PG") || normalized.includes("POSTGRADUATE") || normalized.includes("MASTER")) {
    return "PG";
  }
  if (normalized.includes("PHD") || normalized.includes("DOCTORATE")) {
    return "PhD";
  }
  if (normalized.includes("DIPLOMA")) {
    return "Diploma";
  }
  return normalized;
};

// Course area normalization - extracts base area from prefixed values like "UG_Business"
export const normalizeCourseArea = (area: string): string => {
  if (!area) return "";
  const normalized = area.toString().trim();
  
  // Remove common prefixes
  const withoutPrefix = normalized
    .replace(/^(UG_|PG_|PhD_|DIPLOMA_)/i, "")
    .replace(/_/g, " ");
  
  // Map to standardized areas
  const areaMap: Record<string, string> = {
    "business": "Business",
    "commerce": "Business",
    "management": "Business",
    "mba": "Business",
    "engineering": "Engineering",
    "engg": "Engineering",
    "computerscience": "IT",
    "computer science": "IT",
    "it": "IT",
    "information technology": "IT",
    "data science": "IT",
    "arts": "Arts",
    "humanities": "Arts",
    "science": "Science",
    "medicine": "Health",
    "healthcare": "Health",
    "health": "Health",
    "nursing": "Health",
    "law": "Law",
    "legal": "Law",
    "hospitality": "Hospitality",
    "tourism": "Hospitality",
    "hotel": "Hospitality",
    "design": "Design",
    "architecture": "Design",
  };
  
  const lowerArea = withoutPrefix.toLowerCase();
  return areaMap[lowerArea] || withoutPrefix;
};

// Normalize country slug
export const normalizeCountry = (country: string): string => {
  if (!country) return "";
  const normalized = country.toLowerCase().trim();
  return countrySlugMap[normalized] || normalized;
};

// Standardized ENUM values for filters
export const StudyLevelEnum = {
  UG: "UG",
  PG: "PG",
  PhD: "PhD",
  Diploma: "Diploma",
} as const;

export const CourseAreaEnum = {
  Engineering: "Engineering",
  Business: "Business",
  Science: "Science",
  Arts: "Arts",
  IT: "IT",
  Health: "Health",
  Law: "Law",
  Hospitality: "Hospitality",
  Design: "Design",
} as const;

export const CountryEnum = {
  UnitedKingdom: "uk",
  Ireland: "ireland",
  Germany: "germany",
  France: "france",
  Netherlands: "netherlands",
  Italy: "italy",
  Austria: "austria",
  Belgium: "belgium",
  Finland: "finland",
  Norway: "norway",
  Portugal: "portugal",
  NewZealand: "newzealand",
  Australia: "australia",
  Spain: "spain",
  Sweden: "sweden",
} as const;

// Filter options for UI
export const studyLevelOptions = [
  { value: "UG", label: "Undergraduate" },
  { value: "PG", label: "Postgraduate" },
  { value: "PhD", label: "PhD / Doctorate" },
  { value: "Diploma", label: "Diploma" },
];

export const courseAreaOptions = [
  { value: "Engineering", label: "Engineering" },
  { value: "Business", label: "Business & Management" },
  { value: "IT", label: "IT & Computer Science" },
  { value: "Science", label: "Science" },
  { value: "Arts", label: "Arts & Humanities" },
  { value: "Health", label: "Health & Medicine" },
  { value: "Law", label: "Law" },
  { value: "Hospitality", label: "Hospitality & Tourism" },
  { value: "Design", label: "Design & Architecture" },
];

export const countryOptions = [
  { value: "uk", label: "United Kingdom", flag: "🇬🇧" },
  { value: "ireland", label: "Ireland", flag: "🇮🇪" },
  { value: "germany", label: "Germany", flag: "🇩🇪" },
  { value: "france", label: "France", flag: "🇫🇷" },
  { value: "netherlands", label: "Netherlands", flag: "🇳🇱" },
  { value: "italy", label: "Italy", flag: "🇮🇹" },
  { value: "spain", label: "Spain", flag: "🇪🇸" },
  { value: "sweden", label: "Sweden", flag: "🇸🇪" },
  { value: "newzealand", label: "New Zealand", flag: "🇳🇿" },
  { value: "austria", label: "Austria", flag: "🇦🇹" },
  { value: "belgium", label: "Belgium", flag: "🇧🇪" },
  { value: "finland", label: "Finland", flag: "🇫🇮" },
  { value: "norway", label: "Norway", flag: "🇳🇴" },
  { value: "portugal", label: "Portugal", flag: "🇵🇹" },
  { value: "australia", label: "Australia", flag: "🇦🇺" },
];

// Check if program matches course area filter (handles partial matches)
export const matchesCourseArea = (programArea: string, filterArea: string): boolean => {
  if (!filterArea) return true;
  if (!programArea) return false;
  
  const normalizedProgram = normalizeCourseArea(programArea).toLowerCase();
  const normalizedFilter = filterArea.toLowerCase();
  
  // Direct match
  if (normalizedProgram === normalizedFilter) return true;
  
  // Partial match (e.g., "Business" matches "Business & Management")
  if (normalizedProgram.includes(normalizedFilter)) return true;
  if (normalizedFilter.includes(normalizedProgram)) return true;
  
  // Check original value with prefix removed
  const originalWithoutPrefix = programArea.replace(/^(UG_|PG_|PhD_)/i, "").toLowerCase();
  if (originalWithoutPrefix.includes(normalizedFilter)) return true;
  
  return false;
};

// Check if program matches study level filter
export const matchesStudyLevel = (programLevel: string, filterLevel: string): boolean => {
  if (!filterLevel) return true;
  if (!programLevel) return false;
  
  const normalizedProgram = normalizeStudyLevel(programLevel);
  const normalizedFilter = normalizeStudyLevel(filterLevel);
  
  // Exact match
  if (normalizedProgram === normalizedFilter) return true;
  
  // Check if program level contains filter level (e.g., "UG + PG" contains "UG")
  if (programLevel.toUpperCase().includes(filterLevel.toUpperCase())) return true;
  
  return false;
};
