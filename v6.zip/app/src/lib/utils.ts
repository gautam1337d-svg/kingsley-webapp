import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function slugify(str: string): string {
  if (!str) return "";
  return str
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function formatCurrency(
  amount: number | string,
  currency: string
): string {
  const numAmount = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(numAmount)) return "-";

  const currencyMap: Record<string, string> = {
    GBP: "en-GB",
    USD: "en-US",
    EUR: "en-EU",
    AUD: "en-AU",
    CAD: "en-CA",
    NZD: "en-NZ",
    INR: "en-IN",
  };

  return new Intl.NumberFormat(currencyMap[currency] || "en-US", {
    style: "currency",
    currency: currency,
    maximumFractionDigits: 0,
  }).format(numAmount);
}

export function getCountryFlag(country: string): string {
  const flagMap: Record<string, string> = {
    australia: "🇦🇺",
    austria: "🇦🇹",
    belgium: "🇧🇪",
    germany: "🇩🇪",
    finland: "🇫🇮",
    france: "🇫🇷",
    hungary: "🇭🇺",
    ireland: "🇮🇪",
    italy: "🇮🇹",
    netherlands: "🇳🇱",
    norway: "🇳🇴",
    newzealand: "🇳🇿",
    portugal: "🇵🇹",
    spain: "🇪🇸",
    sweden: "🇸🇪",
    uk: "🇬🇧",
  };
  return flagMap[slugify(country)] || "🌍";
}

export function getCountryName(slug: string): string {
  const nameMap: Record<string, string> = {
    australia: "Australia",
    austria: "Austria",
    belgium: "Belgium",
    germany: "Germany",
    finland: "Finland",
    france: "France",
    hungary: "Hungary",
    ireland: "Ireland",
    italy: "Italy",
    netherlands: "Netherlands",
    norway: "Norway",
    newzealand: "New Zealand",
    portugal: "Portugal",
    spain: "Spain",
    sweden: "Sweden",
    uk: "United Kingdom",
  };
  return nameMap[slug] || slug;
}

export function getCountrySlug(name: string): string {
  const slugMap: Record<string, string> = {
    australia: "australia",
    austria: "austria",
    belgium: "belgium",
    germany: "germany",
    deutschland: "germany",
    finland: "finland",
    france: "france",
    hungary: "hungary",
    ireland: "ireland",
    italy: "italy",
    netherlands: "netherlands",
    norway: "norway",
    "new zealand": "newzealand",
    newzealand: "newzealand",
    portugal: "portugal",
    spain: "spain",
    sweden: "sweden",
    uk: "uk",
    "united kingdom": "uk",
    britain: "uk",
  };
  return slugMap[name.toLowerCase()] || slugify(name);
}

// LocalStorage helpers for blog articles
export function getStoredArticles(): any[] {
  if (typeof window === "undefined") return [];
  const stored = localStorage.getItem("kingsley_articles");
  return stored ? JSON.parse(stored) : [];
}

export function setStoredArticles(articles: any[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem("kingsley_articles", JSON.stringify(articles));
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}

export function formatDate(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength).trim() + "...";
}

export function debounce<T extends (...args: any[]) => void>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export function scrollToElement(elementId: string): void {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

export function getMetaDescription(text: string, maxLength: number = 160): string {
  return truncateText(text.replace(/<[^>]*>/g, ""), maxLength);
}
