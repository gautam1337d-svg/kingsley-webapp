import { Link } from "react-router-dom";
import { ArrowRight, GraduationCap } from "lucide-react";
import { getCountryFlag } from "@/lib/utils";
import { getAllCountries } from "@/data/countryData";

const featuredCountries = [
  { slug: "uk", name: "United Kingdom", description: "World-class education with historic universities" },
  { slug: "australia", name: "Australia", description: "Excellent quality of life and research opportunities" },
  { slug: "germany", name: "Germany", description: "Tuition-free education and strong industry links" },
  { slug: "france", name: "France", description: "Prestigious institutions and cultural richness" },
  { slug: "ireland", name: "Ireland", description: "Friendly environment and post-study work options" },
  { slug: "netherlands", name: "Netherlands", description: "Innovative teaching and English-taught programs" },
];

export function DestinationsGrid() {
  const allCountries = getAllCountries();

  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div className="max-w-2xl">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Study Destinations
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3 mb-4">
              Popular Countries for Indian Students
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Explore top study destinations with excellent education systems,
              post-study work opportunities, and vibrant student communities.
            </p>
          </div>
          <Link
            to="/find-your-course"
            className="inline-flex items-center gap-2 text-[#C6A052] hover:text-[#E5C27A] font-medium mt-4 md:mt-0"
          >
            View All Countries
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredCountries.map((country) => {
            const countryData = allCountries.find((c) => c.slug === country.slug);
            const uniCount = countryData ? 20 : 0;

            return (
              <Link
                key={country.slug}
                to={`/country/${country.slug}`}
                className="group relative bg-[#F5F3EE] rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300"
              >
                <div className="p-8">
                  <div className="flex items-start justify-between mb-6">
                    <span className="text-5xl">{getCountryFlag(country.slug)}</span>
                    <div className="flex items-center gap-2 text-[#0B1F3B] bg-white px-3 py-1 rounded-full text-sm">
                      <GraduationCap className="w-4 h-4" />
                      <span>{uniCount}+ Universities</span>
                    </div>
                  </div>

                  <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B] mb-2 group-hover:text-[#C6A052] transition-colors">
                    {country.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {country.description}
                  </p>

                  <div className="flex items-center gap-2 text-[#C6A052] font-medium text-sm">
                    <span>Explore Programs</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>

                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#C6A052] to-[#E5C27A] transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
