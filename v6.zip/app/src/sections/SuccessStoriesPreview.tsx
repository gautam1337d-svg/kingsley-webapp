import { useRef, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Quote, Star } from "lucide-react";

const stories = [
  {
    id: "1",
    name: "Priya Sharma",
    photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face",
    university: "University of Manchester",
    country: "United Kingdom",
    course: "MSc Data Science",
    year: "2023",
    quote:
      "Kingsley International made my dream of studying in the UK a reality. Their guidance throughout the application and visa process was invaluable.",
    rating: 5,
  },
  {
    id: "2",
    name: "Rahul Patel",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    university: "Technical University of Munich",
    country: "Germany",
    course: "MSc Mechanical Engineering",
    year: "2023",
    quote:
      "The team helped me secure admission to my dream university in Germany with a scholarship. I couldn't have done it without their support.",
    rating: 5,
  },
  {
    id: "3",
    name: "Ananya Reddy",
    photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    university: "University of Melbourne",
    country: "Australia",
    course: "MBA",
    year: "2022",
    quote:
      "From shortlisting universities to visa approval, Kingsley was there at every step. Their expertise made the entire process smooth and stress-free.",
    rating: 5,
  },
];

export function SuccessStoriesPreview() {
  const ref = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="section-padding bg-[#F5F3EE]">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div className="max-w-2xl">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Success Stories
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3 mb-4">
              What Our Students Say
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Hear from students who achieved their dream of studying abroad
              with our guidance and support.
            </p>
          </div>
          <Link
            to="/success-stories"
            className="inline-flex items-center gap-2 text-[#C6A052] hover:text-[#E5C27A] font-medium mt-4 md:mt-0"
          >
            View All Stories
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stories.map((story, index) => (
            <div
              key={story.id}
              className={`bg-white rounded-xl p-8 shadow-lg relative transition-all duration-500 ${
                isInView
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 0.15}s` }}
            >
              <Quote className="absolute top-6 right-6 w-10 h-10 text-[#C6A052]/20" />

              <div className="flex items-center gap-4 mb-6">
                <img
                  src={story.photo}
                  alt={story.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold text-[#0B1F3B]">{story.name}</h3>
                  <p className="text-sm text-gray-500">{story.course}</p>
                  <p className="text-sm text-[#C6A052]">{story.university}</p>
                </div>
              </div>

              <div className="flex gap-1 mb-4">
                {[...Array(story.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-[#C6A052] text-[#C6A052]"
                  />
                ))}
              </div>

              <p className="text-gray-600 text-sm leading-relaxed italic">
                "{story.quote}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
