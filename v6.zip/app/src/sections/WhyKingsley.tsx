import { useRef, useState, useEffect } from "react";
import {
  Compass,
  FileCheck,
  Wallet,
  Plane,
  Users,
  Headphones,
} from "lucide-react";

const features = [
  {
    icon: Compass,
    title: "Personalized Counselling",
    description:
      "One-on-one sessions to understand your goals and create a customized study abroad roadmap tailored to your profile.",
  },
  {
    icon: FileCheck,
    title: "End-to-End Application Support",
    description:
      "From university shortlisting to document preparation and submission, we handle every step of your application process.",
  },
  {
    icon: Wallet,
    title: "Scholarship & Funding Guidance",
    description:
      "Expert advice on scholarships, education loans, and financial planning to make your dream affordable.",
  },
  {
    icon: Plane,
    title: "Visa & Pre-Departure Assistance",
    description:
      "Comprehensive visa guidance with mock interviews and pre-departure briefings for a smooth transition.",
  },
  {
    icon: Users,
    title: "University Network",
    description:
      "Direct partnerships with 400+ universities across 16 countries, giving you access to exclusive opportunities.",
  },
  {
    icon: Headphones,
    title: "Lifetime Support",
    description:
      "Our relationship doesn't end with admission. We provide ongoing support throughout your academic journey.",
  },
];

export function WhyKingsley() {
  const ref = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="section-padding bg-[#F5F3EE]">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
            Why Choose Us
          </span>
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3 mb-4">
            Why Students Trust Kingsley International
          </h2>
          <p className="text-gray-600 leading-relaxed">
            With over a decade of experience, we've helped thousands of Indian
            students achieve their dream of studying abroad. Here's what sets us
            apart.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-500 ${
                isInView
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 bg-[#0B1F3B]/5 rounded-xl flex items-center justify-center mb-6">
                <feature.icon className="w-7 h-7 text-[#C6A052]" />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B] mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
