import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    slug: "career-counselling",
    title: "Career Counselling",
    description:
      "Discover your ideal career path with personalized guidance from our experienced counsellors.",
    icon: "🎯",
  },
  {
    slug: "course-selection",
    title: "Course Selection",
    description:
      "Find the perfect program that aligns with your academic background and career aspirations.",
    icon: "📚",
  },
  {
    slug: "application-assistance",
    title: "Application Assistance",
    description:
      "Expert help with university applications, SOPs, LORs, and all required documentation.",
    icon: "📝",
  },
  {
    slug: "scholarship-guidance",
    title: "Scholarship Guidance",
    description:
      "Maximize your chances of securing scholarships and financial aid for your studies.",
    icon: "💰",
  },
  {
    slug: "visa-assistance",
    title: "Visa Assistance",
    description:
      "Comprehensive visa support including documentation, application, and interview preparation.",
    icon: "✈️",
  },
  {
    slug: "education-loans",
    title: "Education Loans",
    description:
      "Guidance on education loan options and assistance with the application process.",
    icon: "🏦",
  },
];

export function ServicesOverview() {
  return (
    <section className="section-padding bg-[#0B1F3B]">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
            Our Services
          </span>
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-white mt-3 mb-4">
            End-to-End Study Abroad Support
          </h2>
          <p className="text-gray-300 leading-relaxed">
            From the moment you think about studying abroad to the day you land
            at your destination, we're with you every step of the way.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Link
              key={service.slug}
              to={`/services/${service.slug}`}
              className="group bg-[#1a3a5f]/50 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-[#C6A052]/50 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="font-playfair text-lg font-semibold text-white mb-2 group-hover:text-[#C6A052] transition-colors">
                {service.title}
              </h3>
              <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                {service.description}
              </p>
              <div className="flex items-center gap-2 text-[#C6A052] text-sm font-medium">
                <span>Learn More</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/contact">
            <Button 
              size="lg"
              className="gap-2 bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold"
            >
              Get Started
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
