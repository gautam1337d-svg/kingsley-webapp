import { Link } from "react-router-dom";
import { Phone, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CTABanner() {
  return (
    <section className="py-20 bg-gradient-to-r from-[#0B1F3B] via-[#1a3a5f] to-[#0B1F3B] relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#C6A052]/10 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#C6A052]/5 rounded-full blur-3xl transform -translate-x-1/2 translate-y-1/2" />

      <div className="container-custom relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-playfair text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Start Your
            <span className="text-[#C6A052] block"> Study Abroad Journey?</span>
          </h2>

          <p className="text-lg text-gray-300 mb-10 max-w-2xl mx-auto">
            Book a free consultation with our expert counsellors and take the
            first step towards your dream education. No obligations, just
            guidance.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button 
                size="lg"
                className="gap-2 bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6"
              >
                <Calendar className="w-5 h-5" />
                Book Free Consultation
              </Button>
            </Link>

            <a
              href="tel:+919876543210"
              className="inline-flex items-center justify-center gap-2 bg-white/10 text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/20 transition-colors backdrop-blur-sm"
            >
              <Phone className="w-5 h-5" />
              Call Us Now
            </a>
          </div>

          <div className="mt-10 flex flex-wrap justify-center gap-8 text-gray-400 text-sm">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-[#C6A052] rounded-full" />
              Free Initial Consultation
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-[#C6A052] rounded-full" />
              Expert Counsellors
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-[#C6A052] rounded-full" />
              No Hidden Charges
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
