import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, MapPin, BookOpen, GraduationCap, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { countryOptions, studyLevelOptions, courseAreaOptions } from "@/lib/normalizeData";

export function Hero() {
  const navigate = useNavigate();
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedLevel, setSelectedLevel] = useState("");
  const [selectedArea, setSelectedArea] = useState("");

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (selectedCountry) params.append("country", selectedCountry);
    if (selectedLevel) params.append("level", selectedLevel);
    if (selectedArea) params.append("area", selectedArea);
    navigate(`/find-your-course?${params.toString()}`);
  };

  const handleViewAllPrograms = () => {
    navigate("/find-your-course");
  };

  return (
    <section className="relative min-h-[90vh] flex items-center bg-gradient-to-br from-[#0B1F3B] via-[#0B1F3B] to-[#1a3a5f] overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-[#C6A052]/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-[#C6A052]/5 rounded-full blur-3xl" />

      <div className="container-custom relative z-10 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="text-white space-y-6">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm">
              <span className="w-2 h-2 bg-[#C6A052] rounded-full animate-pulse" />
              Trusted by 10,000+ students
            </div>

            <h1 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Your Gateway to
              <span className="text-[#C6A052] block">Global Education</span>
            </h1>

            <p className="text-lg md:text-xl text-gray-300 max-w-xl leading-relaxed">
              Expert guidance for Indian students aspiring to study at top
              universities across the UK, Europe, Australia, and beyond.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <Link to="/find-your-course">
                <Button 
                  size="lg" 
                  className="gap-2 bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-6 py-3"
                >
                  Explore Courses
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link to="/contact">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-2 border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B] font-semibold px-6 py-3 bg-transparent"
                >
                  Book Free Consultation
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-8 border-t border-white/20">
              <div>
                <p className="text-3xl font-bold text-[#C6A052]">16+</p>
                <p className="text-sm text-gray-400">Countries</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#C6A052]">400+</p>
                <p className="text-sm text-gray-400">Universities</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#C6A052]">3,700+</p>
                <p className="text-sm text-gray-400">Programs</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#C6A052]">98%</p>
                <p className="text-sm text-gray-400">Success Rate</p>
              </div>
            </div>
          </div>

          {/* Right content - Search Form */}
          <div className="bg-white rounded-2xl shadow-2xl p-6 md:p-8">
            <div className="text-center mb-6">
              <h2 className="font-playfair text-2xl font-bold text-[#0B1F3B] mb-2">
                Find Your Perfect Course
              </h2>
              <p className="text-gray-600">
                Search from 3,700+ programs across 400+ universities
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <MapPin className="w-4 h-4 inline mr-1" />
                  Study Destination
                </label>
                <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {countryOptions.map((country) => (
                      <SelectItem key={country.value} value={country.value}>
                        <span className="mr-2">{country.flag}</span>
                        {country.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <GraduationCap className="w-4 h-4 inline mr-1" />
                  Study Level
                </label>
                <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    {studyLevelOptions.map((level) => (
                      <SelectItem key={level.value} value={level.value}>
                        {level.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <BookOpen className="w-4 h-4 inline mr-1" />
                  Course Area
                </label>
                <Select value={selectedArea} onValueChange={setSelectedArea}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select area of study" />
                  </SelectTrigger>
                  <SelectContent>
                    {courseAreaOptions.map((area) => (
                      <SelectItem key={area.value} value={area.value}>
                        {area.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleSearch}
                className="w-full py-6 text-lg gap-2 mt-2 bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold"
              >
                <Search className="w-5 h-5" />
                Search Programs
              </Button>
            </div>

            <p className="text-center text-sm text-gray-500 mt-4">
              Or{" "}
              <button
                onClick={handleViewAllPrograms}
                className="text-[#C6A052] hover:underline font-medium"
              >
                browse all programs
              </button>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
