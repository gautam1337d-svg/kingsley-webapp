import { useEffect } from "react";

interface SEOProps {
  title: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  ogType?: string;
  canonicalUrl?: string;
  schema?: object;
}

export function SEO({
  title,
  description = "Expert guidance for Indian students aspiring to study at top universities worldwide. 16+ countries, 400+ universities, 3,700+ programs.",
  keywords = "study abroad, overseas education, university admission, student visa, scholarships",
  ogImage = "/og-image.jpg",
  ogType = "website",
  canonicalUrl,
  schema,
}: SEOProps) {
  useEffect(() => {
    // Update title
    document.title = title;

    // Update meta tags
    const metaTags = {
      description,
      keywords,
      "og:title": title,
      "og:description": description,
      "og:type": ogType,
      "og:image": ogImage,
      "twitter:card": "summary_large_image",
      "twitter:title": title,
      "twitter:description": description,
      "twitter:image": ogImage,
    };

    Object.entries(metaTags).forEach(([name, content]) => {
      let meta = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
      if (!meta) {
        meta = document.createElement("meta");
        if (name.startsWith("og:") || name.startsWith("twitter:")) {
          meta.setAttribute("property", name);
        } else {
          meta.setAttribute("name", name);
        }
        document.head.appendChild(meta);
      }
      meta.setAttribute("content", content);
    });

    // Update canonical URL
    if (canonicalUrl) {
      let link = document.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement("link");
        link.setAttribute("rel", "canonical");
        document.head.appendChild(link);
      }
      link.setAttribute("href", canonicalUrl);
    }

    // Add JSON-LD schema
    if (schema) {
      const existingScript = document.querySelector('script[type="application/ld+json"]');
      if (existingScript) {
        existingScript.remove();
      }
      const script = document.createElement("script");
      script.type = "application/ld+json";
      script.text = JSON.stringify(schema);
      document.head.appendChild(script);
    }

    return () => {
      // Cleanup schema on unmount
      if (schema) {
        const script = document.querySelector('script[type="application/ld+json"]');
        if (script) {
          script.remove();
        }
      }
    };
  }, [title, description, keywords, ogImage, ogType, canonicalUrl, schema]);

  return null;
}

// Predefined schemas
export const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  name: "Kingsley International",
  description: "Study abroad consultancy helping Indian students achieve their dream of studying at top universities worldwide",
  url: "https://kingsley.edu",
  telephone: "+91-98765-43210",
  address: {
    "@type": "PostalAddress",
    streetAddress: "123 Education Street, Koramangala",
    addressLocality: "Bangalore",
    addressRegion: "Karnataka",
    postalCode: "560034",
    addressCountry: "IN",
  },
  sameAs: [
    "https://facebook.com/kingsleyinternational",
    "https://instagram.com/kingsleyinternational",
    "https://linkedin.com/company/kingsleyinternational",
  ],
};

export const createCourseSchema = (course: {
  name: string;
  description: string;
  provider: string;
  url: string;
}) => ({
  "@context": "https://schema.org",
  "@type": "Course",
  name: course.name,
  description: course.description,
  provider: {
    "@type": "Organization",
    name: course.provider,
  },
  url: course.url,
});

export const createFAQSchema = (faqs: { question: string; answer: string }[]) => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
});
