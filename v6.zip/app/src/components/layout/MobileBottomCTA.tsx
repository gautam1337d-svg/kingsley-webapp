import { Phone, MessageSquare } from "lucide-react";

export function MobileBottomCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t shadow-lg md:hidden">
      <div className="flex">
        <a
          href="tel:+919876543210"
          className="flex-1 flex items-center justify-center gap-2 bg-[#0B1F3B] text-white py-3 font-medium"
        >
          <Phone className="w-5 h-5" />
          <span>Call Now</span>
        </a>
        <a
          href="https://wa.me/919876543210"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-2 bg-[#C6A052] text-[#0B1F3B] py-3 font-medium"
        >
          <MessageSquare className="w-5 h-5" />
          <span>WhatsApp</span>
        </a>
      </div>
    </div>
  );
}
