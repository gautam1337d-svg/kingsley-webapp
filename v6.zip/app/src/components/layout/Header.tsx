import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown, Phone, GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";

const countries = [
  { slug: "uk", name: "United Kingdom", flag: "🇬🇧" },
  { slug: "australia", name: "Australia", flag: "🇦🇺" },
  { slug: "germany", name: "Germany", flag: "🇩🇪" },
  { slug: "france", name: "France", flag: "🇫🇷" },
  { slug: "ireland", name: "Ireland", flag: "🇮🇪" },
  { slug: "netherlands", name: "Netherlands", flag: "🇳🇱" },
  { slug: "italy", name: "Italy", flag: "🇮🇹" },
  { slug: "spain", name: "Spain", flag: "🇪🇸" },
  { slug: "sweden", name: "Sweden", flag: "🇸🇪" },
  { slug: "newzealand", name: "New Zealand", flag: "🇳🇿" },
  { slug: "austria", name: "Austria", flag: "🇦🇹" },
  { slug: "belgium", name: "Belgium", flag: "🇧🇪" },
  { slug: "finland", name: "Finland", flag: "🇫🇮" },
  { slug: "hungary", name: "Hungary", flag: "🇭🇺" },
  { slug: "norway", name: "Norway", flag: "🇳🇴" },
  { slug: "portugal", name: "Portugal", flag: "🇵🇹" },
];

const services = [
  { slug: "career-counselling", name: "Career Counselling" },
  { slug: "course-selection", name: "Course Selection" },
  { slug: "application-assistance", name: "Application Assistance" },
  { slug: "scholarship-guidance", name: "Scholarship Guidance" },
  { slug: "visa-assistance", name: "Visa Assistance" },
  { slug: "education-loans", name: "Education Loans" },
  { slug: "accommodation", name: "Accommodation Support" },
  { slug: "travel-forex", name: "Travel & Forex" },
  { slug: "pre-departure", name: "Pre-Departure Briefing" },
];

// Gold color constants
const GOLD_PRIMARY = "#C6A052";
const GOLD_HOVER = "#E5C27A";
const NAVY_DARK = "#0B1F3B";

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  const isActive = (path: string) => location.pathname === path;

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled
          ? "bg-white/95 backdrop-blur-md shadow-md"
          : "bg-transparent"
      )}
    >
      {/* Top bar */}
      <div
        className={cn(
          "py-2 transition-all duration-300",
          isScrolled ? "hidden" : "block bg-[#0B1F3B]"
        )}
      >
        <div className="container-custom flex justify-between items-center text-sm text-white">
          <div className="flex items-center gap-4">
            <a
              href="tel:+919876543210"
              className="flex items-center gap-1 hover:text-[#C6A052] transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>+91 98765 43210</span>
            </a>
          </div>
          <div className="hidden sm:flex items-center gap-4">
            <Link to="/success-stories" className="hover:text-[#C6A052] transition-colors">
              Success Stories
            </Link>
            <Link to="/blog" className="hover:text-[#C6A052] transition-colors">
              Blog
            </Link>
            <Link to="/contact" className="hover:text-[#C6A052] transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <nav
        className={cn(
          "transition-all duration-300",
          isScrolled ? "py-3" : "py-4"
        )}
      >
        <div className="container-custom flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <GraduationCap 
              className="w-8 h-8" 
              style={{ color: GOLD_PRIMARY }}
            />
            <div className="flex flex-col">
              <span 
                className="font-playfair text-xl font-bold leading-tight"
                style={{ color: isScrolled ? NAVY_DARK : "white" }}
              >
                Kingsley
              </span>
              <span 
                className="text-xs font-medium tracking-wider"
                style={{ color: GOLD_PRIMARY }}
              >
                INTERNATIONAL
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-6">
            <Link
              to="/"
              className={cn(
                "font-medium transition-colors hover:text-[#C6A052]",
                isScrolled ? "text-[#0B1F3B]" : "text-white",
                isActive("/") && "text-[#C6A052] font-semibold"
              )}
            >
              Home
            </Link>

            {/* Countries Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown("countries")}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                className={cn(
                  "font-medium transition-colors hover:text-[#C6A052] flex items-center gap-1",
                  isScrolled ? "text-[#0B1F3B]" : "text-white",
                  location.pathname.startsWith("/country") && "text-[#C6A052] font-semibold"
                )}
              >
                Study Destinations
                <ChevronDown className="w-4 h-4" />
              </button>
              {activeDropdown === "countries" && (
                <div className="absolute top-full left-0 pt-2">
                  <div className="bg-white rounded-lg shadow-xl border border-gray-100 py-2 grid grid-cols-2 gap-1 w-[400px] max-h-[400px] overflow-y-auto">
                    {countries.map((country) => (
                      <Link
                        key={country.slug}
                        to={`/country/${country.slug}`}
                        className="px-4 py-2 hover:bg-gray-50 cursor-pointer transition-colors flex items-center gap-2 text-[#0B1F3B]"
                      >
                        <span>{country.flag}</span>
                        <span className="text-sm">{country.name}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Link
              to="/find-your-course"
              className={cn(
                "font-medium transition-colors hover:text-[#C6A052]",
                isScrolled ? "text-[#0B1F3B]" : "text-white",
                isActive("/find-your-course") && "text-[#C6A052] font-semibold"
              )}
            >
              Find Your Course
            </Link>

            {/* Services Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown("services")}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                className={cn(
                  "font-medium transition-colors hover:text-[#C6A052] flex items-center gap-1",
                  isScrolled ? "text-[#0B1F3B]" : "text-white",
                  location.pathname.startsWith("/services") && "text-[#C6A052] font-semibold"
                )}
              >
                Services
                <ChevronDown className="w-4 h-4" />
              </button>
              {activeDropdown === "services" && (
                <div className="absolute top-full left-0 pt-2">
                  <div className="bg-white rounded-lg shadow-xl border border-gray-100 py-2 w-[280px]">
                    {services.map((service) => (
                      <Link
                        key={service.slug}
                        to={`/services/${service.slug}`}
                        className="block px-4 py-2 hover:bg-gray-50 cursor-pointer transition-colors text-sm text-[#0B1F3B]"
                      >
                        {service.name}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Link
              to="/visa-guidance"
              className={cn(
                "font-medium transition-colors hover:text-[#C6A052]",
                isScrolled ? "text-[#0B1F3B]" : "text-white",
                isActive("/visa-guidance") && "text-[#C6A052] font-semibold"
              )}
            >
              Visa
            </Link>

            <Link
              to="/scholarships"
              className={cn(
                "font-medium transition-colors hover:text-[#C6A052]",
                isScrolled ? "text-[#0B1F3B]" : "text-white",
                isActive("/scholarships") && "text-[#C6A052] font-semibold"
              )}
            >
              Scholarships
            </Link>

            <Link
              to="/blog"
              className={cn(
                "font-medium transition-colors hover:text-[#C6A052]",
                isScrolled ? "text-[#0B1F3B]" : "text-white",
                isActive("/blog") && "text-[#C6A052] font-semibold"
              )}
            >
              Blog
            </Link>
          </div>

          {/* CTA Button */}
          <div className="hidden lg:block">
            <Link 
              to="/contact" 
              className="text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors"
              style={{ 
                backgroundColor: GOLD_PRIMARY, 
                color: NAVY_DARK,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = GOLD_HOVER;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = GOLD_PRIMARY;
              }}
            >
              Free Consultation
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className={cn(
              "lg:hidden p-2",
              isScrolled ? "text-[#0B1F3B]" : "text-white"
            )}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white border-t shadow-lg max-h-[80vh] overflow-y-auto">
          <div className="container-custom py-4 space-y-4">
            <Link to="/" className="block py-2 text-[#0B1F3B] font-medium">
              Home
            </Link>

            <div className="py-2">
              <p className="font-semibold text-[#0B1F3B] mb-2">Study Destinations</p>
              <div className="pl-4 space-y-2 max-h-[200px] overflow-y-auto">
                {countries.map((country) => (
                  <Link
                    key={country.slug}
                    to={`/country/${country.slug}`}
                    className="block py-1 text-sm text-gray-600"
                  >
                    {country.flag} {country.name}
                  </Link>
                ))}
              </div>
            </div>

            <Link
              to="/find-your-course"
              className="block py-2 text-[#0B1F3B] font-medium"
            >
              Find Your Course
            </Link>

            <div className="py-2">
              <p className="font-semibold text-[#0B1F3B] mb-2">Services</p>
              <div className="pl-4 space-y-2">
                {services.map((service) => (
                  <Link
                    key={service.slug}
                    to={`/services/${service.slug}`}
                    className="block py-1 text-sm text-gray-600"
                  >
                    {service.name}
                  </Link>
                ))}
              </div>
            </div>

            <Link to="/visa-guidance" className="block py-2 text-[#0B1F3B] font-medium">
              Visa Guidance
            </Link>

            <Link to="/scholarships" className="block py-2 text-[#0B1F3B] font-medium">
              Scholarships
            </Link>

            <Link to="/blog" className="block py-2 text-[#0B1F3B] font-medium">
              Blog
            </Link>

            <Link 
              to="/contact" 
              className="block text-center mt-4 font-semibold px-5 py-3 rounded-lg"
              style={{ backgroundColor: GOLD_PRIMARY, color: NAVY_DARK }}
            >
              Free Consultation
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
