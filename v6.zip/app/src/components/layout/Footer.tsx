import { Link } from "react-router-dom";
import {
  GraduationCap,
  MapPin,
  Phone,
  Mail,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
} from "lucide-react";

const quickLinks = [
  { name: "Home", href: "/" },
  { name: "Find Your Course", href: "/find-your-course" },
  { name: "Success Stories", href: "/success-stories" },
  { name: "Blog", href: "/blog" },
  { name: "About Us", href: "/about" },
  { name: "Contact", href: "/contact" },
];

const studyDestinations = [
  { name: "United Kingdom", href: "/country/uk" },
  { name: "Australia", href: "/country/australia" },
  { name: "Germany", href: "/country/germany" },
  { name: "France", href: "/country/france" },
  { name: "Ireland", href: "/country/ireland" },
  { name: "Netherlands", href: "/country/netherlands" },
];

const services = [
  { name: "Career Counselling", href: "/services/career-counselling" },
  { name: "Course Selection", href: "/services/course-selection" },
  { name: "Application Assistance", href: "/services/application-assistance" },
  { name: "Visa Assistance", href: "/services/visa-assistance" },
  { name: "Scholarship Guidance", href: "/services/scholarship-guidance" },
  { name: "Education Loans", href: "/services/education-loans" },
];

export function Footer() {
  return (
    <footer className="bg-[#0B1F3B] text-white">
      {/* Main footer */}
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Company info */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <GraduationCap className="w-10 h-10 text-[#C6A052]" />
              <div className="flex flex-col">
                <span className="font-playfair text-2xl font-bold leading-tight">
                  Kingsley
                </span>
                <span className="text-xs text-[#C6A052] font-medium tracking-wider">
                  INTERNATIONAL
                </span>
              </div>
            </Link>
            <p className="text-gray-300 text-sm mb-6 leading-relaxed">
              Your trusted partner for overseas education. We help Indian students
              achieve their dreams of studying at top universities worldwide.
            </p>
            <div className="space-y-3">
              <div className="flex items-start gap-3 text-sm text-gray-300">
                <MapPin className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                <span>
                  123 Education Street, Koramangala
                  <br />
                  Bangalore, Karnataka 560034
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm text-gray-300">
                <Phone className="w-5 h-5 text-[#C6A052] flex-shrink-0" />
                <a href="tel:+919876543210" className="hover:text-[#C6A052] transition-colors">
                  +91 98765 43210
                </a>
              </div>
              <div className="flex items-center gap-3 text-sm text-gray-300">
                <Mail className="w-5 h-5 text-[#C6A052] flex-shrink-0" />
                <a href="mailto:info@kingsley.edu" className="hover:text-[#C6A052] transition-colors">
                  info@kingsley.edu
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-playfair text-lg font-semibold mb-6 text-[#C6A052]">
              Quick Links
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-300 hover:text-[#C6A052] transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Study Destinations */}
          <div>
            <h3 className="font-playfair text-lg font-semibold mb-6 text-[#C6A052]">
              Study Destinations
            </h3>
            <ul className="space-y-3">
              {studyDestinations.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-300 hover:text-[#C6A052] transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            <Link
              to="/find-your-course"
              className="inline-block mt-4 text-[#C6A052] hover:text-[#E5C27A] text-sm font-medium"
            >
              View All Countries →
            </Link>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-playfair text-lg font-semibold mb-6 text-[#C6A052]">
              Our Services
            </h3>
            <ul className="space-y-3">
              {services.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-300 hover:text-[#C6A052] transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-[#1a3a5f]">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm text-center md:text-left">
              © {new Date().getFullYear()} Kingsley International. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1a3a5f] flex items-center justify-center hover:bg-[#C6A052] hover:text-[#0B1F3B] transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1a3a5f] flex items-center justify-center hover:bg-[#C6A052] hover:text-[#0B1F3B] transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1a3a5f] flex items-center justify-center hover:bg-[#C6A052] hover:text-[#0B1F3B] transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1a3a5f] flex items-center justify-center hover:bg-[#C6A052] hover:text-[#0B1F3B] transition-colors"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <Link to="/privacy" className="hover:text-[#C6A052] transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="hover:text-[#C6A052] transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
