export interface CountryData {
  slug: string;
  name: string;
  flag: string;
  overview: string;
  whyStudy: string[];
  quickFacts: { label: string; value: string }[];
  topUniversities: string[];
  popularPrograms: string[];
  tuitionRange: {
    undergraduate: string;
    postgraduate: string;
  };
  livingCost: {
    range: string;
    details: { category: string; cost: string }[];
  };
  ieltsRequirements: {
    undergraduate: string;
    postgraduate: string;
  };
  visaProcess: {
    type: string;
    processingTime: string;
    fundsRequired: string;
    workRights: string;
    postStudyWork: string;
    prPathway: string;
  };
  topCities: string[];
  averageSalary: string;
  intakeMonths: string[];
  applicationTimeline: string;
  scholarships: {
    name: string;
    eligibility: string;
    amount: string;
    deadline: string;
  }[];
}

export const countriesData: Record<string, CountryData> = {
  uk: {
    slug: "uk",
    name: "United Kingdom",
    flag: "🇬🇧",
    overview: "The United Kingdom is home to some of the world's oldest and most prestigious universities. With a rich academic heritage spanning centuries, the UK offers world-class education, cutting-edge research facilities, and globally recognized degrees that open doors to international career opportunities.",
    whyStudy: [
      "World-renowned universities with excellent academic reputation",
      "Shorter course durations (3 years for UG, 1 year for PG)",
      "Post-study work visa (Graduate Route) for 2 years",
      "Multicultural environment with large Indian student community",
      "Strong industry connections and employment opportunities",
      "Access to NHS healthcare for students",
      "Part-time work opportunities during studies"
    ],
    quickFacts: [
      { label: "Capital", value: "London" },
      { label: "Currency", value: "British Pound (GBP)" },
      { label: "Language", value: "English" },
      { label: "Time Zone", value: "GMT (UTC+0)" },
      { label: "Population", value: "67 million" },
      { label: "International Students", value: "600,000+" }
    ],
    topUniversities: [
      "University of Oxford",
      "University of Cambridge",
      "Imperial College London",
      "University College London",
      "University of Edinburgh",
      "University of Manchester",
      "King's College London",
      "London School of Economics"
    ],
    popularPrograms: [
      "Business & Management",
      "Computer Science",
      "Engineering",
      "Medicine & Healthcare",
      "Law",
      "Data Science",
      "Finance & Accounting",
      "Psychology"
    ],
    tuitionRange: {
      undergraduate: "£12,000 - £35,000 per year",
      postgraduate: "£15,000 - £40,000 per year"
    },
    livingCost: {
      range: "£12,000 - £15,000 per year",
      details: [
        { category: "London", cost: "£1,200 - £1,500/month" },
        { category: "Other Cities", cost: "£800 - £1,000/month" },
        { category: "Accommodation", cost: "£400 - £800/month" },
        { category: "Food", cost: "£150 - £250/month" },
        { category: "Transport", cost: "£50 - £100/month" },
        { category: "Utilities", cost: "£100 - £150/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall (minimum 5.5 in each band)",
      postgraduate: "6.5 - 7.0 overall (minimum 6.0 in each band)"
    },
    visaProcess: {
      type: "Student Route Visa (formerly Tier 4)",
      processingTime: "3-4 weeks",
      fundsRequired: "Tuition fees + £9,207 (London) or £7,347 (outside London) for 9 months",
      workRights: "20 hours/week during term, full-time during holidays",
      postStudyWork: "Graduate Route - 2 years (3 years for PhD)",
      prPathway: "Possible through Skilled Worker visa after PSW"
    },
    topCities: ["London", "Manchester", "Edinburgh", "Birmingham", "Glasgow", "Bristol"],
    averageSalary: "£25,000 - £35,000 per year (graduate)",
    intakeMonths: ["September", "January"],
    applicationTimeline: "Apply 9-12 months before intake",
    scholarships: [
      {
        name: "Chevening Scholarship",
        eligibility: "Leadership potential, 2+ years work experience",
        amount: "Full tuition + living expenses + flights",
        deadline: "August"
      },
      {
        name: "Commonwealth Scholarship",
        eligibility: "Citizens of Commonwealth countries",
        amount: "Full tuition + living expenses",
        deadline: "October-December"
      },
      {
        name: "GREAT Scholarship",
        eligibility: "Indian students for selected universities",
        amount: "£10,000 towards tuition fees",
        deadline: "Varies by university"
      }
    ]
  },
  
  ireland: {
    slug: "ireland",
    name: "Ireland",
    flag: "🇮🇪",
    overview: "Ireland is an emerging favourite among Indian students, offering high-quality education, a friendly English-speaking environment, and excellent post-study work opportunities. Known as the 'Silicon Valley of Europe', Ireland hosts major tech companies and offers strong employment prospects.",
    whyStudy: [
      "English-speaking country with friendly locals",
      "2-year post-study work visa for graduates",
      "Home to European headquarters of tech giants",
      "High-quality education system",
      "Safe and welcoming environment",
      "Gateway to Europe with easy travel access",
      "Strong pharmaceutical and tech industries"
    ],
    quickFacts: [
      { label: "Capital", value: "Dublin" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "English, Irish" },
      { label: "Time Zone", value: "GMT (UTC+0)" },
      { label: "Population", value: "5 million" },
      { label: "International Students", value: "35,000+" }
    ],
    topUniversities: [
      "Trinity College Dublin",
      "University College Dublin",
      "University College Cork",
      "National University of Ireland Galway",
      "Dublin City University",
      "University of Limerick",
      "Maynooth University",
      "Technological University Dublin"
    ],
    popularPrograms: [
      "Computer Science & IT",
      "Data Analytics",
      "Business & Management",
      "Pharmaceutical Science",
      "Engineering",
      "Biotechnology",
      "Finance",
      "Digital Marketing"
    ],
    tuitionRange: {
      undergraduate: "€10,000 - €25,000 per year",
      postgraduate: "€12,000 - €30,000 per year"
    },
    livingCost: {
      range: "€10,000 - €14,000 per year",
      details: [
        { category: "Dublin", cost: "€1,100 - €1,400/month" },
        { category: "Other Cities", cost: "€800 - €1,000/month" },
        { category: "Accommodation", cost: "€500 - €900/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€50 - €100/month" },
        { category: "Utilities", cost: "€80 - €120/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall (minimum 5.5 in each band)",
      postgraduate: "6.5 overall (minimum 6.0 in each band)"
    },
    visaProcess: {
      type: "Study Visa (D Visa)",
      processingTime: "4-8 weeks",
      fundsRequired: "Tuition fees + €10,000 living expenses proof",
      workRights: "20 hours/week during term, 40 hours during holidays",
      postStudyWork: "Third Level Graduate Scheme - 2 years",
      prPathway: "Critical Skills Employment Permit pathway available"
    },
    topCities: ["Dublin", "Cork", "Galway", "Limerick", "Waterford"],
    averageSalary: "€30,000 - €45,000 per year (graduate)",
    intakeMonths: ["September", "January"],
    applicationTimeline: "Apply 6-9 months before intake",
    scholarships: [
      {
        name: "Government of Ireland International Education Scholarship",
        eligibility: "Non-EU/EEA students with excellent academics",
        amount: "€10,000 stipend + full fee waiver",
        deadline: "March"
      },
      {
        name: "Trinity College Dublin Scholarship",
        eligibility: "Academic excellence",
        amount: "€5,000 - €10,000",
        deadline: "Varies"
      }
    ]
  },

  germany: {
    slug: "germany",
    name: "Germany",
    flag: "🇩🇪",
    overview: "Germany is renowned for its tuition-free education at public universities, world-class engineering programs, and strong research focus. As Europe's largest economy, it offers excellent career prospects and a high standard of living for international students.",
    whyStudy: [
      "Tuition-free education at public universities",
      "World-class engineering and technical programs",
      "Strong economy with excellent job prospects",
      "18-month post-study work visa",
      "Central location in Europe for travel",
      "High quality of life and safety",
      "Strong industry-academia collaboration"
    ],
    quickFacts: [
      { label: "Capital", value: "Berlin" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "German, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "83 million" },
      { label: "International Students", value: "400,000+" }
    ],
    topUniversities: [
      "Technical University of Munich",
      "Ludwig Maximilian University of Munich",
      "Heidelberg University",
      "Humboldt University of Berlin",
      "Karlsruhe Institute of Technology",
      "RWTH Aachen University",
      "Free University of Berlin",
      "University of Freiburg"
    ],
    popularPrograms: [
      "Mechanical Engineering",
      "Computer Science",
      "Automotive Engineering",
      "Electrical Engineering",
      "Business Administration",
      "Physics",
      "Chemistry",
      "Medicine"
    ],
    tuitionRange: {
      undergraduate: "Free - €3,000 per year (public universities)",
      postgraduate: "Free - €5,000 per year (public universities)"
    },
    livingCost: {
      range: "€10,332 - €12,000 per year",
      details: [
        { category: "Munich/Frankfurt", cost: "€900 - €1,200/month" },
        { category: "Berlin/Hamburg", cost: "€800 - €1,000/month" },
        { category: "Smaller Cities", cost: "€600 - €800/month" },
        { category: "Accommodation", cost: "€300 - €600/month" },
        { category: "Food", cost: "€200 - €250/month" },
        { category: "Health Insurance", cost: "€110/month (mandatory)" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall (English-taught programs)",
      postgraduate: "6.5 - 7.0 overall (English-taught programs)"
    },
    visaProcess: {
      type: "Student Visa (Visum zu Studienzwecken)",
      processingTime: "6-12 weeks",
      fundsRequired: "Blocked account with €11,208 per year",
      workRights: "120 full days or 240 half days per year",
      postStudyWork: "18-month job seeker visa after graduation",
      prPathway: "EU Blue Card or German permanent residence"
    },
    topCities: ["Berlin", "Munich", "Hamburg", "Frankfurt", "Cologne", "Stuttgart"],
    averageSalary: "€40,000 - €55,000 per year (graduate)",
    intakeMonths: ["October", "April"],
    applicationTimeline: "Apply 6-12 months before intake",
    scholarships: [
      {
        name: "DAAD Scholarship",
        eligibility: "Graduates with 2+ years experience",
        amount: "€850-1,200/month + allowances",
        deadline: "Varies by program"
      },
      {
        name: "Deutschlandstipendium",
        eligibility: "Outstanding academic achievement",
        amount: "€300/month",
        deadline: "Varies by university"
      }
    ]
  },

  france: {
    slug: "france",
    name: "France",
    flag: "🇫🇷",
    overview: "France offers a unique blend of academic excellence, cultural richness, and affordable education. Known for its prestigious grandes écoles and research-intensive universities, France is an attractive destination for students seeking quality education in the heart of Europe.",
    whyStudy: [
      "Low tuition fees at public universities",
      "World-renowned business schools (INSEAD, HEC)",
      "Rich cultural experience",
      "2-year post-study work visa",
      "Central European location",
      "Strong aerospace and luxury industry",
      "Beautiful cities and high quality of life"
    ],
    quickFacts: [
      { label: "Capital", value: "Paris" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "French, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "68 million" },
      { label: "International Students", value: "400,000+" }
    ],
    topUniversities: [
      "Sorbonne University",
      "Paris-Saclay University",
      "PSL University",
      "École Polytechnique",
      "INSEAD",
      "HEC Paris",
      "Sciences Po",
      "University of Paris"
    ],
    popularPrograms: [
      "Business & Management",
      "Fashion & Luxury Management",
      "Hospitality Management",
      "Aerospace Engineering",
      "International Relations",
      "Culinary Arts",
      "Fine Arts",
      "Computer Science"
    ],
    tuitionRange: {
      undergraduate: "€170 - €3,000 per year (public)",
      postgraduate: "€243 - €4,000 per year (public)"
    },
    livingCost: {
      range: "€10,000 - €14,000 per year",
      details: [
        { category: "Paris", cost: "€1,000 - €1,500/month" },
        { category: "Other Cities", cost: "€700 - €1,000/month" },
        { category: "Accommodation", cost: "€400 - €800/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€30 - €75/month" },
        { category: "Health Insurance", cost: "€20-50/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall (English programs)",
      postgraduate: "6.5 overall (English programs)"
    },
    visaProcess: {
      type: "Long-Stay Student Visa (VLS-TS)",
      processingTime: "2-4 weeks",
      fundsRequired: "€615/month proof (€7,380/year)",
      workRights: "964 hours per year (approx. 20 hours/week)",
      postStudyWork: "APS visa - 2 years for master's graduates",
      prPathway: "Talent Passport or regular residence permit"
    },
    topCities: ["Paris", "Lyon", "Marseille", "Toulouse", "Nice", "Bordeaux"],
    averageSalary: "€30,000 - €42,000 per year (graduate)",
    intakeMonths: ["September", "January"],
    applicationTimeline: "Apply 6-9 months before intake",
    scholarships: [
      {
        name: "Eiffel Excellence Scholarship",
        eligibility: "Master's and PhD applicants",
        amount: "€1,181/month (master's), €1,400/month (PhD)",
        deadline: "January"
      },
      {
        name: "Charpak Scholarship",
        eligibility: "Indian students",
        amount: "Variable (tuition + living allowance)",
        deadline: "February"
      }
    ]
  },

  netherlands: {
    slug: "netherlands",
    name: "Netherlands",
    flag: "🇳🇱",
    overview: "The Netherlands is known for its innovative teaching methods, English-taught programs, and international outlook. With a strong economy and excellent quality of life, it's a popular choice for students seeking a modern European education experience.",
    whyStudy: [
      "High-quality English-taught programs",
      "Innovative teaching methods",
      "International business hub",
      "1-year post-study work visa (Orientation Year)",
      "Cycling-friendly and sustainable",
      "High English proficiency",
      "Strong tech and agritech sectors"
    ],
    quickFacts: [
      { label: "Capital", value: "Amsterdam" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "Dutch, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "17.5 million" },
      { label: "International Students", value: "120,000+" }
    ],
    topUniversities: [
      "University of Amsterdam",
      "Delft University of Technology",
      "Wageningen University",
      "Utrecht University",
      "Leiden University",
      "Eindhoven University of Technology",
      "University of Groningen",
      "Erasmus University Rotterdam"
    ],
    popularPrograms: [
      "Water Management",
      "Agricultural Sciences",
      "Engineering",
      "Business & Economics",
      "Computer Science",
      "Architecture",
      "International Law",
      "Psychology"
    ],
    tuitionRange: {
      undergraduate: "€2,500 - €15,000 per year (EU rates for some)",
      postgraduate: "€8,000 - €25,000 per year"
    },
    livingCost: {
      range: "€12,000 - €15,000 per year",
      details: [
        { category: "Amsterdam", cost: "€1,200 - €1,500/month" },
        { category: "Other Cities", cost: "€900 - €1,200/month" },
        { category: "Accommodation", cost: "€500 - €900/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€50 - €100/month" },
        { category: "Health Insurance", cost: "€100-120/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall",
      postgraduate: "6.5 overall (some require 7.0)"
    },
    visaProcess: {
      type: "Residence Permit for Study (MVV + VVR)",
      processingTime: "4-8 weeks",
      fundsRequired: "€1,000/month proof (€12,000/year)",
      workRights: "16 hours/week or seasonal work full-time",
      postStudyWork: "Orientation Year - 1 year",
      prPathway: "Highly Skilled Migrant visa after employment"
    },
    topCities: ["Amsterdam", "Rotterdam", "The Hague", "Utrecht", "Eindhoven", "Delft"],
    averageSalary: "€32,000 - €45,000 per year (graduate)",
    intakeMonths: ["September", "February"],
    applicationTimeline: "Apply 6 months before intake",
    scholarships: [
      {
        name: "Holland Scholarship",
        eligibility: "Non-EEA students for bachelor's/master's",
        amount: "€5,000 one-time",
        deadline: "February/May"
      },
      {
        name: "Orange Knowledge Programme",
        eligibility: "Professionals from specific countries",
        amount: "Full funding",
        deadline: "Varies"
      }
    ]
  },

  italy: {
    slug: "italy",
    name: "Italy",
    flag: "🇮🇹",
    overview: "Italy combines world-class education with unparalleled art, culture, and cuisine. Home to some of the oldest universities in the world, Italy offers affordable education and a unique lifestyle experience in the heart of the Mediterranean.",
    whyStudy: [
      "Affordable tuition at public universities",
      "Rich cultural and historical heritage",
      "World-renowned art and design schools",
      "Excellent food and wine programs",
      "1-year post-study work permit",
      "Beautiful cities and landscapes",
      "Strong fashion and design industry"
    ],
    quickFacts: [
      { label: "Capital", value: "Rome" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "Italian, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "59 million" },
      { label: "International Students", value: "90,000+" }
    ],
    topUniversities: [
      "University of Bologna",
      "Sapienza University of Rome",
      "Politecnico di Milano",
      "University of Milan",
      "University of Padua",
      "University of Florence",
      "Bocconi University",
      "Politecnico di Torino"
    ],
    popularPrograms: [
      "Fashion Design",
      "Architecture",
      "Art History",
      "Culinary Arts",
      "Engineering",
      "Business",
      "Medicine",
      "Classical Studies"
    ],
    tuitionRange: {
      undergraduate: "€900 - €4,000 per year (public universities)",
      postgraduate: "€1,000 - €5,000 per year (public universities)"
    },
    livingCost: {
      range: "€10,000 - €14,000 per year",
      details: [
        { category: "Milan/Rome", cost: "€1,000 - €1,400/month" },
        { category: "Other Cities", cost: "€700 - €1,000/month" },
        { category: "Accommodation", cost: "€350 - €700/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€25 - €50/month" },
        { category: "Health Insurance", cost: "€150-200/year" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "5.5 - 6.0 overall (English programs)",
      postgraduate: "6.0 - 6.5 overall (English programs)"
    },
    visaProcess: {
      type: "Type D National Visa (Study)",
      processingTime: "4-8 weeks",
      fundsRequired: "€450-600/month proof (€6,000-8,000/year)",
      workRights: "20 hours/week during term",
      postStudyWork: "Permesso di Soggiorno for job search - 1 year",
      prPathway: "Elective Residence Visa or work-based permit"
    },
    topCities: ["Rome", "Milan", "Florence", "Bologna", "Venice", "Turin"],
    averageSalary: "€24,000 - €32,000 per year (graduate)",
    intakeMonths: ["September", "February"],
    applicationTimeline: "Apply 6-9 months before intake",
    scholarships: [
      {
        name: "Italian Government Scholarship",
        eligibility: "International students",
        amount: "€900/month + tuition waiver",
        deadline: "June"
      },
      {
        name: "Invest Your Talent in Italy",
        eligibility: "Master's students from selected countries",
        amount: "€8,100 + tuition waiver + internship",
        deadline: "January"
      }
    ]
  },

  spain: {
    slug: "spain",
    name: "Spain",
    flag: "🇪🇸",
    overview: "Spain offers a vibrant lifestyle, affordable education, and growing opportunities for international students. With excellent business schools and a booming tech sector, Spain is becoming increasingly popular among Indian students.",
    whyStudy: [
      "Affordable tuition fees",
      "High quality business schools (IE, ESADE)",
      "Vibrant lifestyle and culture",
      "Growing tech startup ecosystem",
      "1-year job search visa after studies",
      "Great weather and beaches",
      "Gateway to Latin American markets"
    ],
    quickFacts: [
      { label: "Capital", value: "Madrid" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "Spanish, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "47 million" },
      { label: "International Students", value: "200,000+" }
    ],
    topUniversities: [
      "University of Barcelona",
      "Autonomous University of Barcelona",
      "Autonomous University of Madrid",
      "Complutense University of Madrid",
      "Pompeu Fabra University",
      "IE University",
      "ESADE Business School",
      "University of Navarra"
    ],
    popularPrograms: [
      "Business Administration",
      "Tourism & Hospitality",
      "Law",
      "Medicine",
      "Architecture",
      "Computer Science",
      "International Relations",
      "Sports Management"
    ],
    tuitionRange: {
      undergraduate: "€680 - €3,500 per year (public universities)",
      postgraduate: "€1,500 - €5,000 per year (public universities)"
    },
    livingCost: {
      range: "€10,000 - €14,000 per year",
      details: [
        { category: "Madrid/Barcelona", cost: "€1,000 - €1,400/month" },
        { category: "Other Cities", cost: "€700 - €1,000/month" },
        { category: "Accommodation", cost: "€400 - €800/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€40 - €60/month" },
        { category: "Health Insurance", cost: "€50-100/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "5.5 - 6.0 overall (English programs)",
      postgraduate: "6.0 - 6.5 overall (English programs)"
    },
    visaProcess: {
      type: "Student Visa (Type D)",
      processingTime: "4-8 weeks",
      fundsRequired: "€600-800/month proof (€7,200-10,000/year)",
      workRights: "20 hours/week during term",
      postStudyWork: "Job search visa - up to 1 year",
      prPathway: "Work permit or entrepreneur visa"
    },
    topCities: ["Madrid", "Barcelona", "Valencia", "Seville", "Bilbao", "Granada"],
    averageSalary: "€22,000 - €30,000 per year (graduate)",
    intakeMonths: ["September", "February"],
    applicationTimeline: "Apply 6-9 months before intake",
    scholarships: [
      {
        name: "MAEC-AECID Scholarship",
        eligibility: "International students",
        amount: "Full funding available",
        deadline: "Varies"
      }
    ]
  },

  sweden: {
    slug: "sweden",
    name: "Sweden",
    flag: "🇸🇪",
    overview: "Sweden is known for its innovative education system, sustainability focus, and high quality of life. Swedish universities emphasize creativity, critical thinking, and collaboration, preparing students for the global job market.",
    whyStudy: [
      "Innovative and creative education system",
      "High English proficiency",
      "Strong tech and innovation sector",
      "12-month job search visa after graduation",
      "Focus on sustainability and equality",
      "High quality of life",
      "Gender equality and work-life balance"
    ],
    quickFacts: [
      { label: "Capital", value: "Stockholm" },
      { label: "Currency", value: "Swedish Krona (SEK)" },
      { label: "Language", value: "Swedish, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "10.5 million" },
      { label: "International Students", value: "40,000+" }
    ],
    topUniversities: [
      "KTH Royal Institute of Technology",
      "Lund University",
      "Stockholm University",
      "Uppsala University",
      "Chalmers University of Technology",
      "Karolinska Institutet",
      "Linköping University",
      "University of Gothenburg"
    ],
    popularPrograms: [
      "Engineering",
      "Computer Science",
      "Sustainable Development",
      "Life Sciences",
      "Design",
      "Business",
      "Environmental Science",
      "Game Development"
    ],
    tuitionRange: {
      undergraduate: "SEK 80,000 - 150,000 per year",
      postgraduate: "SEK 100,000 - 180,000 per year"
    },
    livingCost: {
      range: "SEK 100,000 - 120,000 per year (€9,000-11,000)",
      details: [
        { category: "Stockholm", cost: "SEK 9,000 - 11,000/month" },
        { category: "Other Cities", cost: "SEK 7,000 - 9,000/month" },
        { category: "Accommodation", cost: "SEK 4,000 - 7,000/month" },
        { category: "Food", cost: "SEK 2,000 - 2,500/month" },
        { category: "Transport", cost: "SEK 600 - 900/month" },
        { category: "Health Insurance", cost: "SEK 300-500/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall",
      postgraduate: "6.5 overall (some require 7.0)"
    },
    visaProcess: {
      type: "Residence Permit for Studies",
      processingTime: "2-4 months",
      fundsRequired: "SEK 9,450/month proof (SEK 85,000/year)",
      workRights: "No official limit, but studies must be prioritized",
      postStudyWork: "12-month job search permit after graduation",
      prPathway: "Work permit leading to permanent residence"
    },
    topCities: ["Stockholm", "Gothenburg", "Malmö", "Lund", "Uppsala", "Linköping"],
    averageSalary: "SEK 360,000 - 480,000 per year (€32,000-43,000)",
    intakeMonths: ["August/September"],
    applicationTimeline: "Apply October-January for autumn intake",
    scholarships: [
      {
        name: "Swedish Institute Scholarship",
        eligibility: "Students from selected countries",
        amount: "Full tuition + living expenses + travel grant",
        deadline: "February"
      },
      {
        name: "University-specific scholarships",
        eligibility: "Academic excellence",
        amount: "25-100% tuition waiver",
        deadline: "Varies"
      }
    ]
  },

  newzealand: {
    slug: "newzealand",
    name: "New Zealand",
    flag: "🇳🇿",
    overview: "New Zealand offers world-class education in a stunning natural environment. Known for its welcoming culture and innovative teaching methods, it's an excellent choice for students seeking quality education and outdoor adventure.",
    whyStudy: [
      "Globally recognized qualifications",
      "Post-study work visa (up to 3 years)",
      "High quality of life and safety",
      "Stunning natural landscapes",
      "Innovative teaching methods",
      "Pathway to permanent residence",
      "Friendly and welcoming culture"
    ],
    quickFacts: [
      { label: "Capital", value: "Wellington" },
      { label: "Currency", value: "New Zealand Dollar (NZD)" },
      { label: "Language", value: "English, Māori" },
      { label: "Time Zone", value: "NZST (UTC+12)" },
      { label: "Population", value: "5.1 million" },
      { label: "International Students", value: "50,000+" }
    ],
    topUniversities: [
      "University of Auckland",
      "University of Otago",
      "Victoria University of Wellington",
      "University of Canterbury",
      "Massey University",
      "University of Waikato",
      "Lincoln University",
      "Auckland University of Technology"
    ],
    popularPrograms: [
      "Business & Management",
      "Engineering",
      "Information Technology",
      "Health Sciences",
      "Environmental Science",
      "Agriculture",
      "Hospitality & Tourism",
      "Marine Biology"
    ],
    tuitionRange: {
      undergraduate: "NZD 22,000 - 35,000 per year",
      postgraduate: "NZD 26,000 - 40,000 per year"
    },
    livingCost: {
      range: "NZD 20,000 - 25,000 per year",
      details: [
        { category: "Auckland", cost: "NZD 1,800 - 2,500/month" },
        { category: "Other Cities", cost: "NZD 1,200 - 1,800/month" },
        { category: "Accommodation", cost: "NZD 800 - 1,500/month" },
        { category: "Food", cost: "NZD 300 - 500/month" },
        { category: "Transport", cost: "NZD 100 - 200/month" },
        { category: "Health Insurance", cost: "NZD 500-700/year" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 overall (minimum 5.5 in each band)",
      postgraduate: "6.5 overall (minimum 6.0 in each band)"
    },
    visaProcess: {
      type: "Fee Paying Student Visa",
      processingTime: "4-8 weeks",
      fundsRequired: "NZD 20,000/year living expenses + tuition",
      workRights: "20 hours/week during term, full-time during holidays",
      postStudyWork: "Post-study work visa - 1-3 years depending on qualification",
      prPathway: "Skilled Migrant Category available"
    },
    topCities: ["Auckland", "Wellington", "Christchurch", "Dunedin", "Hamilton"],
    averageSalary: "NZD 50,000 - 70,000 per year (graduate)",
    intakeMonths: ["February", "July"],
    applicationTimeline: "Apply 6-9 months before intake",
    scholarships: [
      {
        name: "New Zealand Excellence Awards",
        eligibility: "Indian students for selected universities",
        amount: "Up to NZD 10,000",
        deadline: "Varies"
      },
      {
        name: "Commonwealth Scholarship",
        eligibility: "Commonwealth country citizens",
        amount: "Full funding",
        deadline: "March"
      }
    ]
  },

  australia: {
    slug: "australia",
    name: "Australia",
    flag: "🇦🇺",
    overview: "Australia offers world-class education with a focus on research and innovation. Known for its high quality of life, beautiful landscapes, and welcoming multicultural society, Australia is a top choice for international students.",
    whyStudy: [
      "Globally recognized qualifications",
      "Post-study work rights (2-4 years)",
      "High standard of living",
      "Strong research and innovation focus",
      "Multicultural and safe environment",
      "Part-time work opportunities",
      "Pathway to permanent residence"
    ],
    quickFacts: [
      { label: "Capital", value: "Canberra" },
      { label: "Currency", value: "Australian Dollar (AUD)" },
      { label: "Language", value: "English" },
      { label: "Time Zone", value: "AEST (UTC+10)" },
      { label: "Population", value: "26 million" },
      { label: "International Students", value: "600,000+" }
    ],
    topUniversities: [
      "University of Melbourne",
      "Australian National University",
      "University of Sydney",
      "University of Queensland",
      "University of New South Wales",
      "Monash University",
      "University of Western Australia",
      "University of Adelaide"
    ],
    popularPrograms: [
      "Business & Management",
      "Engineering",
      "Information Technology",
      "Health Sciences",
      "Accounting & Finance",
      "Hospitality & Tourism",
      "Environmental Science",
      "Media & Communications"
    ],
    tuitionRange: {
      undergraduate: "AUD 20,000 - 45,000 per year",
      postgraduate: "AUD 25,000 - 50,000 per year"
    },
    livingCost: {
      range: "AUD 21,041 per year (minimum requirement)",
      details: [
        { category: "Sydney/Melbourne", cost: "AUD 1,800 - 2,500/month" },
        { category: "Other Cities", cost: "AUD 1,200 - 1,800/month" },
        { category: "Accommodation", cost: "AUD 800 - 1,500/month" },
        { category: "Food", cost: "AUD 300 - 500/month" },
        { category: "Transport", cost: "AUD 100 - 150/month" },
        { category: "Health Insurance", cost: "AUD 500-600/year (OSHC)" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 - 6.5 overall (minimum 5.5-6.0 in each band)",
      postgraduate: "6.5 overall (minimum 6.0 in each band)"
    },
    visaProcess: {
      type: "Subclass 500 Student Visa",
      processingTime: "4-12 weeks",
      fundsRequired: "Tuition + AUD 21,041/year living expenses",
      workRights: "48 hours/fortnight during term, unlimited during holidays",
      postStudyWork: "Temporary Graduate Visa (485) - 2-4 years",
      prPathway: "Skilled Independent or Employer Sponsored pathways"
    },
    topCities: ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Canberra"],
    averageSalary: "AUD 60,000 - 75,000 per year (graduate)",
    intakeMonths: ["February", "July", "November"],
    applicationTimeline: "Apply 6-12 months before intake",
    scholarships: [
      {
        name: "Australia Awards",
        eligibility: "Students from selected countries",
        amount: "Full tuition + living expenses + travel",
        deadline: "April-May"
      },
      {
        name: "Destination Australia",
        eligibility: "Students studying in regional areas",
        amount: "Up to AUD 15,000 per year",
        deadline: "Varies"
      }
    ]
  },

  austria: {
    slug: "austria",
    name: "Austria",
    flag: "🇦🇹",
    overview: "Austria offers high-quality education in the heart of Europe with affordable tuition fees. Known for its rich cultural heritage, music, and art, Austria provides a unique study experience with excellent living standards.",
    whyStudy: [
      "Low tuition fees for international students",
      "High quality of life and safety",
      "Central European location",
      "Rich cultural and musical heritage",
      "English-taught programs available",
      "12-month Red-White-Red Card for job search",
      "Beautiful Alpine landscapes"
    ],
    quickFacts: [
      { label: "Capital", value: "Vienna" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Language", value: "German, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "9 million" },
      { label: "International Students", value: "80,000+" }
    ],
    topUniversities: [
      "University of Vienna",
      "Vienna University of Technology",
      "University of Graz",
      "Johannes Kepler University Linz",
      "University of Innsbruck",
      "Vienna University of Economics",
      "Medical University of Vienna",
      "University of Salzburg"
    ],
    popularPrograms: [
      "Music & Arts",
      "Business & Economics",
      "Engineering",
      "Medicine",
      "Natural Sciences",
      "Architecture",
      "Tourism",
      "Psychology"
    ],
    tuitionRange: {
      undergraduate: "€1,500 - €2,000 per year (public universities)",
      postgraduate: "€1,500 - €2,500 per year (public universities)"
    },
    livingCost: {
      range: "€12,000 - €15,000 per year",
      details: [
        { category: "Vienna", cost: "€1,000 - €1,300/month" },
        { category: "Other Cities", cost: "€800 - €1,000/month" },
        { category: "Accommodation", cost: "€400 - €700/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€30 - €50/month" },
        { category: "Health Insurance", cost: "€60-100/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 overall (English programs)",
      postgraduate: "6.5 overall (English programs)"
    },
    visaProcess: {
      type: "Student Residence Permit",
      processingTime: "3-6 months",
      fundsRequired: "€1,200/month proof (€14,400/year)",
      workRights: "20 hours/week during term",
      postStudyWork: "Red-White-Red Card - 12 months job search",
      prPathway: "Red-White-Red Card for skilled workers"
    },
    topCities: ["Vienna", "Graz", "Linz", "Salzburg", "Innsbruck"],
    averageSalary: "€30,000 - €42,000 per year (graduate)",
    intakeMonths: ["October", "March"],
    applicationTimeline: "Apply 6-9 months before intake",
    scholarships: [
      {
        name: "OeAD Scholarship",
        eligibility: "International students",
        amount: "€1,050/month + accommodation + insurance",
        deadline: "March"
      }
    ]
  },

  belgium: {
    slug: "belgium",
    name: "Belgium",
    flag: "🇧🇪",
    overview: "Belgium offers high-quality education at affordable prices, situated at the crossroads of Europe. Home to the EU institutions, Belgium provides unique opportunities for students interested in international relations, politics, and business.",
    whyStudy: [
      "Affordable tuition fees",
      "Heart of European politics (EU headquarters)",
      "Multilingual environment",
      "High quality of education",
      "12-month job search visa after graduation",
      "Excellent chocolate and cuisine",
      "Central European location"
    ],
    quickFacts: [
      { label: "Capital", value: "Brussels" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Languages", value: "Dutch, French, German, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "11.6 million" },
      { label: "International Students", value: "60,000+" }
    ],
    topUniversities: [
      "KU Leuven",
      "Ghent University",
      "Université catholique de Louvain",
      "Vrije Universiteit Brussel",
      "University of Antwerp",
      "Université libre de Bruxelles",
      "Hasselt University"
    ],
    popularPrograms: [
      "International Relations",
      "European Studies",
      "Business & Economics",
      "Engineering",
      "Law",
      "Political Science",
      "Biotechnology",
      "Architecture"
    ],
    tuitionRange: {
      undergraduate: "€900 - €4,000 per year",
      postgraduate: "€1,000 - €6,000 per year"
    },
    livingCost: {
      range: "€12,000 - €15,000 per year",
      details: [
        { category: "Brussels", cost: "€1,000 - €1,300/month" },
        { category: "Other Cities", cost: "€800 - €1,000/month" },
        { category: "Accommodation", cost: "€400 - €700/month" },
        { category: "Food", cost: "€250 - €350/month" },
        { category: "Transport", cost: "€50 - €80/month" },
        { category: "Health Insurance", cost: "€50-100/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 overall",
      postgraduate: "6.5 overall"
    },
    visaProcess: {
      type: "Long-Stay Visa (D) + Residence Permit",
      processingTime: "4-8 weeks",
      fundsRequired: "€700-800/month proof (€8,500-10,000/year)",
      workRights: "20 hours/week during term",
      postStudyWork: "12-month job search permit",
      prPathway: "Work permit or professional card"
    },
    topCities: ["Brussels", "Antwerp", "Ghent", "Leuven", "Bruges", "Liège"],
    averageSalary: "€28,000 - €38,000 per year (graduate)",
    intakeMonths: ["September", "February"],
    applicationTimeline: "Apply 6 months before intake",
    scholarships: [
      {
        name: "VLIR-UOS Scholarship",
        eligibility: "Students from selected countries",
        amount: "Full funding for master's programs",
        deadline: "February"
      }
    ]
  },

  finland: {
    slug: "finland",
    name: "Finland",
    flag: "🇫🇮",
    overview: "Finland boasts one of the world's best education systems, known for innovation, equality, and student-centered learning. With stunning natural beauty and a high quality of life, Finland offers a unique study experience.",
    whyStudy: [
      "World's best education system",
      "Tuition-free for EU/EEA; affordable for others",
      "High English proficiency",
      "2-year post-study work permit",
      "Innovative teaching methods",
      "Beautiful natural environment",
      "Gender equality and safety"
    ],
    quickFacts: [
      { label: "Capital", value: "Helsinki" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Languages", value: "Finnish, Swedish, English" },
      { label: "Time Zone", value: "EET (UTC+2)" },
      { label: "Population", value: "5.5 million" },
      { label: "International Students", value: "30,000+" }
    ],
    topUniversities: [
      "University of Helsinki",
      "Aalto University",
      "University of Tampere",
      "University of Oulu",
      "Tampere University of Technology",
      "University of Turku",
      "LUT University",
      "University of Jyväskylä"
    ],
    popularPrograms: [
      "Education",
      "Design & Architecture",
      "Engineering",
      "Computer Science",
      "Environmental Science",
      "Business",
      "Game Development",
      "Nursing"
    ],
    tuitionRange: {
      undergraduate: "€8,000 - €18,000 per year (non-EU)",
      postgraduate: "€10,000 - €20,000 per year (non-EU)"
    },
    livingCost: {
      range: "€10,000 - €13,000 per year",
      details: [
        { category: "Helsinki", cost: "€900 - €1,200/month" },
        { category: "Other Cities", cost: "€700 - €900/month" },
        { category: "Accommodation", cost: "€400 - €700/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€50 - €80/month" },
        { category: "Health Insurance", cost: "€30-50/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 overall",
      postgraduate: "6.5 overall"
    },
    visaProcess: {
      type: "Residence Permit for Studies",
      processingTime: "1-3 months",
      fundsRequired: "€800/month proof (€9,600/year)",
      workRights: "30 hours/week during term",
      postStudyWork: "2-year residence permit for job search",
      prPathway: "Continuous residence permit pathway"
    },
    topCities: ["Helsinki", "Espoo", "Tampere", "Oulu", "Turku", "Jyväskylä"],
    averageSalary: "€30,000 - €40,000 per year (graduate)",
    intakeMonths: ["September", "January"],
    applicationTimeline: "Apply 6 months before intake",
    scholarships: [
      {
        name: "Finland Scholarship",
        eligibility: "Non-EU master's students",
        amount: "€5,000 + first year tuition waiver",
        deadline: "January"
      }
    ]
  },

  norway: {
    slug: "norway",
    name: "Norway",
    flag: "🇳🇴",
    overview: "Norway offers tuition-free education at public universities, making it an attractive destination for quality higher education. With stunning fjords, high living standards, and a strong focus on sustainability, Norway provides a unique study experience.",
    whyStudy: [
      "Tuition-free at public universities",
      "High quality of life",
      "Stunning natural landscapes",
      "Strong focus on sustainability",
      "2-year job search permit after studies",
      "High English proficiency",
      "Excellent work-life balance"
    ],
    quickFacts: [
      { label: "Capital", value: "Oslo" },
      { label: "Currency", value: "Norwegian Krone (NOK)" },
      { label: "Languages", value: "Norwegian, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "5.4 million" },
      { label: "International Students", value: "25,000+" }
    ],
    topUniversities: [
      "University of Oslo",
      "Norwegian University of Science and Technology",
      "University of Bergen",
      "University of Tromsø",
      "Norwegian School of Economics",
      "BI Norwegian Business School",
      "University of Stavanger",
      "NHH Norwegian School of Economics"
    ],
    popularPrograms: [
      "Marine Science",
      "Petroleum Engineering",
      "Renewable Energy",
      "Fisheries & Aquaculture",
      "Business",
      "Arctic Studies",
      "Environmental Science",
      "Shipping & Logistics"
    ],
    tuitionRange: {
      undergraduate: "Free (public universities) - NOK 100,000-150,000 (private)",
      postgraduate: "Free (public universities) - NOK 100,000-200,000 (private)"
    },
    livingCost: {
      range: "NOK 140,000 - 180,000 per year (€12,000-16,000)",
      details: [
        { category: "Oslo", cost: "NOK 12,000 - 15,000/month" },
        { category: "Other Cities", cost: "NOK 10,000 - 12,000/month" },
        { category: "Accommodation", cost: "NOK 5,000 - 8,000/month" },
        { category: "Food", cost: "NOK 3,000 - 4,000/month" },
        { category: "Transport", cost: "NOK 500 - 800/month" },
        { category: "Health Insurance", cost: "NOK 500-1,000/year" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "6.0 overall",
      postgraduate: "6.5 overall"
    },
    visaProcess: {
      type: "Student Residence Permit",
      processingTime: "2-4 months",
      fundsRequired: "NOK 14,000/month proof (NOK 128,000/year)",
      workRights: "Part-time during studies (no strict limit)",
      postStudyWork: "2-year permit for job search",
      prPathway: "Skilled worker permit leading to permanent residence"
    },
    topCities: ["Oslo", "Bergen", "Trondheim", "Stavanger", "Tromsø"],
    averageSalary: "NOK 500,000 - 650,000 per year (€45,000-58,000)",
    intakeMonths: ["August"],
    applicationTimeline: "Apply October-December for autumn intake",
    scholarships: [
      {
        name: "Quota Scheme (discontinued, alternatives available)",
        eligibility: "Check university-specific options",
        amount: "Varies",
        deadline: "Varies"
      },
      {
        name: "Norwegian-Russian Scholarship",
        eligibility: "Selected nationalities",
        amount: "Full or partial funding",
        deadline: "Varies"
      }
    ]
  },

  portugal: {
    slug: "portugal",
    name: "Portugal",
    flag: "🇵🇹",
    overview: "Portugal offers affordable education, a warm climate, and a welcoming culture. With growing tech hubs and a high quality of life, Portugal is becoming an increasingly popular destination for international students.",
    whyStudy: [
      "Affordable tuition and living costs",
      "Warm Mediterranean climate",
      "Growing tech and startup ecosystem",
      "1-year job search visa after graduation",
      "Safe and welcoming environment",
      "Beautiful beaches and historic cities",
      "English-taught programs increasing"
    ],
    quickFacts: [
      { label: "Capital", value: "Lisbon" },
      { label: "Currency", value: "Euro (EUR)" },
      { label: "Languages", value: "Portuguese, English" },
      { label: "Time Zone", value: "WET (UTC+0)" },
      { label: "Population", value: "10.3 million" },
      { label: "International Students", value: "60,000+" }
    ],
    topUniversities: [
      "University of Lisbon",
      "University of Porto",
      "University of Coimbra",
      "New University of Lisbon",
      "University of Aveiro",
      "University of Minho",
      "ISCTE - University Institute of Lisbon",
      "Catholic University of Portugal"
    ],
    popularPrograms: [
      "Business & Management",
      "Tourism & Hospitality",
      "Computer Science",
      "Marine Biology",
      "Architecture",
      "Wine Studies",
      "Medicine",
      "Social Sciences"
    ],
    tuitionRange: {
      undergraduate: "€3,000 - €7,000 per year (public universities)",
      postgraduate: "€4,000 - €10,000 per year (public universities)"
    },
    livingCost: {
      range: "€8,000 - €12,000 per year",
      details: [
        { category: "Lisbon/Porto", cost: "€800 - €1,200/month" },
        { category: "Other Cities", cost: "€600 - €900/month" },
        { category: "Accommodation", cost: "€350 - €700/month" },
        { category: "Food", cost: "€200 - €300/month" },
        { category: "Transport", cost: "€30 - €50/month" },
        { category: "Health Insurance", cost: "€30-50/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "5.5 - 6.0 overall",
      postgraduate: "6.0 - 6.5 overall"
    },
    visaProcess: {
      type: "Student Visa (Type D)",
      processingTime: "4-8 weeks",
      fundsRequired: "€600-800/month proof (€7,200-10,000/year)",
      workRights: "20 hours/week during term",
      postStudyWork: "Job search visa - up to 1 year",
      prPathway: "Work permit or Golden Visa program"
    },
    topCities: ["Lisbon", "Porto", "Coimbra", "Braga", "Faro", "Aveiro"],
    averageSalary: "€18,000 - €25,000 per year (graduate)",
    intakeMonths: ["September", "February"],
    applicationTimeline: "Apply 6 months before intake",
    scholarships: [
      {
        name: "Santander Universities Scholarship",
        eligibility: "International students",
        amount: "€3,000 - €5,000",
        deadline: "Varies"
      },
      {
        name: "Portuguese Government Scholarships",
        eligibility: "Selected nationalities",
        amount: "Variable",
        deadline: "Varies"
      }
    ]
  },

  hungary: {
    slug: "hungary",
    name: "Hungary",
    flag: "🇭🇺",
    overview: "Hungary offers affordable, high-quality education in the heart of Europe. Known for its strong programs in medicine, engineering, and sciences, Hungary has become an increasingly popular destination for Indian students seeking European degrees at a fraction of the cost compared to Western Europe.",
    whyStudy: [
      "Affordable tuition fees compared to Western Europe",
      "High-quality education with EU-recognized degrees",
      "Low cost of living",
      "Strong medical and engineering programs",
      "Vibrant student life in historic cities",
      "Central European location for travel",
      "Growing Indian student community",
      "English-taught programs available"
    ],
    quickFacts: [
      { label: "Capital", value: "Budapest" },
      { label: "Currency", value: "Hungarian Forint (HUF)" },
      { label: "Language", value: "Hungarian, English" },
      { label: "Time Zone", value: "CET (UTC+1)" },
      { label: "Population", value: "9.6 million" },
      { label: "International Students", value: "40,000+" }
    ],
    topUniversities: [
      "Eötvös Loránd University (ELTE)",
      "University of Szeged",
      "University of Debrecen",
      "Budapest University of Technology and Economics",
      "Semmelweis University",
      "University of Pécs",
      "Corvinus University of Budapest",
      "Óbuda University"
    ],
    popularPrograms: [
      "Medicine & Dentistry",
      "Pharmacy",
      "Computer Science",
      "Engineering",
      "Business Administration",
      "Psychology",
      "Architecture",
      "Veterinary Medicine"
    ],
    tuitionRange: {
      undergraduate: "€2,500 - €8,000 per year (HUF 1,000,000 - 3,200,000)",
      postgraduate: "€3,000 - €10,000 per year (HUF 1,200,000 - 4,000,000)"
    },
    livingCost: {
      range: "€6,000 - €10,000 per year (HUF 2.4M - 4M)",
      details: [
        { category: "Budapest", cost: "€600 - €900/month (HUF 240K-360K)" },
        { category: "Other Cities", cost: "€400 - €600/month (HUF 160K-240K)" },
        { category: "Accommodation", cost: "€250 - €500/month" },
        { category: "Food", cost: "€150 - €250/month" },
        { category: "Transport", cost: "€25 - €40/month" },
        { category: "Health Insurance", cost: "€50-100/month" }
      ]
    },
    ieltsRequirements: {
      undergraduate: "5.5 - 6.0 overall (English programs)",
      postgraduate: "6.0 - 6.5 overall (English programs)"
    },
    visaProcess: {
      type: "Student Visa (D Visa) + Residence Permit",
      processingTime: "4-8 weeks",
      fundsRequired: "€8,000 - €10,000 per year proof (HUF 3.2M - 4M)",
      workRights: "24 hours/week during term, full-time during holidays",
      postStudyWork: "9-month job search permit after graduation",
      prPathway: "EU Blue Card or Hungarian permanent residence after employment"
    },
    topCities: ["Budapest", "Debrecen", "Szeged", "Pécs", "Győr", "Miskolc"],
    averageSalary: "€12,000 - €20,000 per year (HUF 4.8M - 8M)",
    intakeMonths: ["September", "February"],
    applicationTimeline: "Apply 4-6 months before intake",
    scholarships: [
      {
        name: "Stipendium Hungaricum",
        eligibility: "International students from partner countries including India",
        amount: "Full tuition waiver + monthly stipend + accommodation + medical insurance",
        deadline: "January"
      },
      {
        name: "Hungarian Diaspora Scholarship",
        eligibility: "Students of Hungarian heritage",
        amount: "Full tuition + monthly stipend",
        deadline: "January"
      },
      {
        name: "University-specific Scholarships",
        eligibility: "Academic excellence",
        amount: "10-50% tuition waiver",
        deadline: "Varies by university"
      }
    ]
  }
};

export const getCountryData = (slug: string): CountryData | null => {
  return countriesData[slug] || null;
};

export const getAllCountries = (): CountryData[] => {
  return Object.values(countriesData);
};
