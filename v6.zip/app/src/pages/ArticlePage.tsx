import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Calendar, User, Clock, Tag, Share2 } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Article } from "@/types";

export function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("kingsley_articles");
    if (stored) {
      const articles: Article[] = JSON.parse(stored);
      const found = articles.find((a) => a.slug === slug);
      setArticle(found || null);

      if (found) {
        // Find related articles
        const related = articles
          .filter(
            (a) =>
              a.id !== found.id &&
              (a.category === found.category ||
                a.tags?.some((t) => found.tags?.includes(t)))
          )
          .slice(0, 3);
        setRelatedArticles(related);
      }
    }
  }, [slug]);

  if (!article) {
    return (
      <div className="min-h-screen bg-cream">
        <Header />
        <div className="pt-32 text-center">
          <h1 className="text-2xl font-bold text-navy mb-4">Article Not Found</h1>
          <Link to="/blog">
            <Button>Back to Blog</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream">
      <Header />

      <main className="pt-28 pb-12">
        <div className="container-custom">
          <Link
            to="/blog"
            className="inline-flex items-center gap-2 text-gray-500 hover:text-gold mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Blog
          </Link>

          <article className="max-w-4xl mx-auto">
            {/* Header */}
            <header className="mb-8">
              <Badge className="mb-4">{article.category}</Badge>
              <h1 className="font-playfair text-3xl md:text-4xl font-bold text-navy mb-4">
                {article.title}
              </h1>

              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                <span className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  {article.author}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {new Date(article.date).toLocaleDateString()}
                </span>
                {article.readTime && (
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {article.readTime}
                  </span>
                )}
              </div>
            </header>

            {/* Content */}
            <div className="bg-white rounded-xl p-8 md:p-12 shadow-card mb-8">
              <div
                className="prose prose-lg max-w-none prose-headings:font-playfair prose-headings:text-navy prose-a:text-gold hover:prose-a:text-gold-dark"
                dangerouslySetInnerHTML={{
                  __html: article.content
                    .replace(/## (.*)/g, '<h2 class="text-2xl font-bold mt-8 mb-4">$1</h2>')
                    .replace(/\n\n/g, "</p><p class='mb-4'>")
                    .replace(/^/, "<p class='mb-4'>")
                    .replace(/$/, "</p>"),
                }}
              />
            </div>

            {/* Tags */}
            {article.tags && article.tags.length > 0 && (
              <div className="flex items-center gap-2 mb-8">
                <Tag className="w-4 h-4 text-gray-500" />
                {article.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            {/* Share */}
            <div className="flex items-center gap-4 p-4 bg-cream rounded-lg mb-12">
              <Share2 className="w-5 h-5 text-gray-500" />
              <span className="text-sm text-gray-600">Share this article:</span>
              <button
                onClick={() =>
                  window.open(
                    `https://twitter.com/intent/tweet?text=${encodeURIComponent(
                      article.title
                    )}&url=${encodeURIComponent(window.location.href)}`,
                    "_blank"
                  )
                }
                className="text-blue-400 hover:text-blue-500"
              >
                Twitter
              </button>
              <button
                onClick={() =>
                  window.open(
                    `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
                      window.location.href
                    )}`,
                    "_blank"
                  )
                }
                className="text-blue-700 hover:text-blue-800"
              >
                LinkedIn
              </button>
              <button
                onClick={() =>
                  window.open(
                    `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
                      window.location.href
                    )}`,
                    "_blank"
                  )
                }
                className="text-blue-600 hover:text-blue-700"
              >
                Facebook
              </button>
            </div>

            {/* Related Articles */}
            {relatedArticles.length > 0 && (
              <div className="mt-12">
                <h2 className="font-playfair text-2xl font-semibold text-navy mb-6">
                  Related Articles
                </h2>
                <div className="grid md:grid-cols-3 gap-6">
                  {relatedArticles.map((related) => (
                    <Link
                      key={related.id}
                      to={`/blog/${related.slug}`}
                      className="bg-white rounded-lg p-6 shadow-card card-hover"
                    >
                      <Badge variant="secondary" className="mb-2 text-xs">
                        {related.category}
                      </Badge>
                      <h3 className="font-semibold text-navy mb-2 line-clamp-2">
                        {related.title}
                      </h3>
                      <p className="text-gray-600 text-sm line-clamp-2">
                        {related.excerpt}
                      </p>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </article>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
