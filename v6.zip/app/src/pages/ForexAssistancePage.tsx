import { Link } from "react-router-dom";
import {
  Banknote,
  CreditCard,
  TrendingUp,
  FileText,
  CheckCircle,
  ArrowRight,
  Phone,
  Shield,
  Wallet,
  Globe,
  AlertCircle,
  Info,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SEO } from "@/components/SEO";

const forexServices = [
  {
    icon: Banknote,
    title: "Education Loan Assistance",
    description: "Guidance on securing education loans from top Indian banks and NBFCs at competitive interest rates.",
    features: [
      "Compare loan options from 15+ banks",
      "Documentation support",
      "Collateral vs non-collateral guidance",
      "Interest rate negotiation tips"
    ]
  },
  {
    icon: CreditCard,
    title: "Forex Card",
    description: "Get the best forex cards with zero issuance fees, competitive rates, and global acceptance.",
    features: [
      "Multi-currency cards",
      "Zero forex markup options",
      "Emergency card replacement",
      "Mobile app for tracking"
    ]
  },
  {
    icon: TrendingUp,
    title: "Currency Exchange",
    description: "Exchange currency at the best rates with authorized dealers and avoid airport exchange rip-offs.",
    features: [
      "Compare rates across dealers",
      "Lock-in favorable rates",
      "Home delivery available",
      "Buy-back guarantee"
    ]
  },
  {
    icon: Globe,
    title: "International Transfers",
    description: "Send money abroad for tuition and living expenses with lowest transfer fees and best exchange rates.",
    features: [
      "Wire transfer (SWIFT)",
      "Demand draft services",
      "Online transfer platforms",
      "University fee payment support"
    ]
  },
  {
    icon: FileText,
    title: "Proof of Funds Support",
    description: "Assistance with preparing and presenting financial documents for visa applications.",
    features: [
      "Bank statement guidance",
      "Affidavit of support",
      "Sponsorship letter templates",
      "Financial documentation review"
    ]
  },
  {
    icon: Shield,
    title: "Financial Security",
    description: "Protect your money abroad with insurance and emergency assistance services.",
    features: [
      "Travel insurance with financial coverage",
      "Emergency cash assistance",
      "Lost card protection",
      "Fraud monitoring"
    ]
  }
];

const loanBanks = [
  { name: "SBI", rate: "8.15% - 10.50%", maxAmount: "₹1.5 Crore" },
  { name: "HDFC Credila", rate: "9.50% - 12.50%", maxAmount: "₹50 Lakhs" },
  { name: "Axis Bank", rate: "9.99% - 13.50%", maxAmount: "₹75 Lakhs" },
  { name: "ICICI Bank", rate: "9.50% - 12.00%", maxAmount: "₹1 Crore" },
  { name: "Bank of Baroda", rate: "8.50% - 10.50%", maxAmount: "₹80 Lakhs" },
  { name: "PNB", rate: "8.55% - 11.00%", maxAmount: "₹75 Lakhs" },
];

const forexTips = [
  {
    title: "Load Forex Card Before Departure",
    description: "Load your forex card 2-3 days before departure when rates are favorable. Avoid last-minute airport exchanges."
  },
  {
    title: "Carry Multi-Currency Card",
    description: "If traveling through multiple countries or with stopovers, a multi-currency card saves conversion fees."
  },
  {
    title: "Keep Some Cash Handy",
    description: "Carry $500-1000 in cash for immediate expenses upon arrival before you can access ATMs."
  },
  {
    title: "Notify Your Bank",
    description: "Inform your Indian bank about your travel to prevent card blocks when used abroad."
  },
  {
    title: "Track Exchange Rates",
    description: "Monitor rates for 2-3 weeks before your trip. Book when rates are favorable, not at the last minute."
  }
];

export function ForexAssistancePage() {
  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Forex & Education Loan Assistance | Kingsley International"
        description="Complete forex assistance for Indian students. Education loans, forex cards, currency exchange, and international money transfers at best rates."
      />
      <Header />

      {/* Hero Section */}
      <section className="pt-28 pb-16 bg-gradient-to-br from-[#0B1F3B] via-[#1a3a5c] to-[#0B1F3B]">
        <div className="container-custom">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C6A052]/20 rounded-full mb-6">
              <Banknote className="w-4 h-4 text-[#C6A052]" />
              <span className="text-[#C6A052] text-sm font-medium">Financial Services</span>
            </div>
            <h1 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
              Forex & Loan
              <span className="text-[#C6A052]"> Assistance</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              From education loans to forex cards, we help you manage your finances abroad. 
              Get the best exchange rates, lowest transfer fees, and expert guidance on funding your education.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact">
                <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                  Get Forex Quote
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a href="tel:+919999999999">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                  <Phone className="w-5 h-5 mr-2" />
                  Talk to Expert
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Our Services
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Complete Financial Solutions
            </h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Everything you need to manage your money while studying abroad
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {forexServices.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-card">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-[#C6A052]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#C6A052] transition-colors">
                    <service.icon className="w-7 h-7 text-[#C6A052] group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B] mb-3">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-[#C6A052] mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Education Loan Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
                Education Loans
              </span>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3 mb-6">
                Compare & Apply for Education Loans
              </h2>
              <p className="text-gray-600 mb-8 leading-relaxed">
                We help you find the best education loan options from top Indian banks. 
                Compare interest rates, loan amounts, and repayment terms to make an informed decision.
              </p>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b-2 border-[#C6A052]">
                      <th className="text-left py-3 px-4 font-semibold text-[#0B1F3B]">Bank</th>
                      <th className="text-left py-3 px-4 font-semibold text-[#0B1F3B]">Interest Rate</th>
                      <th className="text-left py-3 px-4 font-semibold text-[#0B1F3B]">Max Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loanBanks.map((bank, index) => (
                      <tr key={index} className="border-b border-gray-100">
                        <td className="py-3 px-4 font-medium">{bank.name}</td>
                        <td className="py-3 px-4 text-gray-600">{bank.rate}</td>
                        <td className="py-3 px-4 text-gray-600">{bank.maxAmount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 p-4 bg-[#F5F3EE] rounded-xl">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    <strong>Note:</strong> Interest rates are indicative and subject to change. 
                    Final rates depend on your credit profile, co-applicant, and collateral. 
                    Contact us for the most current rates and personalized guidance.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gradient-to-br from-[#0B1F3B] to-[#1a3a5c] rounded-2xl p-8 text-white">
                <Wallet className="w-10 h-10 text-[#C6A052] mb-4" />
                <h3 className="font-playfair text-2xl font-bold mb-4">
                  Loan Eligibility Checklist
                </h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Admission letter from recognized university</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Co-applicant (parent/guardian) with stable income</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Good academic record (60%+ in last exam)</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Collateral (for loans above ₹7.5 Lakhs)</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">KYC documents of applicant and co-applicant</p>
                  </div>
                </div>
              </div>

              <div className="bg-[#C6A052]/10 rounded-2xl p-8">
                <AlertCircle className="w-10 h-10 text-[#C6A052] mb-4" />
                <h3 className="font-playfair text-xl font-bold text-[#0B1F3B] mb-3">
                  Documents Required
                </h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Admission letter from university</li>
                  <li>• Fee structure from university</li>
                  <li>• Academic transcripts and certificates</li>
                  <li>• ID and address proof (Aadhar, PAN, Passport)</li>
                  <li>• Income proof of co-applicant (ITR, salary slips)</li>
                  <li>• Bank statements (6 months)</li>
                  <li>• Collateral documents (if applicable)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Forex Tips Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Money-Saving Tips
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Smart Forex Strategies
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {forexTips.map((tip, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-card">
                <div className="w-10 h-10 bg-[#C6A052] text-white rounded-full flex items-center justify-center mb-4 font-semibold">
                  {index + 1}
                </div>
                <h4 className="font-semibold text-[#0B1F3B] mb-2">{tip.title}</h4>
                <p className="text-sm text-gray-600">{tip.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Need Help with Forex or Loans?
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Our financial experts will guide you through the entire process, from loan application 
            to getting your forex card ready for departure.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                Get Free Consultation
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
