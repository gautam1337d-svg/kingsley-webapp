import { lazy, Suspense } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { SEO, organizationSchema } from "@/components/SEO";

// Lazy load sections for better performance
const Hero = lazy(() => import("@/sections/Hero").then(m => ({ default: m.Hero })));
const TrustStrip = lazy(() => import("@/sections/TrustStrip").then(m => ({ default: m.TrustStrip })));
const WhyKingsley = lazy(() => import("@/sections/WhyKingsley").then(m => ({ default: m.WhyKingsley })));
const DestinationsGrid = lazy(() => import("@/sections/DestinationsGrid").then(m => ({ default: m.DestinationsGrid })));
const ServicesOverview = lazy(() => import("@/sections/ServicesOverview").then(m => ({ default: m.ServicesOverview })));
const SuccessStoriesPreview = lazy(() => import("@/sections/SuccessStoriesPreview").then(m => ({ default: m.SuccessStoriesPreview })));
const CTABanner = lazy(() => import("@/sections/CTABanner").then(m => ({ default: m.CTABanner })));

// Section loader
function SectionLoader() {
  return (
    <div className="py-20 flex items-center justify-center">
      <div className="animate-spin w-8 h-8 border-2 border-[#C6A052] border-t-transparent rounded-full" />
    </div>
  );
}

export function HomePage() {
  return (
    <div className="min-h-screen">
      <SEO 
        title="Study Abroad Consultants | Kingsley International"
        description="Expert guidance for Indian students aspiring to study at top universities worldwide. 16+ countries, 400+ universities, 3,700+ programs. Free consultation available."
        schema={organizationSchema}
      />
      <Header />
      <main>
        <Suspense fallback={<SectionLoader />}>
          <Hero />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <TrustStrip />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <WhyKingsley />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <DestinationsGrid />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <ServicesOverview />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <SuccessStoriesPreview />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <CTABanner />
        </Suspense>
      </main>
      <Footer />
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
