import { useParams, Link } from "react-router-dom";
import {
  FileText,
  CheckCircle,
  AlertCircle,
  Clock,
  DollarSign,
  Briefcase,
  Users,
  ArrowLeft,
  ArrowRight,
  XCircle,
  Lightbulb,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { SEO, createFAQSchema } from "@/components/SEO";
import { getCountryData } from "@/data/countryData";
import { getCountryFlag } from "@/lib/utils";

// Extended visa information
const extendedVisaInfo: Record<string, {
  commonRejections: string[];
  successTips: string[];
  documentChecklist: string[];
  interviewTips: string[];
}> = {
  uk: {
    commonRejections: [
      "Insufficient funds or unclear financial documentation",
      "Failure to demonstrate genuine student intent",
      "Inadequate English language proficiency",
      "Incomplete or incorrect application form",
      "Missing or fraudulent documents",
      "Poor academic progression explanation",
    ],
    successTips: [
      "Maintain required funds in account for 28 consecutive days before application",
      "Provide clear evidence of ties to home country",
      "Ensure all documents are genuine and properly translated",
      "Prepare a genuine and convincing Statement of Purpose",
      "Apply well in advance of course start date",
    ],
    documentChecklist: [
      "Valid passport (valid for duration of stay)",
      "CAS (Confirmation of Acceptance for Studies)",
      "Financial evidence (bank statements/loan letter)",
      "TB test results (if applicable)",
      "English language test results",
      "Academic transcripts and certificates",
      "Passport-sized photographs",
      "ATAS certificate (if required for course)",
    ],
    interviewTips: [
      "Be honest and consistent in your answers",
      "Know your course details, university, and location",
      "Explain your career goals clearly",
      "Demonstrate genuine intent to study",
      "Show you can afford studies without working illegally",
    ],
  },
  ireland: {
    commonRejections: [
      "Insufficient proof of funds",
      "Lack of genuine study intent",
      "Poor academic background for chosen course",
      "Inadequate English proficiency",
      "Previous visa violations",
    ],
    successTips: [
      "Show €10,000 in funds for living expenses",
      "Demonstrate clear academic progression",
      "Provide detailed Statement of Purpose",
      "Apply early to avoid delays",
      "Ensure health insurance coverage",
    ],
    documentChecklist: [
      "Valid passport",
      "Letter of Acceptance from Irish institution",
      "Proof of payment of tuition fees",
      "Financial documentation (€10,000 minimum)",
      "English language proficiency proof",
      "Medical/travel insurance",
      "Academic transcripts",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Ireland specifically",
      "Show knowledge of your course curriculum",
      "Demonstrate post-study plans",
      "Be prepared to discuss finances in detail",
    ],
  },
  germany: {
    commonRejections: [
      "Insufficient funds in blocked account",
      "Inadequate academic preparation",
      "Language proficiency issues",
      "Unclear motivation for studying in Germany",
      "Incomplete documentation",
    ],
    successTips: [
      "Open blocked account with €11,208 before visa application",
      "Learn basic German even for English programs",
      "Research your university and city thoroughly",
      "Prepare strong motivation letter",
      "Apply at least 3 months before intake",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Blocked account confirmation (€11,208)",
      "Health insurance coverage",
      "Academic documents (translated and apostilled)",
      "Language proficiency proof",
      "Motivation letter",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Germany over other countries",
      "Show knowledge of German education system",
      "Demonstrate clear career plans post-study",
      "Be honest about your financial situation",
    ],
  },
  france: {
    commonRejections: [
      "Insufficient financial proof",
      "Inadequate accommodation proof",
      "Poor academic record",
      "Language proficiency concerns",
      "Incomplete Campus France procedure",
    ],
    successTips: [
      "Complete Campus France procedure first",
      "Show €615/month (€7,380/year) in funds",
      "Arrange accommodation before visa application",
      "Learn basic French phrases",
      "Prepare detailed study plan",
    ],
    documentChecklist: [
      "Valid passport",
      "Campus France acceptance",
      "University acceptance letter",
      "Proof of accommodation in France",
      "Financial proof (€615/month)",
      "Health insurance (EHIC or private)",
      "OFII form",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain your choice of France and specific program",
      "Show basic French language skills",
      "Demonstrate understanding of French culture",
      "Have clear post-study plans",
    ],
  },
  netherlands: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate English proficiency",
      "Unclear study motivation",
      "Previous immigration violations",
      "Incomplete application",
    ],
    successTips: [
      "Show €1,000/month (€12,000/year) in funds",
      "Apply for MVV and residence permit together",
      "Ensure university is recognized by NVAO",
      "Prepare detailed motivation letter",
      "Apply at least 3 months in advance",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Proof of funds (€12,000/year)",
      "Health insurance",
      "Tuberculosis test (if applicable)",
      "Birth certificate (legalized)",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why the Netherlands is right for you",
      "Show knowledge of Dutch education system",
      "Demonstrate clear career goals",
      "Be prepared for questions about finances",
    ],
  },
  italy: {
    commonRejections: [
      "Insufficient financial documentation",
      "Inadequate pre-enrollment procedure",
      "Poor academic background",
      "Language proficiency issues",
      "Incomplete documentation",
    ],
    successTips: [
      "Complete pre-enrollment at Italian embassy",
      "Show €450-600/month in funds",
      "Apply for Nulla Osta if required",
      "Prepare all documents with apostille",
      "Learn basic Italian",
    ],
    documentChecklist: [
      "Valid passport",
      "Pre-enrollment confirmation",
      "University admission letter",
      "Financial proof (€450-600/month)",
      "Health insurance",
      "Accommodation proof",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain your choice of Italy",
      "Show basic Italian language skills",
      "Demonstrate knowledge of Italian culture",
      "Have clear study and career plans",
    ],
  },
  spain: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate health insurance",
      "Unclear study motivation",
      "Incomplete documentation",
      "Language proficiency concerns",
    ],
    successTips: [
      "Show €600-800/month in funds",
      "Get comprehensive health insurance",
      "Complete all documentation with apostille",
      "Learn basic Spanish",
      "Apply at least 2 months in advance",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Financial proof (€600-800/month)",
      "Health insurance (full coverage)",
      "Medical certificate",
      "Police clearance certificate",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Spain",
      "Show basic Spanish skills",
      "Demonstrate understanding of Spanish culture",
      "Have clear post-study plans",
    ],
  },
  sweden: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate insurance coverage",
      "Incomplete application",
      "Previous immigration violations",
    ],
    successTips: [
      "Show SEK 9,450/month (SEK 85,000/year) in funds",
      "Get comprehensive health insurance",
      "Apply well in advance (2-3 months)",
      "Ensure all documents are properly translated",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Proof of funds (SEK 85,000/year)",
      "Health insurance",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain your choice of Sweden",
      "Show knowledge of Swedish education",
      "Demonstrate clear career goals",
      "Be honest about finances",
    ],
  },
  newzealand: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate genuine intent",
      "Health or character issues",
      "Incomplete documentation",
      "Previous visa violations",
    ],
    successTips: [
      "Show NZD 20,000/year for living expenses",
      "Provide detailed Statement of Purpose",
      "Get medical examination done early",
      "Ensure police clearance is recent",
      "Apply at least 6-8 weeks in advance",
    ],
    documentChecklist: [
      "Valid passport",
      "Offer of Place from NZ institution",
      "Proof of tuition payment",
      "Financial evidence (NZD 20,000/year)",
      "Medical certificate (if required)",
      "Police clearance certificate",
      "Health insurance",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose New Zealand",
      "Show knowledge of NZ education system",
      "Demonstrate genuine student intent",
      "Have clear post-study plans",
    ],
  },
  australia: {
    commonRejections: [
      "Insufficient Genuine Temporary Entrant (GTE) evidence",
      "Inadequate funds proof",
      "English proficiency issues",
      "Incomplete or fraudulent documents",
      "Previous visa violations",
    ],
    successTips: [
      "Provide strong GTE statement",
      "Show AUD 21,041/year for living expenses",
      "Get OSHC health insurance",
      "Ensure all documents are genuine",
      "Apply at least 6-8 weeks in advance",
    ],
    documentChecklist: [
      "Valid passport",
      "COE (Confirmation of Enrolment)",
      "GTE statement",
      "Financial evidence (AUD 21,041/year)",
      "OSHC health insurance",
      "English test results",
      "Academic transcripts",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain your ties to home country",
      "Show knowledge of Australian education",
      "Demonstrate genuine temporary intent",
      "Have clear post-study plans",
    ],
  },
  austria: {
    commonRejections: [
      "Insufficient funds in blocked account",
      "Inadequate German language skills",
      "Incomplete documentation",
      "Unclear study motivation",
    ],
    successTips: [
      "Open blocked account with €14,400/year",
      "Learn German to A2 level minimum",
      "Prepare all documents with apostille",
      "Apply at least 3 months in advance",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Blocked account confirmation",
      "Health insurance",
      "German language certificate (if required)",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Austria",
      "Show German language skills",
      "Demonstrate knowledge of Austrian culture",
      "Have clear study plans",
    ],
  },
  belgium: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate health insurance",
      "Incomplete documentation",
      "Unclear study motivation",
    ],
    successTips: [
      "Show €700-800/month in funds",
      "Get comprehensive health insurance",
      "Complete all documentation",
      "Apply at least 2 months in advance",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Financial proof (€700-800/month)",
      "Health insurance",
      "Medical certificate",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Belgium",
      "Show knowledge of Belgian education",
      "Demonstrate clear career goals",
      "Be prepared for multilingual questions",
    ],
  },
  finland: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate insurance",
      "Incomplete application",
      "Unclear study motivation",
    ],
    successTips: [
      "Show €800/month (€9,600/year) in funds",
      "Get comprehensive health insurance",
      "Apply early (1-3 months processing)",
      "Prepare detailed motivation letter",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Proof of funds (€9,600/year)",
      "Health insurance",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Finland",
      "Show knowledge of Finnish education",
      "Demonstrate clear career goals",
      "Be honest about finances",
    ],
  },
  norway: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate documentation",
      "Unclear study motivation",
      "Incomplete application",
    ],
    successTips: [
      "Show NOK 128,000/year in funds",
      "Apply very early (2-4 months processing)",
      "Prepare all documents carefully",
      "Have clear study and career plans",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Proof of funds (NOK 128,000/year)",
      "Health insurance",
      "Housing documentation",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Norway",
      "Show knowledge of Norwegian education",
      "Demonstrate clear career goals",
      "Be prepared for questions about finances",
    ],
  },
  portugal: {
    commonRejections: [
      "Insufficient funds proof",
      "Inadequate health insurance",
      "Incomplete documentation",
      "Unclear study motivation",
    ],
    successTips: [
      "Show €600-800/month in funds",
      "Get comprehensive health insurance",
      "Apply at least 2 months in advance",
      "Learn basic Portuguese",
    ],
    documentChecklist: [
      "Valid passport",
      "University admission letter",
      "Financial proof (€600-800/month)",
      "Health insurance",
      "Criminal record certificate",
      "Passport photographs",
    ],
    interviewTips: [
      "Explain why you chose Portugal",
      "Show basic Portuguese skills",
      "Demonstrate knowledge of Portuguese culture",
      "Have clear study plans",
    ],
  },
};

export function VisaPage() {
  const { countrySlug } = useParams<{ countrySlug: string }>();
  const countryData = countrySlug ? getCountryData(countrySlug) : null;
  const extendedInfo = countrySlug ? extendedVisaInfo[countrySlug] : null;
  const flag = countrySlug ? getCountryFlag(countrySlug) : "";

  if (!countryData || !extendedInfo) {
    return (
      <div className="min-h-screen bg-[#F5F3EE]">
        <Header />
        <div className="pt-32 text-center">
          <h1 className="text-2xl font-bold text-[#0B1F3B] mb-4">Visa Information Not Found</h1>
          <Link to="/visa-guidance">
            <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]">
              View All Visa Guides
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const faqData = [
    {
      question: `What is the processing time for a ${countryData.name} student visa?`,
      answer: `The processing time for a ${countryData.name} student visa is typically ${countryData.visaProcess.processingTime}.`,
    },
    {
      question: `How much funds do I need to show for a ${countryData.name} student visa?`,
      answer: `You need to show ${countryData.visaProcess.fundsRequired}.`,
    },
    {
      question: `Can I work while studying in ${countryData.name}?`,
      answer: `Yes, ${countryData.visaProcess.workRights}.`,
    },
  ];

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title={`${countryData.name} Student Visa Guide for Indians | Kingsley International`}
        description={`Complete guide to ${countryData.name} student visa: requirements, documents, processing time, fees & tips. Expert assistance available.`}
        schema={createFAQSchema(faqData)}
      />
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-[#0B1F3B]">
        <div className="container-custom">
          <Link to="/visa-guidance" className="inline-flex items-center gap-2 text-gray-400 hover:text-[#C6A052] mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Visa Guides
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-6xl">{flag}</span>
            <div>
              <h1 className="font-playfair text-3xl md:text-5xl font-bold text-white">
                {countryData.name} Student Visa
              </h1>
              <p className="text-[#C6A052] mt-2">Complete Guide for Indian Students</p>
            </div>
          </div>
        </div>
      </div>

      <main className="container-custom py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Key Information */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                Key Visa Information
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-5 h-5 text-[#C6A052]" />
                    <span className="text-sm text-gray-500">Visa Type</span>
                  </div>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.type}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5 text-[#C6A052]" />
                    <span className="text-sm text-gray-500">Processing Time</span>
                  </div>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.processingTime}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="w-5 h-5 text-[#C6A052]" />
                    <span className="text-sm text-gray-500">Funds Required</span>
                  </div>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.fundsRequired}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Briefcase className="w-5 h-5 text-[#C6A052]" />
                    <span className="text-sm text-gray-500">Work Rights</span>
                  </div>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.workRights}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-[#C6A052]" />
                    <span className="text-sm text-gray-500">Post-Study Work</span>
                  </div>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.postStudyWork}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-5 h-5 text-[#C6A052]" />
                    <span className="text-sm text-gray-500">PR Pathway</span>
                  </div>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.prPathway}</p>
                </div>
              </div>
            </section>

            {/* Document Checklist */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <CheckCircle className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Document Checklist
              </h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {extendedInfo.documentChecklist.map((doc, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600">{doc}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Common Rejection Reasons */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <XCircle className="w-6 h-6 inline mr-2 text-red-500" />
                Common Rejection Reasons
              </h2>
              <div className="space-y-3">
                {extendedInfo.commonRejections.map((reason, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{reason}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Success Tips */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <Lightbulb className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Visa Success Tips
              </h2>
              <div className="space-y-3">
                {extendedInfo.successTips.map((tip, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{tip}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Interview Tips */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                Interview Tips
              </h2>
              <div className="space-y-3">
                {extendedInfo.interviewTips.map((tip, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-[#C6A052] text-[#0B1F3B] rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                      {idx + 1}
                    </div>
                    <span className="text-gray-600">{tip}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* CTA */}
            <div className="bg-[#C6A052] rounded-xl p-6 text-[#0B1F3B]">
              <h3 className="font-playfair text-xl font-semibold mb-4">
                Need Visa Assistance?
              </h3>
              <p className="text-sm mb-4 opacity-90">
                Our visa experts have a 98% success rate. Let us help you navigate the {countryData.name} visa process.
              </p>
              <Link to="/contact">
                <Button className="w-full bg-[#0B1F3B] text-white hover:bg-[#1a3a5f] mb-3">
                  Get Expert Help
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <a
                href={`https://wa.me/919876543210?text=Hi, I need help with ${encodeURIComponent(countryData.name)} student visa`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" className="w-full border-[#0B1F3B] text-[#0B1F3B] hover:bg-[#0B1F3B] hover:text-white">
                  Chat on WhatsApp
                </Button>
              </a>
            </div>

            {/* Related Countries */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                Other Visa Guides
              </h3>
              <div className="space-y-2">
                {["uk", "ireland", "germany", "france", "australia", "canada"].filter(c => c !== countrySlug).slice(0, 5).map((c) => {
                  const data = getCountryData(c);
                  if (!data) return null;
                  return (
                    <Link
                      key={c}
                      to={`/visa/${c}`}
                      className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors"
                    >
                      <span>{getCountryFlag(c)}</span>
                      {data.name}
                    </Link>
                  );
                })}
              </div>
            </div>

            {/* Quick Links */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                Related Links
              </h3>
              <div className="space-y-2">
                <Link to={`/country/${countrySlug}`} className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <FileText className="w-4 h-4" />
                  About {countryData.name}
                </Link>
                <Link to="/scholarships" className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <DollarSign className="w-4 h-4" />
                  Scholarships
                </Link>
                <Link to={`/find-your-course?country=${countrySlug}`} className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <Briefcase className="w-4 h-4" />
                  Browse Programs
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
