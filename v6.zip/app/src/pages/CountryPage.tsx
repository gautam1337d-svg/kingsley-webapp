import { useParams, Link } from "react-router-dom";
import {
  CheckCircle,
  FileText,
  GraduationCap,
  MapPin,
  DollarSign,
  Briefcase,
  Award,
  Building2,
  Calendar,
  ArrowRight,
  Globe,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useUniversities, usePrograms } from "@/hooks/useData";
import { getCountryFlag } from "@/lib/utils";
import { getCountryData } from "@/data/countryData";
import { SEO } from "@/components/SEO";

export function CountryPage() {
  const { slug } = useParams<{ slug: string }>();
  const { universities, loading: uniLoading } = useUniversities();
  const { programs, loading: progLoading } = usePrograms();

  const countrySlug = slug || "";
  const countryData = getCountryData(countrySlug);
  const flag = getCountryFlag(countrySlug);

  const countryUniversities = universities.filter(
    (u) => u.country === countrySlug
  );
  const countryPrograms = programs.filter((p) => p.country === countrySlug);

  // Get unique course areas
  const courseAreas = [
    ...new Set(countryPrograms.map((p) => p.courseArea?.replace(/^(UG_|PG_|PhD_)/, "")).filter(Boolean)),
  ].slice(0, 10);

  if (uniLoading || progLoading) {
    return (
      <div className="min-h-screen bg-[#F5F3EE]">
        <Header />
        <div className="pt-32 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#C6A052] border-t-transparent rounded-full mx-auto" />
          <p className="text-gray-600 mt-4">Loading country information...</p>
        </div>
      </div>
    );
  }

  if (!countryData) {
    return (
      <div className="min-h-screen bg-[#F5F3EE]">
        <Header />
        <div className="pt-32 text-center">
          <h1 className="text-2xl font-bold text-[#0B1F3B] mb-4">Country Not Found</h1>
          <Link to="/find-your-course">
            <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]">
              Browse All Countries
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title={`Study in ${countryData.name} for Indian Students | Kingsley International`}
        description={`Explore top universities, courses, and scholarships in ${countryData.name}. Get expert guidance for Indian students. Tuition fees, living costs, visa process & more.`}
      />
      <Header />

      {/* Hero Section */}
      <div className="pt-28 pb-12 bg-[#0B1F3B]">
        <div className="container-custom">
          <div className="flex items-center gap-4 mb-4">
            <span className="text-6xl">{flag}</span>
            <div>
              <h1 className="font-playfair text-3xl md:text-5xl font-bold text-white">
                Study in {countryData.name}
              </h1>
              <p className="text-[#C6A052] mt-2">
                {countryUniversities.length} Universities • {countryPrograms.length} Programs
              </p>
            </div>
          </div>
          <p className="text-gray-300 max-w-3xl mt-4 text-lg">
            {countryData.overview}
          </p>
        </div>
      </div>

      <main className="container-custom py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Why Study Here */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                Why Study in {countryData.name}?
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {countryData.whyStudy.map((reason, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600">{reason}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Quick Facts */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                Quick Facts
              </h2>
              <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
                {countryData.quickFacts.map((fact, idx) => (
                  <div key={idx} className="bg-[#F5F3EE] rounded-lg p-4">
                    <p className="text-sm text-gray-500">{fact.label}</p>
                    <p className="font-semibold text-[#0B1F3B]">{fact.value}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Tuition & Living Costs */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <DollarSign className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Tuition & Living Costs
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-[#0B1F3B] mb-3">Tuition Fees</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between p-3 bg-[#F5F3EE] rounded-lg">
                      <span className="text-gray-600">Undergraduate</span>
                      <span className="font-semibold text-[#0B1F3B]">{countryData.tuitionRange.undergraduate}</span>
                    </div>
                    <div className="flex justify-between p-3 bg-[#F5F3EE] rounded-lg">
                      <span className="text-gray-600">Postgraduate</span>
                      <span className="font-semibold text-[#0B1F3B]">{countryData.tuitionRange.postgraduate}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-[#0B1F3B] mb-3">Living Costs</h3>
                  <p className="text-gray-600 mb-3">{countryData.livingCost.range}</p>
                  <div className="space-y-1 text-sm">
                    {countryData.livingCost.details.slice(0, 4).map((item, idx) => (
                      <div key={idx} className="flex justify-between">
                        <span className="text-gray-500">{item.category}</span>
                        <span className="text-[#0B1F3B]">{item.cost}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            {/* IELTS Requirements */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <Globe className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                English Language Requirements (IELTS)
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Undergraduate</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.ieltsRequirements.undergraduate}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Postgraduate</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.ieltsRequirements.postgraduate}</p>
                </div>
              </div>
            </section>

            {/* Visa Information */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <FileText className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Student Visa Information
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Visa Type</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.type}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Processing Time</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.processingTime}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Funds Required</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.fundsRequired}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Work Rights</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.workRights}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Post-Study Work</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.postStudyWork}</p>
                </div>
                <div className="p-4 bg-[#F5F3EE] rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">PR Pathway</p>
                  <p className="font-semibold text-[#0B1F3B]">{countryData.visaProcess.prPathway}</p>
                </div>
              </div>
              <div className="mt-4">
                <Link to={`/visa/${countrySlug}`}>
                  <Button variant="outline" className="border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]">
                    View Detailed Visa Guide
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </section>

            {/* Top Universities */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <div className="flex justify-between items-center mb-6">
                <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B]">
                  <Building2 className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                  Top Universities
                </h2>
                <Link to={`/find-your-course?country=${countrySlug}`}>
                  <Button variant="outline" className="border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]">
                    View All
                  </Button>
                </Link>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {countryUniversities.slice(0, 6).map((uni) => (
                  <Link
                    key={uni.id}
                    to={`/university/${uni.id}`}
                    className="p-4 border rounded-lg hover:border-[#C6A052] hover:shadow-md transition-all"
                  >
                    <h3 className="font-semibold text-[#0B1F3B] mb-1">{uni.name}</h3>
                    <p className="text-sm text-gray-500">
                      {uni.city} • {uni.type}
                    </p>
                  </Link>
                ))}
              </div>
            </section>

            {/* Popular Programs */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <GraduationCap className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Popular Programs
              </h2>
              <div className="flex flex-wrap gap-2">
                {countryData.popularPrograms.map((program, idx) => (
                  <Link
                    key={idx}
                    to={`/find-your-course?country=${countrySlug}&area=${encodeURIComponent(program)}`}
                  >
                    <Badge
                      variant="outline"
                      className="cursor-pointer hover:bg-[#C6A052] hover:text-[#0B1F3B] hover:border-[#C6A052] px-3 py-1"
                    >
                      {program}
                    </Badge>
                  </Link>
                ))}
              </div>
            </section>

            {/* Top Cities & Salary */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <MapPin className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Top Cities & Career Prospects
              </h2>
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-[#0B1F3B] mb-3">Popular Student Cities</h3>
                  <div className="flex flex-wrap gap-2">
                    {countryData.topCities.map((city, idx) => (
                      <Badge key={idx} variant="secondary" className="bg-[#F5F3EE]">
                        {city}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-[#0B1F3B] mb-3">Average Graduate Salary</h3>
                  <p className="text-2xl font-bold text-[#C6A052]">{countryData.averageSalary}</p>
                </div>
              </div>
            </section>

            {/* Intake & Timeline */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <Calendar className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Intake & Application Timeline
              </h2>
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-[#0B1F3B] mb-3">Intake Months</h3>
                  <div className="flex flex-wrap gap-2">
                    {countryData.intakeMonths.map((month, idx) => (
                      <Badge key={idx} className="bg-[#C6A052] text-[#0B1F3B]">
                        {month}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-[#0B1F3B] mb-3">When to Apply</h3>
                  <p className="text-gray-600">{countryData.applicationTimeline}</p>
                </div>
              </div>
            </section>

            {/* Scholarships */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                <Award className="w-6 h-6 inline mr-2 text-[#C6A052]" />
                Scholarships Available
              </h2>
              <div className="space-y-4">
                {countryData.scholarships.map((scholarship, idx) => (
                  <div key={idx} className="p-4 bg-[#F5F3EE] rounded-lg">
                    <h3 className="font-semibold text-[#0B1F3B] mb-2">{scholarship.name}</h3>
                    <div className="grid sm:grid-cols-3 gap-2 text-sm">
                      <div>
                        <span className="text-gray-500">Eligibility:</span>
                        <p className="text-[#0B1F3B]">{scholarship.eligibility}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Amount:</span>
                        <p className="text-[#0B1F3B]">{scholarship.amount}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Deadline:</span>
                        <p className="text-[#0B1F3B]">{scholarship.deadline}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Link to="/scholarships">
                  <Button variant="outline" className="border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]">
                    View All Scholarships
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-[#C6A052] rounded-xl p-6 text-[#0B1F3B]">
              <h3 className="font-playfair text-xl font-semibold mb-4">
                Ready to Study in {countryData.name}?
              </h3>
              <p className="text-sm mb-4 opacity-90">
                Our experts can guide you through the entire process from university selection to visa approval.
              </p>
              <Link to="/contact">
                <Button className="w-full bg-[#0B1F3B] text-white hover:bg-[#1a3a5f] mb-3">
                  Book Free Consultation
                </Button>
              </Link>
              <a
                href={`https://wa.me/919876543210?text=Hi, I'm interested in studying in ${encodeURIComponent(countryData.name)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" className="w-full border-[#0B1F3B] text-[#0B1F3B] hover:bg-[#0B1F3B] hover:text-white">
                  Chat on WhatsApp
                </Button>
              </a>
            </div>

            {/* Course Areas */}
            {courseAreas.length > 0 && (
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                  Browse by Course Area
                </h3>
                <div className="flex flex-wrap gap-2">
                  {courseAreas.map((area, idx) => (
                    <Link
                      key={idx}
                      to={`/find-your-course?country=${countrySlug}&area=${encodeURIComponent(area)}`}
                    >
                      <Badge
                        variant="outline"
                        className="cursor-pointer hover:bg-[#C6A052] hover:text-[#0B1F3B] hover:border-[#C6A052]"
                      >
                        {area}
                      </Badge>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Related Links */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                Quick Links
              </h3>
              <div className="space-y-2">
                <Link to={`/visa/${countrySlug}`} className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <FileText className="w-4 h-4" />
                  Visa Guide
                </Link>
                <Link to="/scholarships" className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <Award className="w-4 h-4" />
                  Scholarships
                </Link>
                <Link to={`/find-your-course?country=${countrySlug}`} className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <GraduationCap className="w-4 h-4" />
                  Browse Programs
                </Link>
                <Link to="/contact" className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <Briefcase className="w-4 h-4" />
                  Book Consultation
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
