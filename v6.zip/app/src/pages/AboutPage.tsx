import { Link } from "react-router-dom";
import {
  Target,
  Eye,
  Heart,
  Users,
  Globe,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";

const values = [
  {
    icon: Heart,
    title: "Student-First Approach",
    description:
      "Every decision we make is guided by what's best for our students and their future success.",
  },
  {
    icon: Target,
    title: "Excellence",
    description:
      "We strive for excellence in every aspect of our service, from counselling to application support.",
  },
  {
    icon: Users,
    title: "Integrity",
    description:
      "We believe in transparent, honest communication and ethical practices in all our dealings.",
  },
  {
    icon: Globe,
    title: "Global Perspective",
    description:
      "We bring a worldwide outlook to help students succeed in an increasingly connected world.",
  },
];

const milestones = [
  { year: "2010", event: "Kingsley International founded in Bangalore" },
  { year: "2012", event: "Expanded to 50+ university partnerships" },
  { year: "2015", event: "Crossed 1,000 successful student placements" },
  { year: "2018", event: "Opened offices in Delhi and Mumbai" },
  { year: "2020", event: "Launched virtual counselling services" },
  { year: "2023", event: "Reached 10,000+ students helped milestone" },
];

export function AboutPage() {
  return (
    <div className="min-h-screen bg-cream">
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-navy">
        <div className="container-custom text-center">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            About Kingsley International
          </h1>
          <p className="text-gray-300 max-w-3xl mx-auto">
            Your trusted partner in transforming study abroad dreams into reality.
            With over a decade of experience, we've helped thousands of Indian
            students achieve their global education goals.
          </p>
        </div>
      </div>

      <main>
        {/* Mission & Vision */}
        <section className="section-padding">
          <div className="container-custom">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl p-8 shadow-card">
                <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-6">
                  <Target className="w-7 h-7 text-gold" />
                </div>
                <h2 className="font-playfair text-2xl font-semibold text-navy mb-4">
                  Our Mission
                </h2>
                <p className="text-gray-600 leading-relaxed">
                  To empower Indian students with the guidance, resources, and
                  support they need to access world-class education opportunities
                  abroad. We are committed to making the study abroad journey
                  smooth, transparent, and successful for every student we serve.
                </p>
              </div>

              <div className="bg-white rounded-xl p-8 shadow-card">
                <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-6">
                  <Eye className="w-7 h-7 text-gold" />
                </div>
                <h2 className="font-playfair text-2xl font-semibold text-navy mb-4">
                  Our Vision
                </h2>
                <p className="text-gray-600 leading-relaxed">
                  To be India's most trusted and respected study abroad consultancy,
                  known for our student-first approach, ethical practices, and
                  exceptional success rate. We envision a future where every Indian
                  student can access global education opportunities regardless of
                  their background.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="section-padding bg-white">
          <div className="container-custom">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="font-playfair text-3xl font-semibold text-navy mb-4">
                Our Core Values
              </h2>
              <p className="text-gray-600">
                These principles guide everything we do at Kingsley International.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, idx) => (
                <div key={idx} className="text-center p-6">
                  <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-gold" />
                  </div>
                  <h3 className="font-playfair text-lg font-semibold text-navy mb-2">
                    {value.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-16 bg-gold">
          <div className="container-custom">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <p className="text-4xl font-bold text-navy mb-1">10,000+</p>
                <p className="text-navy/70">Students Helped</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-navy mb-1">400+</p>
                <p className="text-navy/70">Partner Universities</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-navy mb-1">16</p>
                <p className="text-navy/70">Countries</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-navy mb-1">98%</p>
                <p className="text-navy/70">Success Rate</p>
              </div>
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="section-padding">
          <div className="container-custom">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="font-playfair text-3xl font-semibold text-navy mb-4">
                Our Journey
              </h2>
              <p className="text-gray-600">
                From a small consultancy to a leading name in overseas education.
              </p>
            </div>

            <div className="max-w-3xl mx-auto">
              {milestones.map((milestone, idx) => (
                <div key={idx} className="flex gap-6 mb-8 last:mb-0">
                  <div className="flex flex-col items-center">
                    <div className="w-4 h-4 bg-gold rounded-full" />
                    {idx < milestones.length - 1 && (
                      <div className="w-0.5 flex-1 bg-gold/30 mt-2" />
                    )}
                  </div>
                  <div className="pb-8">
                    <span className="text-gold font-bold">{milestone.year}</span>
                    <p className="text-gray-600 mt-1">{milestone.event}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-navy">
          <div className="container-custom text-center">
            <h2 className="font-playfair text-3xl font-semibold text-white mb-4">
              Start Your Journey With Us
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto mb-8">
              Let us help you achieve your dream of studying abroad. Book a free
              consultation today.
            </p>
            <Link to="/contact">
              <Button className="btn-primary">Book Free Consultation</Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
