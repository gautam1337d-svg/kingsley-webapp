import { useState, useMemo, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import {
  Search,
  Filter,
  MapPin,
  GraduationCap,
  BookOpen,
  X,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  IndianRupee,
  Clock,
  Calendar,
  Languages,
  AlertCircle,
  Loader2,
  ArrowUpDown,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { usePrograms } from "@/hooks/useData";
import { useCurrency } from "@/contexts/CurrencyContext";
import { getCountryFlag } from "@/lib/utils";
import { 
  studyLevelOptions, 
  courseAreaOptions, 
  countryOptions,
  matchesCourseArea, 
  matchesStudyLevel 
} from "@/lib/normalizeData";
import { SEO } from "@/components/SEO";

const ITEMS_PER_PAGE = 9;

// Tuition range options in INR (lakhs)
const tuitionRanges = [
  { value: "all", label: "All Ranges", min: 0, max: Infinity },
  { value: "0-10", label: "Under ₹10 Lakhs", min: 0, max: 1000000 },
  { value: "10-20", label: "₹10 - ₹20 Lakhs", min: 1000000, max: 2000000 },
  { value: "20-30", label: "₹20 - ₹30 Lakhs", min: 2000000, max: 3000000 },
  { value: "30-40", label: "₹30 - ₹40 Lakhs", min: 3000000, max: 4000000 },
  { value: "40+", label: "₹40 Lakhs+", min: 4000000, max: Infinity },
];

type SortOption = "relevance" | "tuition-low" | "tuition-high";

// Error Boundary Component
function ErrorFallback({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <Header />
      <div className="pt-32 pb-20 text-center">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-4">
          Something went wrong
        </h2>
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          {error.message || "An error occurred while loading programs."}
        </p>
        <Button 
          onClick={reset}
          className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
        >
          Try Again
        </Button>
      </div>
      <Footer />
    </div>
  );
}

export function FindYourCoursePage() {
  const [error, setError] = useState<Error | null>(null);
  
  if (error) {
    return <ErrorFallback error={error} reset={() => setError(null)} />;
  }

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Find the Perfect Course for Indian Students | Kingsley International"
        description="Search through 3,700+ programs across 400+ universities in 16 countries. Filter by destination, study level, course area, and budget in INR."
      />
      <Header />
      <FindYourCourseContent onError={setError} />
      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}

function FindYourCourseContent({ onError }: { onError: (error: Error) => void }) {
  const { programs, loading: programsLoading, error: programsError } = usePrograms();
  const { convertToINR, formatINR, isReady: currencyReady, loading: currencyLoading } = useCurrency();

  // Filter states (state-driven, NOT URL-driven)
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedLevel, setSelectedLevel] = useState("");
  const [selectedArea, setSelectedArea] = useState("");
  const [selectedTuitionRange, setSelectedTuitionRange] = useState("all");
  const [sortBy, setSortBy] = useState<SortOption>("relevance");
  const [currentPage, setCurrentPage] = useState(1);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCountry, selectedLevel, selectedArea, selectedTuitionRange, searchQuery, sortBy]);

  // Handle programs error
  useEffect(() => {
    if (programsError) {
      onError(new Error(programsError));
    }
  }, [programsError, onError]);

  // Enrich programs with INR tuition
  const enrichedPrograms = useMemo(() => {
    if (!programs || programs.length === 0) return [];
    
    return programs.map((program) => {
      const tuitionAmount = typeof program.tuitionPerYear === "string" 
        ? parseFloat(program.tuitionPerYear) 
        : program.tuitionPerYear;
      
      const tuitionInINR = convertToINR(tuitionAmount, program.tuitionCurrency || "USD");
      
      return {
        ...program,
        tuitionAmount,
        tuitionInINR,
      };
    });
  }, [programs, convertToINR]);

  // Filter programs with proper matching logic
  const filteredPrograms = useMemo(() => {
    if (!enrichedPrograms || enrichedPrograms.length === 0) return [];
    
    try {
      return enrichedPrograms.filter((program) => {
        // Country filter - exact match on slug
        if (selectedCountry && program.country !== selectedCountry) return false;
        
        // Study level filter - use normalized matching
        if (selectedLevel && !matchesStudyLevel(program.studyLevel, selectedLevel)) {
          return false;
        }
        
        // Course area filter - use normalized matching
        if (selectedArea && !matchesCourseArea(program.courseArea, selectedArea)) {
          return false;
        }
        
        // Tuition range filter (INR based)
        if (selectedTuitionRange && selectedTuitionRange !== "all") {
          const range = tuitionRanges.find(r => r.value === selectedTuitionRange);
          if (range && program.tuitionInINR !== null && program.tuitionInINR !== undefined) {
            if (program.tuitionInINR < range.min || program.tuitionInINR > range.max) {
              return false;
            }
          }
        }
        
        // Search query filter
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          const matchesName = program.programName?.toLowerCase().includes(query);
          const matchesUni = program.universityName?.toLowerCase().includes(query);
          const matchesArea = program.courseArea?.toLowerCase().includes(query);
          if (!matchesName && !matchesUni && !matchesArea) return false;
        }
        
        return true;
      });
    } catch (err) {
      console.error("Filter error:", err);
      return [];
    }
  }, [enrichedPrograms, selectedCountry, selectedLevel, selectedArea, selectedTuitionRange, searchQuery]);

  // Sort programs
  const sortedPrograms = useMemo(() => {
    if (!filteredPrograms || filteredPrograms.length === 0) return [];
    
    const sorted = [...filteredPrograms];
    
    switch (sortBy) {
      case "tuition-low":
        sorted.sort((a, b) => (a.tuitionInINR || Infinity) - (b.tuitionInINR || Infinity));
        break;
      case "tuition-high":
        sorted.sort((a, b) => (b.tuitionInINR || 0) - (a.tuitionInINR || 0));
        break;
      default:
        // Relevance - no specific sort
        break;
    }
    
    return sorted;
  }, [filteredPrograms, sortBy]);

  // Pagination
  const totalPages = Math.ceil(sortedPrograms.length / ITEMS_PER_PAGE);
  const paginatedPrograms = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return sortedPrograms.slice(start, start + ITEMS_PER_PAGE);
  }, [sortedPrograms, currentPage]);

  const clearFilters = useCallback(() => {
    setSelectedCountry("");
    setSelectedLevel("");
    setSelectedArea("");
    setSelectedTuitionRange("all");
    setSearchQuery("");
    setSortBy("relevance");
    setCurrentPage(1);
  }, []);

  const activeFiltersCount = [
    selectedCountry,
    selectedLevel,
    selectedArea,
    selectedTuitionRange !== "all" ? selectedTuitionRange : "",
  ].filter(Boolean).length;

  const isLoading = programsLoading || (currencyLoading && !currencyReady);

  // Filter Sidebar Component
  const FilterSidebar = () => (
    <div className="space-y-6">
      {/* Search */}
      <div>
        <label className="block text-sm font-semibold text-[#0B1F3B] mb-2">
          <Search className="w-4 h-4 inline mr-1" />
          Search Programs
        </label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 border-gray-300 focus:border-[#C6A052] focus:ring-[#C6A052]"
          />
        </div>
      </div>

      {/* Country Filter */}
      <div>
        <label className="block text-sm font-semibold text-[#0B1F3B] mb-2">
          <MapPin className="w-4 h-4 inline mr-1" />
          Study Destination
        </label>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
            <input
              type="radio"
              name="country"
              value=""
              checked={selectedCountry === ""}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="text-[#C6A052] focus:ring-[#C6A052]"
            />
            <span className="text-sm text-gray-700">All Countries</span>
          </label>
          {countryOptions.map((country) => (
            <label key={country.value} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input
                type="radio"
                name="country"
                value={country.value}
                checked={selectedCountry === country.value}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="text-[#C6A052] focus:ring-[#C6A052]"
              />
              <span className="text-sm text-gray-700">{country.flag} {country.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Study Level Filter */}
      <div>
        <label className="block text-sm font-semibold text-[#0B1F3B] mb-2">
          <GraduationCap className="w-4 h-4 inline mr-1" />
          Study Level
        </label>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
            <input
              type="radio"
              name="level"
              value=""
              checked={selectedLevel === ""}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="text-[#C6A052] focus:ring-[#C6A052]"
            />
            <span className="text-sm text-gray-700">All Levels</span>
          </label>
          {studyLevelOptions.map((level) => (
            <label key={level.value} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input
                type="radio"
                name="level"
                value={level.value}
                checked={selectedLevel === level.value}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="text-[#C6A052] focus:ring-[#C6A052]"
              />
              <span className="text-sm text-gray-700">{level.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Course Area Filter */}
      <div>
        <label className="block text-sm font-semibold text-[#0B1F3B] mb-2">
          <BookOpen className="w-4 h-4 inline mr-1" />
          Course Area
        </label>
        <div className="space-y-2 max-h-56 overflow-y-auto">
          <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
            <input
              type="radio"
              name="area"
              value=""
              checked={selectedArea === ""}
              onChange={(e) => setSelectedArea(e.target.value)}
              className="text-[#C6A052] focus:ring-[#C6A052]"
            />
            <span className="text-sm text-gray-700">All Areas</span>
          </label>
          {courseAreaOptions.map((area) => (
            <label key={area.value} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input
                type="radio"
                name="area"
                value={area.value}
                checked={selectedArea === area.value}
                onChange={(e) => setSelectedArea(e.target.value)}
                className="text-[#C6A052] focus:ring-[#C6A052]"
              />
              <span className="text-sm text-gray-700">{area.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Tuition Range Filter */}
      <div>
        <label className="block text-sm font-semibold text-[#0B1F3B] mb-2">
          <IndianRupee className="w-4 h-4 inline mr-1" />
          Tuition Fee (INR)
          {currencyLoading && (
            <span className="ml-2 text-xs text-gray-400 font-normal">Loading rates...</span>
          )}
        </label>
        <div className="space-y-2">
          {tuitionRanges.map((range) => (
            <label key={range.value} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input
                type="radio"
                name="tuition"
                value={range.value}
                checked={selectedTuitionRange === range.value}
                onChange={(e) => setSelectedTuitionRange(e.target.value)}
                disabled={currencyLoading}
                className="text-[#C6A052] focus:ring-[#C6A052] disabled:opacity-50"
              />
              <span className={`text-sm ${currencyLoading ? "text-gray-400" : "text-gray-700"}`}>
                {range.label}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Clear Filters */}
      {activeFiltersCount > 0 && (
        <Button
          onClick={clearFilters}
          variant="outline"
          className="w-full border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]"
        >
          <X className="w-4 h-4 mr-2" />
          Clear All Filters
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      {/* Page Header */}
      <div className="pt-28 pb-6 bg-[#0B1F3B]">
        <div className="container-custom">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-2">
            Find Your Perfect Course
          </h1>
          <p className="text-gray-300 max-w-2xl">
            Search through {programs.length.toLocaleString()}+ programs across 400+ universities in 16
            countries. Filter by destination, study level, and budget in INR.
          </p>
        </div>
      </div>

      {/* Main Content - 30/70 Layout */}
      <div className="container-custom py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Left Sidebar - Filters (30%) */}
          <aside className="hidden lg:block lg:w-[30%]">
            <div className="bg-white rounded-xl shadow-card p-6 sticky top-28">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-lg text-[#0B1F3B]">
                  <Filter className="w-5 h-5 inline mr-2" />
                  Filters
                </h2>
                {activeFiltersCount > 0 && (
                  <Badge className="bg-[#C6A052] text-[#0B1F3B]">
                    {activeFiltersCount}
                  </Badge>
                )}
              </div>
              <FilterSidebar />
            </div>
          </aside>

          {/* Right Content - Results (70%) */}
          <main className="flex-1 lg:w-[70%]">
            
            {/* Mobile Filter Button */}
            <div className="lg:hidden mb-4">
              <Button
                onClick={() => setShowMobileFilters(true)}
                variant="outline"
                className="w-full gap-2 border-[#C6A052] text-[#C6A052]"
              >
                <Filter className="w-4 h-4" />
                Filters
                {activeFiltersCount > 0 && (
                  <Badge className="ml-1 bg-[#C6A052] text-[#0B1F3B]">
                    {activeFiltersCount}
                  </Badge>
                )}
              </Button>
            </div>

            {/* Mobile Filter Drawer */}
            {showMobileFilters && (
              <div className="fixed inset-0 z-50 lg:hidden">
                <div 
                  className="absolute inset-0 bg-black/50" 
                  onClick={() => setShowMobileFilters(false)}
                />
                <div className="absolute right-0 top-0 h-full w-80 bg-white shadow-xl overflow-y-auto p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-semibold text-lg text-[#0B1F3B]">Filters</h2>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowMobileFilters(false)}
                    >
                      <X className="w-5 h-5" />
                    </Button>
                  </div>
                  <FilterSidebar />
                </div>
              </div>
            )}

            {/* Results Header */}
            <div className="bg-white rounded-xl shadow-card p-4 mb-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <p className="text-gray-600">
                    Showing{" "}
                    <span className="font-semibold text-[#0B1F3B]">
                      {sortedPrograms.length}
                    </span>{" "}
                    programs
                    {sortedPrograms.length > 0 && (
                      <span className="text-gray-400 ml-1">
                        (Page {currentPage} of {totalPages || 1})
                      </span>
                    )}
                  </p>
                </div>
                
                {/* Sort Dropdown */}
                <div className="flex items-center gap-2">
                  <ArrowUpDown className="w-4 h-4 text-gray-500" />
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:border-[#C6A052] focus:ring-[#C6A052]"
                  >
                    <option value="relevance">Sort by Relevance</option>
                    <option value="tuition-low">Tuition: Low to High</option>
                    <option value="tuition-high">Tuition: High to Low</option>
                  </select>
                </div>
              </div>

              {/* Active Filters */}
              {activeFiltersCount > 0 && (
                <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t">
                  <span className="text-sm text-gray-500">Active filters:</span>
                  {selectedCountry && (
                    <Badge
                      className="gap-1 cursor-pointer bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
                      onClick={() => setSelectedCountry("")}
                    >
                      {getCountryFlag(selectedCountry)} {selectedCountry}
                      <X className="w-3 h-3" />
                    </Badge>
                  )}
                  {selectedLevel && (
                    <Badge
                      className="gap-1 cursor-pointer bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
                      onClick={() => setSelectedLevel("")}
                    >
                      {studyLevelOptions.find(l => l.value === selectedLevel)?.label || selectedLevel}
                      <X className="w-3 h-3" />
                    </Badge>
                  )}
                  {selectedArea && (
                    <Badge
                      className="gap-1 cursor-pointer bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
                      onClick={() => setSelectedArea("")}
                    >
                      {courseAreaOptions.find(a => a.value === selectedArea)?.label || selectedArea}
                      <X className="w-3 h-3" />
                    </Badge>
                  )}
                  {selectedTuitionRange !== "all" && (
                    <Badge
                      className="gap-1 cursor-pointer bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
                      onClick={() => setSelectedTuitionRange("all")}
                    >
                      {tuitionRanges.find(r => r.value === selectedTuitionRange)?.label}
                      <X className="w-3 h-3" />
                    </Badge>
                  )}
                  <button
                    onClick={clearFilters}
                    className="text-sm text-[#C6A052] hover:underline ml-2"
                  >
                    Clear all
                  </button>
                </div>
              )}
            </div>

            {/* Loading State */}
            {isLoading ? (
              <div className="text-center py-16 bg-white rounded-xl shadow-card">
                <Loader2 className="animate-spin w-10 h-10 text-[#C6A052] mx-auto mb-4" />
                <p className="text-gray-600">Loading programs...</p>
                {currencyLoading && (
                  <p className="text-sm text-gray-400 mt-2">Fetching exchange rates...</p>
                )}
              </div>
            ) : sortedPrograms.length === 0 ? (
              /* Empty State */
              <div className="text-center py-16 bg-white rounded-xl shadow-card">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-[#0B1F3B] mb-2">
                  No programs match your selection
                </h3>
                <p className="text-gray-500 mb-6 max-w-md mx-auto">
                  Try adjusting your filters or search query to find more programs.
                </p>
                <Button 
                  onClick={clearFilters}
                  className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
                >
                  Clear All Filters
                </Button>
              </div>
            ) : (
              /* Results Grid - 3 columns desktop, 2 tablet, 1 mobile */
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {paginatedPrograms.map((program) => (
                    <ProgramCard 
                      key={program.id} 
                      program={program} 
                      formatINR={formatINR}
                    />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center items-center gap-2 mt-8">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="border-gray-300 disabled:opacity-50"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </Button>
                    
                    <div className="flex gap-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter((page) => {
                          return (
                            page === 1 ||
                            page === totalPages ||
                            Math.abs(page - currentPage) <= 1
                          );
                        })
                        .map((page, idx, arr) => (
                          <div key={page} className="flex items-center">
                            {idx > 0 && arr[idx - 1] !== page - 1 && (
                              <span className="px-2 text-gray-400">...</span>
                            )}
                            <Button
                              variant={currentPage === page ? "default" : "outline"}
                              size="sm"
                              onClick={() => setCurrentPage(page)}
                              className={
                                currentPage === page
                                  ? "bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]"
                                  : "border-gray-300"
                              }
                            >
                              {page}
                            </Button>
                          </div>
                        ))}
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="border-gray-300 disabled:opacity-50"
                    >
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}

// Program Card Component
interface ProgramCardProps {
  program: {
    id: string;
    country: string;
    countryDisplay: string;
    studyLevel: string;
    universityName: string;
    universityId: string;
    programName: string;
    courseArea: string;
    intakeMonths: string;
    durationMonths: string | number;
    tuitionAmount: number;
    tuitionCurrency: string;
    tuitionInINR: number | null;
    englishRequirement: string;
  };
  formatINR: (amount: number | null) => string;
}

function ProgramCard({ program, formatINR }: ProgramCardProps) {
  const getStudyLevelBadge = (level: string) => {
    const normalized = level?.toUpperCase() || "";
    if (normalized.includes("UG")) return { label: "UG", color: "bg-blue-100 text-blue-800" };
    if (normalized.includes("PG")) return { label: "PG", color: "bg-green-100 text-green-800" };
    if (normalized.includes("PHD")) return { label: "PhD", color: "bg-purple-100 text-purple-800" };
    return { label: level, color: "bg-gray-100 text-gray-800" };
  };

  const levelBadge = getStudyLevelBadge(program.studyLevel);
  const courseAreaName = program.courseArea?.replace(/^(UG_|PG_|PhD_)/i, "") || "General";

  return (
    <div className="bg-white rounded-xl shadow-card hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col h-full">
      {/* Card Header */}
      <div className="p-5 flex-1">
        {/* Badges */}
        <div className="flex flex-wrap gap-2 mb-3">
          <Badge className={`text-xs ${levelBadge.color}`}>
            {levelBadge.label}
          </Badge>
          <Badge variant="outline" className="text-xs border-gray-300 text-gray-600">
            {getCountryFlag(program.country)} {program.countryDisplay}
          </Badge>
          <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-700">
            {courseAreaName}
          </Badge>
        </div>

        {/* Program Name */}
        <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-2 line-clamp-2">
          {program.programName}
        </h3>

        {/* University Name */}
        <Link
          to={`/university/${program.universityId}`}
          className="text-[#C6A052] hover:underline text-sm block mb-4 line-clamp-1"
        >
          {program.universityName}
        </Link>

        {/* Program Details */}
        <div className="space-y-2 text-sm">
          {program.durationMonths && (
            <div className="flex items-center gap-2 text-gray-600">
              <Clock className="w-4 h-4 text-gray-400" />
              <span>Duration: {program.durationMonths} months</span>
            </div>
          )}
          
          {program.intakeMonths && (
            <div className="flex items-center gap-2 text-gray-600">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span>Intake: {program.intakeMonths}</span>
            </div>
          )}
          
          {program.englishRequirement && (
            <div className="flex items-center gap-2 text-gray-600">
              <Languages className="w-4 h-4 text-gray-400" />
              <span>IELTS: {program.englishRequirement}</span>
            </div>
          )}
        </div>

        {/* Tuition */}
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="flex flex-col gap-1">
            <span className="text-xs text-gray-500">Approx. Tuition per year</span>
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-[#0B1F3B]">
                {formatINR(program.tuitionInINR)}
              </span>
              <span className="text-xs text-gray-400">
                ({program.tuitionCurrency} {program.tuitionAmount?.toLocaleString()})
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Card Footer - CTAs */}
      <div className="p-5 pt-0 mt-auto">
        <div className="flex flex-col gap-2">
          <Link to={`/university/${program.universityId}`}>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full gap-1 border-gray-300 hover:border-[#C6A052] hover:text-[#C6A052]"
            >
              View Details
              <ExternalLink className="w-4 h-4" />
            </Button>
          </Link>
          <Link to="/contact">
            <Button 
              size="sm" 
              className="w-full bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold"
            >
              Apply Now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
