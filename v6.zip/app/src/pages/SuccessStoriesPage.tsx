import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { MapPin, GraduationCap, Quote, Star, ArrowRight } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { SuccessStory } from "@/types";

// Default success stories
const defaultStories: SuccessStory[] = [
  {
    id: "1",
    name: "Priya Sharma",
    photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face",
    university: "University of Manchester",
    country: "United Kingdom",
    course: "MSc Data Science",
    year: "2023",
    quote:
      "Kingsley International made my dream of studying in the UK a reality. Their guidance throughout the application and visa process was invaluable.",
    fullStory:
      "I always dreamed of studying at a top UK university, but the process seemed overwhelming. Kingsley's team helped me at every step - from selecting the right program to preparing for my visa interview. Their personalized approach and attention to detail made all the difference.",
    results:
      "Secured admission with a 20% scholarship, visa approved in 15 days",
  },
  {
    id: "2",
    name: "Rahul Patel",
    photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face",
    university: "Technical University of Munich",
    country: "Germany",
    course: "MSc Mechanical Engineering",
    year: "2023",
    quote:
      "The team helped me secure admission to my dream university in Germany with a scholarship. I couldn't have done it without their support.",
    fullStory:
      "Germany's tuition-free education was a major draw for me, but navigating the application process was challenging. Kingsley's counsellors have deep knowledge of German universities and their requirements. They helped me prepare a strong application that stood out.",
    results: "Full scholarship + part-time job secured within first month",
  },
  {
    id: "3",
    name: "Ananya Reddy",
    photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face",
    university: "University of Melbourne",
    country: "Australia",
    course: "MBA",
    year: "2022",
    quote:
      "From shortlisting universities to visa approval, Kingsley was there at every step. Their expertise made the entire process smooth and stress-free.",
    fullStory:
      "As a working professional looking to pursue an MBA abroad, I needed guidance on programs that would fit my career goals. Kingsley helped me identify the right universities and prepared me for the GMAT and application essays.",
    results: "GMAT score improved by 120 points, 3 admits from top universities",
  },
  {
    id: "4",
    name: "Vikram Mehta",
    photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face",
    university: "University of Toronto",
    country: "Canada",
    course: "BSc Computer Science",
    year: "2023",
    quote:
      "The counselling team understood my goals perfectly and helped me choose a program that aligned with my career aspirations.",
    fullStory:
      "Coming from a non-CS background, I was worried about transitioning into Computer Science. Kingsley's team helped me identify foundation programs and bridge courses that would prepare me for the degree.",
    results: "Successfully transitioned to CS, internship at top tech company",
  },
  {
    id: "5",
    name: "Sneha Gupta",
    photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=face",
    university: "Trinity College Dublin",
    country: "Ireland",
    course: "MSc Biotechnology",
    year: "2022",
    quote:
      "Kingsley's expertise in European education helped me find the perfect program in Ireland. The post-study work opportunities are amazing!",
    fullStory:
      "I wanted to study biotechnology in Europe but was concerned about language barriers. Kingsley introduced me to Ireland's excellent English-taught programs and helped me secure a spot at Trinity College.",
    results: "Full-time research position after graduation",
  },
  {
    id: "6",
    name: "Arjun Nair",
    photoUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
    university: "Delft University of Technology",
    country: "Netherlands",
    course: "MSc Aerospace Engineering",
    year: "2023",
    quote:
      "The team's knowledge of Dutch universities and their application processes was exceptional. I'm now studying at one of the world's top engineering schools.",
    fullStory:
      "Aerospace Engineering is a niche field, and finding the right program was crucial. Kingsley's counsellors have in-depth knowledge of specialized programs and helped me craft a compelling application.",
    results: "Scholarship covering 50% of tuition fees",
  },
];

export function SuccessStoriesPage() {
  const [stories, setStories] = useState<SuccessStory[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("kingsley_stories");
    if (stored) {
      setStories(JSON.parse(stored));
    } else {
      setStories(defaultStories);
      localStorage.setItem("kingsley_stories", JSON.stringify(defaultStories));
    }
  }, []);

  return (
    <div className="min-h-screen bg-cream">
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-navy">
        <div className="container-custom text-center">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Success Stories
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Inspiring journeys of students who achieved their dream of studying
            abroad with our guidance and support.
          </p>
        </div>
      </div>

      <main className="container-custom py-12">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-xl p-6 text-center shadow-card">
            <p className="text-3xl font-bold text-gold mb-1">10,000+</p>
            <p className="text-gray-600 text-sm">Students Helped</p>
          </div>
          <div className="bg-white rounded-xl p-6 text-center shadow-card">
            <p className="text-3xl font-bold text-gold mb-1">98%</p>
            <p className="text-gray-600 text-sm">Success Rate</p>
          </div>
          <div className="bg-white rounded-xl p-6 text-center shadow-card">
            <p className="text-3xl font-bold text-gold mb-1">400+</p>
            <p className="text-gray-600 text-sm">Partner Universities</p>
          </div>
          <div className="bg-white rounded-xl p-6 text-center shadow-card">
            <p className="text-3xl font-bold text-gold mb-1">16</p>
            <p className="text-gray-600 text-sm">Countries</p>
          </div>
        </div>

        {/* Stories Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stories.map((story) => (
            <div
              key={story.id}
              className="bg-white rounded-xl overflow-hidden shadow-card card-hover"
            >
              <div className="p-6">
                <div className="flex items-center gap-4 mb-6">
                  <img
                    src={story.photoUrl}
                    alt={story.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-semibold text-navy">{story.name}</h3>
                    <div className="flex items-center gap-1 text-sm text-gray-500">
                      <MapPin className="w-3 h-3" />
                      {story.country}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <Badge variant="secondary" className="text-xs">
                    <GraduationCap className="w-3 h-3 mr-1" />
                    {story.course}
                  </Badge>
                  <span className="text-xs text-gray-500">{story.year}</span>
                </div>

                <div className="relative mb-4">
                  <Quote className="absolute -top-2 -left-2 w-8 h-8 text-gold/20" />
                  <p className="text-gray-600 text-sm italic pl-4">
                    "{story.quote}"
                  </p>
                </div>

                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-gold text-gold" />
                  ))}
                </div>

                {story.results && (
                  <div className="bg-cream rounded-lg p-3 mb-4">
                    <p className="text-xs text-gray-500 mb-1">Results:</p>
                    <p className="text-sm text-navy font-medium">
                      {story.results}
                    </p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 bg-gold rounded-xl p-8 md:p-12 text-center">
          <h2 className="font-playfair text-2xl md:text-3xl font-semibold text-navy mb-4">
            Be Our Next Success Story
          </h2>
          <p className="text-navy/70 max-w-2xl mx-auto mb-6">
            Let us help you achieve your dream of studying abroad. Book a free
            consultation today and start your journey.
          </p>
          <Link to="/contact">
            <Button className="bg-navy text-white hover:bg-navy-light">
              Book Free Consultation
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
