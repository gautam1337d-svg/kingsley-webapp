import { useParams, Link } from "react-router-dom";
import {
  MapPin,
  Globe,
  GraduationCap,
  CheckCircle,
  ExternalLink,
  ArrowLeft,
  Building2,
  Star,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useUniversityById, useProgramsByUniversity } from "@/hooks/useData";
import { getCountryFlag, formatCurrency } from "@/lib/utils";

export function UniversityPage() {
  const { id } = useParams<{ id: string }>();
  const { university, loading: uniLoading } = useUniversityById(id || "");
  const { programs, loading: progLoading } = useProgramsByUniversity(id || "");

  if (uniLoading || progLoading) {
    return (
      <div className="min-h-screen bg-cream">
        <Header />
        <div className="pt-32 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-gold border-t-transparent rounded-full mx-auto" />
        </div>
      </div>
    );
  }

  if (!university) {
    return (
      <div className="min-h-screen bg-cream">
        <Header />
        <div className="pt-32 text-center">
          <h1 className="text-2xl font-bold text-navy mb-4">
            University Not Found
          </h1>
          <Link to="/find-your-course">
            <Button>Browse All Universities</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  // Group programs by study level
  const programsByLevel = programs.reduce((acc, prog) => {
    const level = prog.studyLevel || "Other";
    if (!acc[level]) acc[level] = [];
    acc[level].push(prog);
    return acc;
  }, {} as Record<string, typeof programs>);

  // Get unique course areas
  const courseAreas = [
    ...new Set(programs.map((p) => p.courseArea).filter(Boolean)),
  ];

  return (
    <div className="min-h-screen bg-cream">
      <Header />

      {/* Hero Section */}
      <div className="pt-28 pb-12 bg-navy">
        <div className="container-custom">
          <Link
            to={`/country/${university.country}`}
            className="inline-flex items-center gap-2 text-gray-400 hover:text-gold mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to {university.countryDisplay}
          </Link>

          <div className="flex flex-col md:flex-row md:items-start gap-6">
            <div className="w-20 h-20 bg-white rounded-xl flex items-center justify-center text-4xl flex-shrink-0">
              {getCountryFlag(university.country)}
            </div>

            <div className="flex-1">
              <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-2">
                {university.name}
              </h1>

              <div className="flex flex-wrap items-center gap-4 text-gray-300 mb-4">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {university.city}, {university.countryDisplay}
                </span>
                {university.type && (
                  <Badge variant="secondary">{university.type}</Badge>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                {university.popularity && (
                  <Badge className="bg-gold text-navy">
                    <Star className="w-3 h-3 mr-1" />
                    {university.popularity} Popularity with Indian Students
                  </Badge>
                )}
                {university.costBand && (
                  <Badge variant="outline" className="text-white border-white/30">
                    <Building2 className="w-3 h-3 mr-1" />
                    {university.costBand} Cost
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="container-custom py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* About */}
            <section className="bg-white rounded-xl p-8 shadow-card">
              <h2 className="font-playfair text-2xl font-semibold text-navy mb-4">
                About {university.name}
              </h2>
              <p className="text-gray-600 leading-relaxed mb-6">
                {university.whySelected ||
                  `${university.name} is a ${university.type?.toLowerCase()} university located in ${university.city}, ${university.countryDisplay}. The university offers a wide range of programs for international students.`}
              </p>

              <div className="grid sm:grid-cols-2 gap-4">
                {university.studyLevels && (
                  <div className="flex items-start gap-3 p-4 bg-cream rounded-lg">
                    <GraduationCap className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-navy">Study Levels</p>
                      <p className="text-sm text-gray-600">
                        {university.studyLevels}
                      </p>
                    </div>
                  </div>
                )}

                {university.operationalConfidence && (
                  <div className="flex items-start gap-3 p-4 bg-cream rounded-lg">
                    <CheckCircle className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-navy">Our Assessment</p>
                      <p className="text-sm text-gray-600">
                        {university.operationalConfidence}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Programs */}
            {programs.length > 0 && (
              <section className="bg-white rounded-xl p-8 shadow-card">
                <h2 className="font-playfair text-2xl font-semibold text-navy mb-6">
                  Available Programs ({programs.length})
                </h2>

                <Accordion type="single" collapsible className="w-full">
                  {Object.entries(programsByLevel).map(([level, progs]) => (
                    <AccordionItem key={level} value={level}>
                      <AccordionTrigger className="text-navy font-semibold">
                        {level} ({progs.length})
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-3">
                          {progs.slice(0, 5).map((prog) => (
                            <div
                              key={prog.id}
                              className="p-4 border rounded-lg hover:border-gold transition-colors"
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h4 className="font-medium text-navy">
                                    {prog.programName}
                                  </h4>
                                  <div className="flex flex-wrap gap-3 mt-2 text-sm text-gray-600">
                                    {prog.courseArea && (
                                      <Badge variant="secondary" className="text-xs">
                                        {prog.courseArea}
                                      </Badge>
                                    )}
                                    {prog.durationMonths && (
                                      <span>{prog.durationMonths} months</span>
                                    )}
                                    {prog.tuitionPerYear && (
                                      <span>
                                        {formatCurrency(
                                          prog.tuitionPerYear,
                                          prog.tuitionCurrency || "USD"
                                        )}
                                        /year
                                      </span>
                                    )}
                                  </div>
                                  {prog.englishRequirement && (
                                    <p className="text-xs text-gray-500 mt-2">
                                      English: {prog.englishRequirement}
                                    </p>
                                  )}
                                </div>
                                <Link to="/contact">
                                  <Button size="sm" variant="outline">
                                    Apply
                                  </Button>
                                </Link>
                              </div>
                            </div>
                          ))}
                          {progs.length > 5 && (
                            <Link
                              to={`/find-your-course?country=${university.country}`}
                            >
                              <Button variant="ghost" className="w-full text-gold">
                                View All {progs.length} {level} Programs
                              </Button>
                            </Link>
                          )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </section>
            )}

            {/* Visa Notes */}
            {university.visaRiskNotes && (
              <section className="bg-amber-50 border border-amber-200 rounded-xl p-6">
                <h3 className="font-semibold text-amber-800 mb-2">
                  Visa Considerations
                </h3>
                <p className="text-amber-700 text-sm">
                  {university.visaRiskNotes}
                </p>
              </section>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-gold rounded-xl p-6 text-navy">
              <h3 className="font-playfair text-lg font-semibold mb-4">
                Interested in this University?
              </h3>
              <p className="text-sm mb-4">
                Our experts can guide you through the application process and
                help you secure admission.
              </p>
              <Link to="/contact">
                <Button className="w-full bg-navy text-white hover:bg-navy-light mb-3">
                  Apply Now
                </Button>
              </Link>
              <a
                href={`https://wa.me/919876543210?text=Hi, I'm interested in ${encodeURIComponent(
                  university.name
                )}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" className="w-full border-navy text-navy">
                  Chat on WhatsApp
                </Button>
              </a>
            </div>

            {/* Course Areas */}
            {courseAreas.length > 0 && (
              <div className="bg-white rounded-xl p-6 shadow-card">
                <h3 className="font-playfair text-lg font-semibold text-navy mb-4">
                  Course Areas
                </h3>
                <div className="flex flex-wrap gap-2">
                  {courseAreas.map((area, idx) => (
                    <Badge key={idx} variant="secondary">
                      {area}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Info */}
            <div className="bg-white rounded-xl p-6 shadow-card">
              <h3 className="font-playfair text-lg font-semibold text-navy mb-4">
                University Info
              </h3>
              <div className="space-y-4 text-sm">
                {university.sourceUrl && (
                  <a
                    href={university.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-gold hover:underline"
                  >
                    <Globe className="w-4 h-4" />
                    Official Website
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {university.lastChecked && (
                  <p className="text-gray-500">
                    Last updated: {university.lastChecked}
                  </p>
                )}
                {university.confidence && (
                  <p className="text-gray-500">
                    Data confidence: {university.confidence}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
