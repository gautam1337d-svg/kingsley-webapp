import { Link } from "react-router-dom";
import {
  ClipboardCheck,
  FileCheck,
  Globe,
  Briefcase,
  Landmark,
  Smartphone,
  Phone,
  CheckCircle,
  ArrowRight,
  AlertCircle,
  Info,
  Plane,
  BookOpen,
  Heart,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SEO } from "@/components/SEO";

const preDepartureServices = [
  {
    icon: ClipboardCheck,
    title: "Pre-Departure Checklist",
    description: "Comprehensive checklist to ensure you don't miss anything important before your flight.",
    features: [
      "Document verification checklist",
      "Packing essentials guide",
      "Medication and health preparations",
      "Financial setup checklist"
    ]
  },
  {
    icon: FileCheck,
    title: "Document Verification",
    description: "Double-check all your important documents to avoid any last-minute issues.",
    features: [
      "Passport validity check",
      "Visa verification",
      "Admission letter review",
      "Financial documents check"
    ]
  },
  {
    icon: Globe,
    title: "Cultural Orientation",
    description: "Prepare for cultural differences and learn about your destination country's customs.",
    features: [
      "Local customs and etiquette",
      "Social norms and behavior",
      "Food and dining culture",
      "Weather and clothing guide"
    ]
  },
  {
    icon: Briefcase,
    title: "Packing Guide",
    description: "Smart packing strategies to maximize your baggage allowance and bring essentials.",
    features: [
      "Essential items checklist",
      "What NOT to pack",
      "Seasonal clothing guide",
      "Electronics and adapters"
    ]
  },
  {
    icon: Landmark,
    title: "Banking Setup",
    description: "Guidance on setting up bank accounts and managing finances in your new country.",
    features: [
      "Student bank account options",
      "International transfer setup",
      "Credit/debit card guidance",
      "Tax and financial compliance"
    ]
  },
  {
    icon: Smartphone,
    title: "SIM Card & Connectivity",
    description: "Stay connected from day one with the right mobile plan and internet setup.",
    features: [
      "Best student mobile plans",
      "International roaming options",
      "Wi-Fi and internet setup",
      "Essential apps to download"
    ]
  }
];

const essentialDocuments = [
  { name: "Passport", description: "Valid for at least 6 months beyond your stay", critical: true },
  { name: "Student Visa", description: "Original visa sticker/approval letter", critical: true },
  { name: "University Offer Letter", description: "Original or certified copy", critical: true },
  { name: "CAS/Confirmation of Enrollment", description: "Required for UK and some countries", critical: true },
  { name: "Academic Transcripts", description: "Original certificates and marksheets", critical: true },
  { name: "English Test Results", description: "IELTS/TOEFL/PTE score report", critical: true },
  { name: "Financial Documents", description: "Bank statements, loan sanction letter", critical: true },
  { name: "Medical Records", description: "Vaccination certificates, prescriptions", critical: false },
  { name: "Passport Photos", description: "10-15 recent passport-size photos", critical: false },
  { name: "Travel Insurance", description: "Policy documents with coverage details", critical: true },
  { name: "Accommodation Proof", description: "Tenancy agreement or hostel confirmation", critical: true },
  { name: "Flight Tickets", description: "Return/onward journey tickets", critical: true },
];

const packingEssentials = {
  clothing: [
    "Undergarments (2 weeks' worth)",
    "Casual wear (jeans, t-shirts, shirts)",
    "Formal wear (1-2 sets for presentations)",
    "Winter wear (if applicable - jacket, sweaters)",
    "Traditional Indian outfit (for festivals/events)",
    "Comfortable walking shoes",
    "Formal shoes",
    "Sleepwear and loungewear"
  ],
  electronics: [
    "Laptop and charger",
    "Smartphone and charger",
    "Universal power adapter",
    "Power bank",
    "Headphones/earphones",
    "External hard drive (for backups)",
    "Hair dryer/trimmer (check voltage compatibility)"
  ],
  medications: [
    "Prescription medications (3-month supply)",
    "Basic first-aid kit",
    "Pain relievers (paracetamol, ibuprofen)",
    "Cold and flu medication",
    "Digestive aids",
    "Personal hygiene products",
    "Prescription copies and doctor's note"
  ],
  food: [
    "Instant noodles/maggi (for initial days)",
    "Indian spices (small quantities)",
    "Ready-to-eat meals (2-3 packs)",
    "Tea/coffee sachets",
    "Homemade snacks (check customs rules)"
  ],
  documents: [
    "All documents in carry-on bag",
    "Digital copies on cloud and email",
    "Emergency contact list",
    "University contact details",
    "Accommodation address and contact"
  ]
};

const emergencyContacts = [
  { country: "United Kingdom", embassy: "+44-20-7629-8800", police: "999", medical: "999" },
  { country: "Australia", embassy: "+61-2-6273-3999", police: "000", medical: "000" },
  { country: "Germany", embassy: "+49-30-257950", police: "110", medical: "112" },
  { country: "Ireland", embassy: "+353-1-496-7788", police: "999", medical: "999" },
  { country: "Canada", embassy: "+1-613-755-1531", police: "911", medical: "911" },
  { country: "USA", embassy: "+1-202-939-7000", police: "911", medical: "911" },
];

export function PreDepartureGuidancePage() {
  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Pre-Departure Guidance for Indian Students | Kingsley International"
        description="Complete pre-departure guidance for students going abroad. Checklists, document verification, packing guide, and cultural orientation."
      />
      <Header />

      {/* Hero Section */}
      <section className="pt-28 pb-16 bg-gradient-to-br from-[#0B1F3B] via-[#1a3a5c] to-[#0B1F3B]">
        <div className="container-custom">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C6A052]/20 rounded-full mb-6">
              <Plane className="w-4 h-4 text-[#C6A052]" />
              <span className="text-[#C6A052] text-sm font-medium">Pre-Departure</span>
            </div>
            <h1 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
              Ready for Takeoff?
              <span className="text-[#C6A052]"> We've Got You Covered</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              From document verification to cultural orientation, our pre-departure guidance 
              ensures you're fully prepared for your journey abroad. Don't leave anything to chance.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact">
                <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                  Get Pre-Departure Kit
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a href="tel:+919999999999">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                  <Phone className="w-5 h-5 mr-2" />
                  Talk to Advisor
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Our Services
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Complete Pre-Departure Support
            </h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Everything you need to prepare for a smooth transition to your new life abroad
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {preDepartureServices.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-card">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-[#C6A052]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#C6A052] transition-colors">
                    <service.icon className="w-7 h-7 text-[#C6A052] group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B] mb-3">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-[#C6A052] mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Checklist */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Essential Documents
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Document Verification Checklist
            </h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Keep all these documents in your carry-on bag. Never check them in with luggage.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {essentialDocuments.map((doc, index) => (
              <div 
                key={index} 
                className={`flex items-start gap-3 p-4 rounded-xl ${doc.critical ? 'bg-red-50 border border-red-100' : 'bg-gray-50'}`}
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${doc.critical ? 'bg-red-500 text-white' : 'bg-[#C6A052] text-white'}`}>
                  <CheckCircle className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-[#0B1F3B]">{doc.name}</h4>
                    {doc.critical && (
                      <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded">CRITICAL</span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">{doc.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-4 bg-[#C6A052]/10 rounded-xl flex items-start gap-3">
            <Info className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
            <p className="text-sm text-gray-700">
              <strong>Pro Tip:</strong> Make 2-3 sets of photocopies of all documents. Keep one in your 
              carry-on, one in checked luggage, and email digital copies to yourself and a family member.
            </p>
          </div>
        </div>
      </section>

      {/* Packing Guide */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              What to Pack
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Smart Packing Guide
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="border-0 shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Briefcase className="w-6 h-6 text-[#C6A052]" />
                  <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B]">Clothing</h3>
                </div>
                <ul className="space-y-2">
                  {packingEssentials.clothing.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Smartphone className="w-6 h-6 text-[#C6A052]" />
                  <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B]">Electronics</h3>
                </div>
                <ul className="space-y-2">
                  {packingEssentials.electronics.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Heart className="w-6 h-6 text-[#C6A052]" />
                  <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B]">Medications</h3>
                </div>
                <ul className="space-y-2">
                  {packingEssentials.medications.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <BookOpen className="w-6 h-6 text-[#C6A052]" />
                  <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B]">Food Items</h3>
                </div>
                <ul className="space-y-2">
                  {packingEssentials.food.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-card md:col-span-2 lg:col-span-2">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <FileCheck className="w-6 h-6 text-[#C6A052]" />
                  <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B]">Important Documents</h3>
                </div>
                <ul className="space-y-2">
                  {packingEssentials.documents.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 grid md:grid-cols-2 gap-4">
            <div className="p-4 bg-red-50 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-red-700 mb-1">What NOT to Pack</h4>
                <ul className="text-sm text-red-600 space-y-1">
                  <li>• Fresh fruits, vegetables, or meat products</li>
                  <li>• Large quantities of medicines (check limits)</li>
                  <li>• Expensive jewelry or valuables</li>
                  <li>• Items restricted by destination country customs</li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-blue-50 rounded-xl flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-blue-700 mb-1">Baggage Allowance Tips</h4>
                <ul className="text-sm text-blue-600 space-y-1">
                  <li>• Weigh your bags before leaving for airport</li>
                  <li>• Wear heavy items (jacket, boots) to save weight</li>
                  <li>• Use vacuum bags for clothes</li>
                  <li>• Keep essentials in carry-on (1 change of clothes)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Contacts */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Safety First
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Emergency Contacts by Country
            </h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Save these numbers in your phone before you travel
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {emergencyContacts.map((country, index) => (
              <div key={index} className="bg-[#F5F3EE] rounded-xl p-5">
                <h3 className="font-semibold text-[#0B1F3B] mb-3">{country.country}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Indian Embassy:</span>
                    <span className="font-medium">{country.embassy}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Police:</span>
                    <span className="font-medium text-red-600">{country.police}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Medical Emergency:</span>
                    <span className="font-medium text-red-600">{country.medical}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-6 bg-gradient-to-r from-[#0B1F3B] to-[#1a3a5c] rounded-xl text-white">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="font-playfair text-xl font-bold mb-2">Download Our Pre-Departure Checklist</h3>
                <p className="text-gray-300 text-sm">Complete printable checklist with all essentials</p>
              </div>
              <Link to="/contact">
                <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold">
                  Request Checklist
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Have Questions About Your Departure?
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Our pre-departure advisors are here to help. Get personalized guidance on 
            everything from packing to cultural adjustment.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                Schedule Pre-Departure Session
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
