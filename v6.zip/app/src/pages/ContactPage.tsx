import { useState } from "react";
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  CheckCircle,
  MessageSquare,
  User,
  Globe,
  GraduationCap,
  Wallet,
  BookOpen,
  Briefcase,
  Calendar,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SEO } from "@/components/SEO";
import { countryOptions } from "@/lib/normalizeData";

const studyLevels = [
  "Undergraduate",
  "Postgraduate",
  "PhD / Doctorate",
  "Diploma",
  "Not Sure",
];

const budgetRanges = [
  "Under ₹10 Lakhs",
  "₹10-20 Lakhs",
  "₹20-30 Lakhs",
  "₹30-50 Lakhs",
  "Above ₹50 Lakhs",
  "Not Sure",
];

const ieltsStatuses = [
  "Not taken yet",
  "Preparing for exam",
  "Score: 5.0-5.5",
  "Score: 6.0-6.5",
  "Score: 7.0+",
  "Not required",
];

const intakes = [
  "January 2025",
  "February 2025",
  "March 2025",
  "April 2025",
  "May 2025",
  "June 2025",
  "July 2025",
  "August 2025",
  "September 2025",
  "October 2025",
  "January 2026",
  "Flexible",
];

const workExperiences = [
  "No experience",
  "Less than 1 year",
  "1-2 years",
  "2-3 years",
  "3-5 years",
  "5+ years",
];

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    countryInterest: "",
    studyLevel: "",
    budgetRange: "",
    ieltsStatus: "",
    intake: "",
    workExperience: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full name is required";
    }
    
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = "Phone number is required";
    } else if (!/^[+]?[\d\s-]{10,}$/.test(formData.phone.replace(/\s/g, ""))) {
      newErrors.phone = "Please enter a valid phone number";
    }
    
    if (!formData.countryInterest) {
      newErrors.countryInterest = "Please select a country";
    }
    
    if (!formData.studyLevel) {
      newErrors.studyLevel = "Please select study level";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    
    // Store in localStorage for demo purposes
    const submissions = JSON.parse(localStorage.getItem("consultation_submissions") || "[]");
    submissions.push({
      ...formData,
      submittedAt: new Date().toISOString(),
    });
    localStorage.setItem("consultation_submissions", JSON.stringify(submissions));
  };

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Book a Free Consultation | Kingsley International"
        description="Book a free consultation with our study abroad experts. Get personalized guidance for university selection, applications, visas, and scholarships."
      />
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Book a Free Consultation
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Fill out the form below and our expert counsellors will get back to you within 24 hours.
            No obligations, just guidance.
          </p>
        </div>
      </div>

      <main className="container-custom py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl p-8 shadow-lg">
              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                  <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-2">
                    Thank You!
                  </h2>
                  <p className="text-gray-600 mb-2">
                    We've received your consultation request.
                  </p>
                  <p className="text-gray-500 text-sm mb-6">
                    One of our expert counsellors will contact you within 24 hours.
                  </p>
                  <Button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        fullName: "",
                        email: "",
                        phone: "",
                        countryInterest: "",
                        studyLevel: "",
                        budgetRange: "",
                        ieltsStatus: "",
                        intake: "",
                        workExperience: "",
                        message: "",
                      });
                    }}
                    variant="outline"
                    className="border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]"
                  >
                    Submit Another Request
                  </Button>
                </div>
              ) : (
                <>
                  <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                    Tell Us About Your Study Abroad Goals
                  </h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Personal Information */}
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="fullName" className="flex items-center gap-2">
                          <User className="w-4 h-4 text-[#C6A052]" />
                          Full Name *
                        </Label>
                        <Input
                          id="fullName"
                          placeholder="Your full name"
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          className={errors.fullName ? "border-red-500" : ""}
                        />
                        {errors.fullName && (
                          <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>
                        )}
                      </div>
                      <div>
                        <Label htmlFor="email" className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-[#C6A052]" />
                          Email Address *
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className={errors.email ? "border-red-500" : ""}
                        />
                        {errors.email && (
                          <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                        )}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="phone" className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-[#C6A052]" />
                          Phone Number *
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+91 98765 43210"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className={errors.phone ? "border-red-500" : ""}
                        />
                        {errors.phone && (
                          <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                        )}
                      </div>
                      <div>
                        <Label htmlFor="countryInterest" className="flex items-center gap-2">
                          <Globe className="w-4 h-4 text-[#C6A052]" />
                          Country of Interest *
                        </Label>
                        <Select
                          value={formData.countryInterest}
                          onValueChange={(value) => setFormData({ ...formData, countryInterest: value })}
                        >
                          <SelectTrigger className={errors.countryInterest ? "border-red-500" : ""}>
                            <SelectValue placeholder="Select a country" />
                          </SelectTrigger>
                          <SelectContent>
                            {countryOptions.map((country) => (
                              <SelectItem key={country.value} value={country.value}>
                                {country.flag} {country.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {errors.countryInterest && (
                          <p className="text-red-500 text-sm mt-1">{errors.countryInterest}</p>
                        )}
                      </div>
                    </div>

                    {/* Study Preferences */}
                    <div className="border-t pt-6">
                      <h3 className="font-semibold text-[#0B1F3B] mb-4">Study Preferences</h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="studyLevel" className="flex items-center gap-2">
                            <GraduationCap className="w-4 h-4 text-[#C6A052]" />
                            Study Level *
                          </Label>
                          <Select
                            value={formData.studyLevel}
                            onValueChange={(value) => setFormData({ ...formData, studyLevel: value })}
                          >
                            <SelectTrigger className={errors.studyLevel ? "border-red-500" : ""}>
                              <SelectValue placeholder="Select study level" />
                            </SelectTrigger>
                            <SelectContent>
                              {studyLevels.map((level) => (
                                <SelectItem key={level} value={level}>
                                  {level}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {errors.studyLevel && (
                            <p className="text-red-500 text-sm mt-1">{errors.studyLevel}</p>
                          )}
                        </div>
                        <div>
                          <Label htmlFor="budgetRange" className="flex items-center gap-2">
                            <Wallet className="w-4 h-4 text-[#C6A052]" />
                            Budget Range
                          </Label>
                          <Select
                            value={formData.budgetRange}
                            onValueChange={(value) => setFormData({ ...formData, budgetRange: value })}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select budget range" />
                            </SelectTrigger>
                            <SelectContent>
                              {budgetRanges.map((range) => (
                                <SelectItem key={range} value={range}>
                                  {range}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-6">
                      <div>
                        <Label htmlFor="ieltsStatus" className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-[#C6A052]" />
                          IELTS Status
                        </Label>
                        <Select
                          value={formData.ieltsStatus}
                          onValueChange={(value) => setFormData({ ...formData, ieltsStatus: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select IELTS status" />
                          </SelectTrigger>
                          <SelectContent>
                            {ieltsStatuses.map((status) => (
                              <SelectItem key={status} value={status}>
                                {status}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="intake" className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#C6A052]" />
                          Preferred Intake
                        </Label>
                        <Select
                          value={formData.intake}
                          onValueChange={(value) => setFormData({ ...formData, intake: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select intake" />
                          </SelectTrigger>
                          <SelectContent>
                            {intakes.map((intake) => (
                              <SelectItem key={intake} value={intake}>
                                {intake}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="workExperience" className="flex items-center gap-2">
                          <Briefcase className="w-4 h-4 text-[#C6A052]" />
                          Work Experience
                        </Label>
                        <Select
                          value={formData.workExperience}
                          onValueChange={(value) => setFormData({ ...formData, workExperience: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select experience" />
                          </SelectTrigger>
                          <SelectContent>
                            {workExperiences.map((exp) => (
                              <SelectItem key={exp} value={exp}>
                                {exp}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="message">Additional Message</Label>
                      <Textarea
                        id="message"
                        placeholder="Tell us more about your study abroad goals, preferred universities, or any specific questions..."
                        rows={4}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold py-6"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin w-5 h-5 border-2 border-[#0B1F3B] border-t-transparent rounded-full mr-2" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5 mr-2" />
                          Book Free Consultation
                        </>
                      )}
                    </Button>

                    <p className="text-xs text-gray-500 text-center">
                      By submitting this form, you agree to our privacy policy. We will never share your information with third parties.
                    </p>
                  </form>
                </>
              )}
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <div className="bg-[#0B1F3B] rounded-xl p-6 text-white">
              <h3 className="font-playfair text-xl font-semibold mb-6">
                Contact Information
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Address</p>
                    <p className="text-gray-300 text-sm">
                      123 Education Street, Koramangala
                      <br />
                      Bangalore, Karnataka 560034
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Phone</p>
                    <a href="tel:+919876543210" className="text-gray-300 text-sm hover:text-[#C6A052] transition-colors">
                      +91 98765 43210
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Email</p>
                    <a href="mailto:info@kingsley.edu" className="text-gray-300 text-sm hover:text-[#C6A052] transition-colors">
                      info@kingsley.edu
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Working Hours</p>
                    <p className="text-gray-300 text-sm">
                      Mon - Sat: 9:00 AM - 7:00 PM
                      <br />
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a
              href="https://wa.me/919876543210?text=Hi, I'm interested in studying abroad"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-500 rounded-xl p-6 text-white block hover:bg-green-600 transition-colors"
            >
              <div className="flex items-center gap-3 mb-2">
                <MessageSquare className="w-6 h-6" />
                <h3 className="font-playfair text-lg font-semibold">
                  Chat on WhatsApp
                </h3>
              </div>
              <p className="text-green-100 text-sm">
                Get instant responses to your queries via WhatsApp.
              </p>
            </a>

            {/* Why Choose Us */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                Why Book a Consultation?
              </h3>
              <ul className="space-y-3">
                {[
                  "Personalized university shortlisting",
                  "Course selection guidance",
                  "Application strategy",
                  "Scholarship opportunities",
                  "Visa assistance",
                  "Pre-departure support",
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckCircle className="w-4 h-4 text-[#C6A052]" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
