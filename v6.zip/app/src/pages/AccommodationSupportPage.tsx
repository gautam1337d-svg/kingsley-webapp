import { Link } from "react-router-dom";
import {
  Home,
  Building2,
  Users,
  CheckCircle,
  ArrowRight,
  Phone,
  AlertTriangle,
  Calendar,
  Shield,
  Bed,
  Info,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SEO } from "@/components/SEO";

const accommodationTypes = [
  {
    icon: Building2,
    title: "On-Campus Housing",
    description: "University-managed accommodation with easy access to classes and campus facilities.",
    pros: ["Closest to campus", "All utilities included", "Meal plans available", "Built-in community"],
    cons: ["Limited availability", "Higher cost", "Less privacy", "Application deadlines"],
    typicalCost: "£400-800 / €400-700 / AUD 800-1,500 per month"
  },
  {
    icon: Home,
    title: "Private Student Housing",
    description: "Purpose-built student accommodations operated by private companies near universities.",
    pros: ["Modern facilities", "All-inclusive bills", "Social events", "24/7 security"],
    cons: ["Premium pricing", "Can be noisy", "Less flexibility", "Booking fees"],
    typicalCost: "£500-900 / €500-800 / AUD 900-1,800 per month"
  },
  {
    icon: Users,
    title: "Shared Apartments",
    description: "Rent a room in a shared flat or house with other students or working professionals.",
    pros: ["Most affordable option", "More space", "Learn independence", "Local experience"],
    cons: ["Shared responsibilities", "Variable quality", "May need furniture", "Utility bills extra"],
    typicalCost: "£300-600 / €300-600 / AUD 600-1,200 per month"
  },
  {
    icon: Bed,
    title: "Homestay",
    description: "Live with a local family for a immersive cultural experience and home-cooked meals.",
    pros: ["Cultural immersion", "Meals included", "Family support", "Language practice"],
    cons: ["Less independence", "House rules", "Limited availability", "May be far from campus"],
    typicalCost: "£500-800 / €450-750 / AUD 800-1,400 per month"
  }
];

const countryCosts = [
  {
    country: "United Kingdom",
    flag: "🇬🇧",
    onCampus: "£400-800/month",
    private: "£500-900/month",
    shared: "£300-600/month",
    cities: {
      "London": "£800-1,500/month",
      "Manchester": "£400-700/month",
      "Other cities": "£350-600/month"
    }
  },
  {
    country: "Germany",
    flag: "🇩🇪",
    onCampus: "€300-600/month",
    private: "€400-700/month",
    shared: "€300-500/month",
    cities: {
      "Munich": "€600-900/month",
      "Berlin": "€400-700/month",
      "Other cities": "€300-500/month"
    }
  },
  {
    country: "Australia",
    flag: "🇦🇺",
    onCampus: "AUD 800-1,500/month",
    private: "AUD 900-1,800/month",
    shared: "AUD 600-1,200/month",
    cities: {
      "Sydney": "AUD 1,200-2,000/month",
      "Melbourne": "AUD 1,000-1,800/month",
      "Other cities": "AUD 600-1,200/month"
    }
  },
  {
    country: "Ireland",
    flag: "🇮🇪",
    onCampus: "€500-900/month",
    private: "€600-1,000/month",
    shared: "€400-700/month",
    cities: {
      "Dublin": "€800-1,400/month",
      "Cork": "€500-800/month",
      "Other cities": "€400-700/month"
    }
  }
];

const scamWarnings = [
  {
    title: "Too Good to Be True",
    description: "If the price is significantly lower than market rate, it's likely a scam. Verify through official channels."
  },
  {
    title: "Request for Upfront Payment",
    description: "Never pay before viewing the property or signing a contract. Scammers often ask for deposits via wire transfer."
  },
  {
    title: "No Viewing Allowed",
    description: "Be suspicious if the landlord refuses video calls or in-person viewings before payment."
  },
  {
    title: "Pressure Tactics",
    description: "Scammers create urgency ('5 others interested'). Take your time and verify everything."
  },
  {
    title: "Unprofessional Communication",
    description: "Poor grammar, generic emails, or refusal to provide proper documentation are red flags."
  }
];

const bookingTimeline = [
  {
    when: "6-8 Months Before",
    action: "Research accommodation options and apply for on-campus housing",
    important: true
  },
  {
    when: "4-5 Months Before",
    action: "Secure your accommodation with deposit payment",
    important: true
  },
  {
    when: "2-3 Months Before",
    action: "Arrange utility connections and internet setup",
    important: false
  },
  {
    when: "1 Month Before",
    action: "Confirm arrival details and arrange key collection",
    important: true
  },
  {
    when: "1 Week Before",
    action: "Final check with landlord/property manager",
    important: false
  }
];

export function AccommodationSupportPage() {
  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Student Accommodation Support | Kingsley International"
        description="Find the perfect student accommodation abroad. On-campus, private housing, shared apartments - we help you secure safe, affordable housing."
      />
      <Header />

      {/* Hero Section */}
      <section className="pt-28 pb-16 bg-gradient-to-br from-[#0B1F3B] via-[#1a3a5c] to-[#0B1F3B]">
        <div className="container-custom">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C6A052]/20 rounded-full mb-6">
              <Home className="w-4 h-4 text-[#C6A052]" />
              <span className="text-[#C6A052] text-sm font-medium">Accommodation</span>
            </div>
            <h1 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
              Find Your Home
              <span className="text-[#C6A052]"> Away From Home</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              From on-campus dorms to shared apartments, we help you find safe, affordable accommodation 
              that fits your budget and lifestyle. Avoid scams and secure your housing before you arrive.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact">
                <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                  Find Accommodation
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a href="tel:+919999999999">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                  <Phone className="w-5 h-5 mr-2" />
                  Talk to Expert
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Accommodation Types */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Housing Options
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Types of Accommodation
            </h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Understand your options to make the best choice for your study abroad experience
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {accommodationTypes.map((type, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-[#C6A052]/10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-[#C6A052] transition-colors">
                      <type.icon className="w-7 h-7 text-[#C6A052] group-hover:text-white transition-colors" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B] mb-2">
                        {type.title}
                      </h3>
                      <p className="text-gray-600 mb-4 text-sm">
                        {type.description}
                      </p>
                      
                      <div className="grid sm:grid-cols-2 gap-4 mb-4">
                        <div>
                          <span className="text-xs font-semibold text-green-600 uppercase">Pros</span>
                          <ul className="mt-1 space-y-1">
                            {type.pros.map((pro, idx) => (
                              <li key={idx} className="flex items-center gap-1 text-sm text-gray-700">
                                <CheckCircle className="w-3 h-3 text-green-500" />
                                {pro}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <span className="text-xs font-semibold text-red-600 uppercase">Cons</span>
                          <ul className="mt-1 space-y-1">
                            {type.cons.map((con, idx) => (
                              <li key={idx} className="flex items-center gap-1 text-sm text-gray-700">
                                <AlertTriangle className="w-3 h-3 text-red-400" />
                                {con}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="bg-[#F5F3EE] rounded-lg p-3">
                        <span className="text-xs text-gray-500">Typical Cost:</span>
                        <p className="font-semibold text-[#0B1F3B]">{type.typicalCost}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Cost by Country */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Cost Guide
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Accommodation Costs by Country
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {countryCosts.map((country, index) => (
              <Card key={index} className="border-0 shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-3xl">{country.flag}</span>
                    <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B]">
                      {country.country}
                    </h3>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <Building2 className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                      <span className="text-xs text-gray-500 block">On-Campus</span>
                      <span className="font-semibold text-sm">{country.onCampus}</span>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <Home className="w-5 h-5 text-purple-600 mx-auto mb-1" />
                      <span className="text-xs text-gray-500 block">Private</span>
                      <span className="font-semibold text-sm">{country.private}</span>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <Users className="w-5 h-5 text-green-600 mx-auto mb-1" />
                      <span className="text-xs text-gray-500 block">Shared</span>
                      <span className="font-semibold text-sm">{country.shared}</span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <span className="text-xs text-gray-500 mb-2 block">By City:</span>
                    <div className="space-y-1">
                      {Object.entries(country.cities).map(([city, cost]) => (
                        <div key={city} className="flex justify-between text-sm">
                          <span className="text-gray-600">{city}</span>
                          <span className="font-medium">{cost}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Timeline */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
                When to Book
              </span>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3 mb-6">
                Accommodation Booking Timeline
              </h2>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Start your accommodation search early. Good options get booked quickly, 
                especially in popular student cities.
              </p>

              <div className="space-y-4">
                {bookingTimeline.map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${item.important ? 'bg-[#C6A052] text-white' : 'bg-gray-200 text-gray-600'}`}>
                        <Calendar className="w-4 h-4" />
                      </div>
                      {index < bookingTimeline.length - 1 && (
                        <div className="w-0.5 h-full bg-gray-200 mt-2" />
                      )}
                    </div>
                    <div className="pb-6">
                      <span className={`text-sm font-semibold ${item.important ? 'text-[#C6A052]' : 'text-gray-500'}`}>
                        {item.when}
                      </span>
                      <p className="text-gray-700 mt-1">{item.action}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#0B1F3B] to-[#1a3a5c] rounded-2xl p-8 text-white">
              <Shield className="w-10 h-10 text-[#C6A052] mb-4" />
              <h3 className="font-playfair text-2xl font-bold mb-4">
                Avoid Accommodation Scams
              </h3>
              <div className="space-y-4">
                {scamWarnings.map((warning, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-white">{warning.title}</h4>
                      <p className="text-sm text-gray-300">{warning.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-white/20">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-300">
                    <strong className="text-white">Our Guarantee:</strong> We verify all properties 
                    and landlords before recommending them to students. Your safety is our priority.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Need Help Finding Accommodation?
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Let our accommodation experts help you find the perfect place. We work with verified 
            landlords and student housing providers to ensure you have a safe home abroad.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                Get Accommodation Help
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
