import { Link } from "react-router-dom";
import {
  FileText,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Globe,
  DollarSign,
  Briefcase,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { SEO } from "@/components/SEO";
import { getCountryFlag } from "@/lib/utils";
import { getAllCountries } from "@/data/countryData";

const visaTypes = [
  {
    country: "United Kingdom",
    slug: "uk",
    visa: "Student Route Visa",
    duration: "Course duration + 4-6 months",
    workRights: "20 hours/week during term",
    postStudy: "Graduate Route - 2 years",
    fees: "£490",
  },
  {
    country: "Ireland",
    slug: "ireland",
    visa: "Study Visa (D Visa)",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "Third Level Graduate Scheme - 2 years",
    fees: "€60",
  },
  {
    country: "Germany",
    slug: "germany",
    visa: "Student Visa",
    duration: "Course duration + 3 months",
    workRights: "120 full days/year",
    postStudy: "18-month job seeker visa",
    fees: "€75-80",
  },
  {
    country: "France",
    slug: "france",
    visa: "Long-Stay Student Visa (VLS-TS)",
    duration: "Course duration",
    workRights: "964 hours/year",
    postStudy: "APS visa - 2 years for master's",
    fees: "€99",
  },
  {
    country: "Netherlands",
    slug: "netherlands",
    visa: "Residence Permit for Study",
    duration: "Course duration",
    workRights: "16 hours/week or seasonal full-time",
    postStudy: "Orientation Year - 1 year",
    fees: "€210",
  },
  {
    country: "Italy",
    slug: "italy",
    visa: "Type D National Visa (Study)",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "Job search permit - 1 year",
    fees: "€50",
  },
  {
    country: "Spain",
    slug: "spain",
    visa: "Student Visa (Type D)",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "Job search visa - up to 1 year",
    fees: "€60",
  },
  {
    country: "Sweden",
    slug: "sweden",
    visa: "Residence Permit for Studies",
    duration: "Course duration",
    workRights: "No official limit",
    postStudy: "12-month job search permit",
    fees: "SEK 1,500",
  },
  {
    country: "New Zealand",
    slug: "newzealand",
    visa: "Fee Paying Student Visa",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "Post-study work visa - 1-3 years",
    fees: "NZD 375",
  },
  {
    country: "Australia",
    slug: "australia",
    visa: "Subclass 500 Student Visa",
    duration: "Course duration",
    workRights: "48 hours/fortnight during term",
    postStudy: "Temporary Graduate Visa (485) - 2-4 years",
    fees: "AUD 710",
  },
  {
    country: "Austria",
    slug: "austria",
    visa: "Student Residence Permit",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "Red-White-Red Card - 12 months",
    fees: "€160",
  },
  {
    country: "Belgium",
    slug: "belgium",
    visa: "Long-Stay Visa (D) + Residence Permit",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "12-month job search permit",
    fees: "€180",
  },
  {
    country: "Finland",
    slug: "finland",
    visa: "Residence Permit for Studies",
    duration: "Course duration",
    workRights: "30 hours/week during term",
    postStudy: "2-year residence permit for job search",
    fees: "€350",
  },
  {
    country: "Norway",
    slug: "norway",
    visa: "Student Residence Permit",
    duration: "Course duration",
    workRights: "Part-time (no strict limit)",
    postStudy: "2-year permit for job search",
    fees: "NOK 5,900",
  },
  {
    country: "Portugal",
    slug: "portugal",
    visa: "Student Visa (Type D)",
    duration: "Course duration",
    workRights: "20 hours/week during term",
    postStudy: "Job search visa - up to 1 year",
    fees: "€90",
  },
];

const documentChecklist = [
  "Valid passport (valid for at least 6 months beyond stay)",
  "University admission letter / CAS / COE",
  "Financial proof (bank statements, loan letters)",
  "Academic transcripts and certificates",
  "English language test results (IELTS/TOEFL)",
  "Passport-sized photographs",
  "Visa application form (completed)",
  "Visa fee payment receipt",
  "Health/medical certificates (if required)",
  "Police clearance certificate (if required)",
];

const faqs = [
  {
    question: "When should I apply for my student visa?",
    answer: "We recommend applying 3-4 months before your program start date. This allows sufficient time for processing and addressing any issues that may arise.",
  },
  {
    question: "How much funds do I need to show?",
    answer: "The amount varies by country. Generally, you need to show tuition fees for the first year plus living expenses for 9-12 months. Contact us for specific requirements for your destination.",
  },
  {
    question: "Can I work while studying?",
    answer: "Most countries allow international students to work part-time during term and full-time during breaks. Specific hours vary by country.",
  },
  {
    question: "What if my visa is rejected?",
    answer: "Don't panic! We analyze the rejection reason, help you address any issues, and assist with reapplication. Many students succeed on their second attempt.",
  },
  {
    question: "Can I bring my family?",
    answer: "Dependent visas are available in most countries for postgraduate students. Requirements vary - speak to our counsellors for specific guidance.",
  },
];

export function VisaGuidancePage() {
  const countries = getAllCountries();

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Student Visa Guidance | Kingsley International"
        description="Expert visa assistance for studying abroad. 98% success rate. Get help with documentation, application, and interview preparation."
      />
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Visa Guidance
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Expert assistance for your student visa application. We guide you
            through every step to maximize your chances of approval.
          </p>
        </div>
      </div>

      <main className="container-custom py-12">
        {/* Visa Types Comparison */}
        <section className="mb-16">
          <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
            Student Visa Comparison
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-xl shadow-lg">
              <thead>
                <tr className="bg-[#0B1F3B] text-white">
                  <th className="p-4 text-left rounded-tl-xl">Country</th>
                  <th className="p-4 text-left">Visa Type</th>
                  <th className="p-4 text-left">Work Rights</th>
                  <th className="p-4 text-left">Post-Study</th>
                  <th className="p-4 text-left rounded-tr-xl">Fees</th>
                </tr>
              </thead>
              <tbody>
                {visaTypes.map((visa, idx) => (
                  <tr key={idx} className="border-b last:border-b-0 hover:bg-gray-50">
                    <td className="p-4">
                      <Link to={`/visa/${visa.slug}`} className="flex items-center gap-2 hover:text-[#C6A052] transition-colors">
                        <span>{getCountryFlag(visa.slug)}</span>
                        <span className="font-medium">{visa.country}</span>
                      </Link>
                    </td>
                    <td className="p-4 text-sm">{visa.visa}</td>
                    <td className="p-4 text-sm">{visa.workRights}</td>
                    <td className="p-4 text-sm">{visa.postStudy}</td>
                    <td className="p-4 text-sm font-medium">{visa.fees}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Country Visa Guides */}
        <section className="mb-16">
          <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
            Detailed Visa Guides by Country
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {countries.map((country) => (
              <Link
                key={country.slug}
                to={`/visa/${country.slug}`}
                className="bg-white rounded-xl p-4 shadow-lg hover:shadow-xl transition-shadow flex items-center gap-3"
              >
                <span className="text-3xl">{country.flag}</span>
                <div>
                  <p className="font-semibold text-[#0B1F3B]">{country.name}</p>
                  <p className="text-sm text-[#C6A052]">View Visa Guide →</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Document Checklist */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-6">
                <FileText className="w-6 h-6 text-[#C6A052]" />
                <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B]">
                  General Document Checklist
                </h2>
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                {documentChecklist.map((doc, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#C6A052] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600 text-sm">{doc}</span>
                  </div>
                ))}
              </div>
              <p className="text-sm text-gray-500 mt-4">
                * Requirements may vary by country. Visit the specific country visa page for detailed information.
              </p>
            </section>

            {/* Process */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                Our Visa Support Process
              </h2>
              <div className="space-y-6">
                {[
                  {
                    step: 1,
                    title: "Visa Assessment",
                    desc: "We evaluate your profile and determine the appropriate visa category for your destination.",
                  },
                  {
                    step: 2,
                    title: "Document Preparation",
                    desc: "Guidance on gathering and organizing all required documents with proper formatting.",
                  },
                  {
                    step: 3,
                    title: "Application Review",
                    desc: "Thorough review of your application before submission to minimize errors.",
                  },
                  {
                    step: 4,
                    title: "Interview Preparation",
                    desc: "Mock interviews and tips for visa interviews (if required by the country).",
                  },
                  {
                    step: 5,
                    title: "Post-Submission Support",
                    desc: "Tracking and follow-up until visa decision and handling any additional requests.",
                  },
                ].map((item) => (
                  <div key={item.step} className="flex gap-4">
                    <div className="w-10 h-10 bg-[#C6A052] text-[#0B1F3B] rounded-full flex items-center justify-center font-bold flex-shrink-0">
                      {item.step}
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0B1F3B]">{item.title}</h3>
                      <p className="text-gray-600 text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* FAQs */}
            <section className="bg-white rounded-xl p-8 shadow-lg">
              <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
                Frequently Asked Questions
              </h2>
              <div className="space-y-4">
                {faqs.map((faq, idx) => (
                  <div key={idx} className="border-b last:border-b-0 pb-4 last:pb-0">
                    <h3 className="font-semibold text-[#0B1F3B] mb-2">{faq.question}</h3>
                    <p className="text-gray-600 text-sm">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Success Rate */}
            <div className="bg-[#C6A052] rounded-xl p-6 text-[#0B1F3B]">
              <div className="text-center">
                <p className="text-5xl font-bold mb-2">98%</p>
                <p className="font-medium">Visa Success Rate</p>
                <p className="text-sm mt-2 opacity-80">
                  Our expert guidance ensures the best possible outcome for your visa application.
                </p>
              </div>
            </div>

            {/* Quick Tips */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                Quick Tips
              </h3>
              <ul className="space-y-3">
                {[
                  "Apply early - at least 3 months before",
                  "Keep all documents organized",
                  "Be honest in your application",
                  "Prepare well for interviews",
                  "Show strong ties to home country",
                ].map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <AlertCircle className="w-4 h-4 text-[#C6A052] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CTA */}
            <div className="bg-[#0B1F3B] rounded-xl p-6 text-white">
              <h3 className="font-playfair text-lg font-semibold mb-2">
                Need Visa Assistance?
              </h3>
              <p className="text-gray-300 text-sm mb-4">
                Our visa experts are here to help you navigate the application process.
              </p>
              <Link to="/contact">
                <Button className="w-full bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]">
                  Get Expert Help
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>

            {/* Related Links */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-4">
                Related Links
              </h3>
              <div className="space-y-2">
                <Link to="/scholarships" className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <DollarSign className="w-4 h-4" />
                  Scholarships
                </Link>
                <Link to="/find-your-course" className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <Globe className="w-4 h-4" />
                  Browse Programs
                </Link>
                <Link to="/contact" className="flex items-center gap-2 text-gray-600 hover:text-[#C6A052] transition-colors">
                  <Briefcase className="w-4 h-4" />
                  Book Consultation
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
