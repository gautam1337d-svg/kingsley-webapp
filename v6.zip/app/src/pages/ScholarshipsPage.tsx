import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Award,
  CheckCircle,
  DollarSign,
  Calendar,
  ArrowRight,
  Star,
  Globe,
  Search,
  GraduationCap,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { SEO } from "@/components/SEO";
import { getCountryFlag } from "@/lib/utils";

interface Scholarship {
  name: string;
  country: string;
  countrySlug: string;
  level: string;
  coverage: string;
  deadline: string;
  eligibility: string;
  description: string;
  amount: string;
}

const scholarships: Scholarship[] = [
  // UK Scholarships
  {
    name: "Chevening Scholarship",
    country: "United Kingdom",
    countrySlug: "uk",
    level: "Masters",
    coverage: "Full funding",
    deadline: "August",
    eligibility: "2+ years work experience, leadership potential, excellent academics",
    description: "The UK government's global scholarship program for future leaders",
    amount: "Full tuition + £1,100-1,400/month living allowance + flights",
  },
  {
    name: "Commonwealth Scholarship",
    country: "United Kingdom",
    countrySlug: "uk",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "October-December",
    eligibility: "Citizens of Commonwealth countries, academic excellence",
    description: "For students from Commonwealth countries to pursue postgraduate study",
    amount: "Full tuition + living allowance + travel + thesis grant",
  },
  {
    name: "GREAT Scholarship",
    country: "United Kingdom",
    countrySlug: "uk",
    level: "Masters",
    coverage: "Partial funding",
    deadline: "Varies by university",
    eligibility: "Indian students for selected UK universities",
    description: "Partnership between UK government and British Council",
    amount: "£10,000 towards tuition fees",
  },
  {
    name: "Charles Wallace India Trust Scholarship",
    country: "United Kingdom",
    countrySlug: "uk",
    level: "Doctoral, Research",
    coverage: "Partial funding",
    deadline: "December-January",
    eligibility: "Indian citizens in arts, heritage conservation, humanities",
    description: "For mid-career professionals in arts and heritage",
    amount: "Variable (up to full funding)",
  },
  
  // Ireland Scholarships
  {
    name: "Government of Ireland International Education Scholarship",
    country: "Ireland",
    countrySlug: "ireland",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "March",
    eligibility: "Non-EU/EEA students with excellent academics",
    description: "Prestigious scholarship offered by the Irish government",
    amount: "€10,000 stipend + full fee waiver",
  },
  {
    name: "Trinity College Dublin Scholarship",
    country: "Ireland",
    countrySlug: "ireland",
    level: "Undergraduate, Masters",
    coverage: "Partial funding",
    deadline: "Varies",
    eligibility: "Academic excellence, leadership potential",
    description: "Merit-based scholarships for international students",
    amount: "€5,000 - €10,000",
  },
  
  // Germany Scholarships
  {
    name: "DAAD Scholarship",
    country: "Germany",
    countrySlug: "germany",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "Varies by program",
    eligibility: "Graduates with 2+ years experience, academic excellence",
    description: "Germany's largest scholarship organization for international students",
    amount: "€850-1,200/month + allowances + travel + insurance",
  },
  {
    name: "Deutschlandstipendium",
    country: "Germany",
    countrySlug: "germany",
    level: "Undergraduate, Masters",
    coverage: "Partial funding",
    deadline: "Varies by university",
    eligibility: "Outstanding academic achievement and social commitment",
    description: "Merit-based scholarship supported by government and private sponsors",
    amount: "€300/month for 2 semesters (renewable)",
  },
  {
    name: "Heinrich Böll Scholarship",
    country: "Germany",
    countrySlug: "germany",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "March, September",
    eligibility: "International students with strong social and political engagement",
    description: "For students committed to green values and social justice",
    amount: "Full tuition + living expenses",
  },
  
  // France Scholarships
  {
    name: "Eiffel Excellence Scholarship",
    country: "France",
    countrySlug: "france",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "January",
    eligibility: "Non-French students under 30 (masters) or 35 (PhD)",
    description: "Prestigious scholarship by the French Ministry for Europe and Foreign Affairs",
    amount: "€1,181/month (master's), €1,400/month (PhD) + various allowances",
  },
  {
    name: "Charpak Scholarship",
    country: "France",
    countrySlug: "france",
    level: "Bachelors, Masters",
    coverage: "Partial to full funding",
    deadline: "February",
    eligibility: "Indian students under 30 years",
    description: "Scholarship program for Indian students funded by French Embassy",
    amount: "Tuition waiver + living allowance + visa fee waiver",
  },
  {
    name: "Erasmus Mundus Scholarship",
    country: "France",
    countrySlug: "france",
    level: "Masters",
    coverage: "Full funding",
    deadline: "January-March",
    eligibility: "Students worldwide for joint master's programs",
    description: "EU-funded scholarships for joint master's degrees",
    amount: "Full tuition + €1,400/month living allowance + travel",
  },
  
  // Netherlands Scholarships
  {
    name: "Holland Scholarship",
    country: "Netherlands",
    countrySlug: "netherlands",
    level: "Bachelors, Masters",
    coverage: "Partial funding",
    deadline: "February/May",
    eligibility: "Non-EEA students applying to Dutch research universities",
    description: "Scholarship for international students from outside the EEA",
    amount: "€5,000 one-time payment in first year",
  },
  {
    name: "Orange Knowledge Programme",
    country: "Netherlands",
    countrySlug: "netherlands",
    level: "Short courses, Masters",
    coverage: "Full funding",
    deadline: "Varies",
    eligibility: "Professionals from selected countries including India",
    description: "Dutch government scholarship for capacity building",
    amount: "Full cost coverage including travel and living expenses",
  },
  {
    name: "TU Delft Excellence Scholarship",
    country: "Netherlands",
    countrySlug: "netherlands",
    level: "Masters",
    coverage: "Full funding",
    deadline: "December",
    eligibility: "Outstanding academic record, top 10% of class",
    description: "Merit-based scholarship for MSc students at TU Delft",
    amount: "Full tuition waiver + living expenses",
  },
  
  // Italy Scholarships
  {
    name: "Italian Government Scholarship",
    country: "Italy",
    countrySlug: "italy",
    level: "Masters, PhD, Research",
    coverage: "Full funding",
    deadline: "June",
    eligibility: "International students under certain age limits",
    description: "Scholarships offered by the Italian Ministry of Foreign Affairs",
    amount: "€900/month + tuition waiver + health insurance",
  },
  {
    name: "Invest Your Talent in Italy",
    country: "Italy",
    countrySlug: "italy",
    level: "Masters",
    coverage: "Full funding",
    deadline: "January",
    eligibility: "Students from selected countries including India",
    description: "Scholarship for English-taught master's programs with internship",
    amount: "€8,100 + tuition waiver + internship",
  },
  
  // Spain Scholarships
  {
    name: "MAEC-AECID Scholarship",
    country: "Spain",
    countrySlug: "spain",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "Varies",
    eligibility: "International students from selected countries",
    description: "Spanish government scholarships for international cooperation",
    amount: "Full tuition + living allowance + travel",
  },
  
  // Sweden Scholarships
  {
    name: "Swedish Institute Scholarship",
    country: "Sweden",
    countrySlug: "sweden",
    level: "Masters",
    coverage: "Full funding",
    deadline: "February",
    eligibility: "Students from selected countries with leadership experience",
    description: "Highly competitive scholarships for full-time master's studies",
    amount: "Full tuition + SEK 11,000/month + travel grant + insurance",
  },
  {
    name: "University-specific Scholarships",
    country: "Sweden",
    countrySlug: "sweden",
    level: "Masters",
    coverage: "Partial to full funding",
    deadline: "Varies",
    eligibility: "Academic excellence",
    description: "Various scholarships offered by Swedish universities",
    amount: "25-100% tuition waiver",
  },
  
  // New Zealand Scholarships
  {
    name: "New Zealand Excellence Awards",
    country: "New Zealand",
    countrySlug: "newzealand",
    level: "Undergraduate, Masters",
    coverage: "Partial funding",
    deadline: "Varies",
    eligibility: "Indian students for selected universities",
    description: "Scholarships for Indian students at New Zealand universities",
    amount: "Up to NZD 10,000",
  },
  {
    name: "Commonwealth Scholarship (NZ)",
    country: "New Zealand",
    countrySlug: "newzealand",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "March",
    eligibility: "Citizens of Commonwealth countries",
    description: "Full scholarships for postgraduate study in New Zealand",
    amount: "Full tuition + living allowance + travel + establishment grant",
  },
  
  // Australia Scholarships
  {
    name: "Australia Awards",
    country: "Australia",
    countrySlug: "australia",
    level: "Masters, PhD",
    coverage: "Full funding",
    deadline: "April-May",
    eligibility: "Students from selected countries including India",
    description: "Australian government scholarships for development-focused study",
    amount: "Full tuition + living expenses + travel + OSHC",
  },
  {
    name: "Destination Australia",
    country: "Australia",
    countrySlug: "australia",
    level: "Undergraduate, Masters, PhD",
    coverage: "Partial funding",
    deadline: "Varies",
    eligibility: "International students studying in regional Australia",
    description: "Scholarships to attract students to regional areas",
    amount: "Up to AUD 15,000 per year",
  },
  
  // Austria Scholarships
  {
    name: "OeAD Scholarship",
    country: "Austria",
    countrySlug: "austria",
    level: "Masters, PhD, Research",
    coverage: "Full funding",
    deadline: "March",
    eligibility: "International students from selected countries",
    description: "Austrian Agency for International Cooperation in Education",
    amount: "€1,050/month + accommodation + insurance",
  },
  
  // Belgium Scholarships
  {
    name: "VLIR-UOS Scholarship",
    country: "Belgium",
    countrySlug: "belgium",
    level: "Masters",
    coverage: "Full funding",
    deadline: "February",
    eligibility: "Students from selected countries in Asia, Africa, Latin America",
    description: "Scholarships for development-related master's programs",
    amount: "Full tuition + €1,150/month + travel + insurance",
  },
  
  // Finland Scholarships
  {
    name: "Finland Scholarship",
    country: "Finland",
    countrySlug: "finland",
    level: "Masters",
    coverage: "Partial funding",
    deadline: "January",
    eligibility: "Non-EU/EEA students for first year master's",
    description: "Scholarship for international master's students",
    amount: "€5,000 + first year tuition waiver",
  },
  
  // Norway Scholarships
  {
    name: "Quota Scheme (Alternatives)",
    country: "Norway",
    countrySlug: "norway",
    level: "Masters, PhD",
    coverage: "Varies",
    deadline: "Varies",
    eligibility: "Check university-specific options",
    description: "Various university-specific scholarships available",
    amount: "Varies by program",
  },
  
  // Portugal Scholarships
  {
    name: "Santander Universities Scholarship",
    country: "Portugal",
    countrySlug: "portugal",
    level: "Undergraduate, Masters",
    coverage: "Partial funding",
    deadline: "Varies",
    eligibility: "International students at partner universities",
    description: "Scholarships funded by Santander Bank",
    amount: "€3,000 - €5,000",
  },
];

const tips = [
  {
    title: "Start Early",
    description: "Begin your scholarship search 12-18 months before your intended start date. Many scholarships have early deadlines.",
    icon: Calendar,
  },
  {
    title: "Maintain Excellence",
    description: "Most scholarships require strong academic records. Keep your grades up and aim for top performance.",
    icon: Star,
  },
  {
    title: "Build Your Profile",
    description: "Participate in extracurriculars, volunteer work, and leadership activities to strengthen your application.",
    icon: Award,
  },
  {
    title: "Research Thoroughly",
    description: "Look beyond popular scholarships. Many universities offer their own funding opportunities.",
    icon: Globe,
  },
];

export function ScholarshipsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCountry, setSelectedCountry] = useState<string>("");

  const filteredScholarships = scholarships.filter((scholarship) => {
    const matchesSearch = 
      scholarship.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scholarship.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scholarship.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCountry = !selectedCountry || scholarship.countrySlug === selectedCountry;
    return matchesSearch && matchesCountry;
  });

  const countries = [...new Set(scholarships.map(s => s.countrySlug))];

  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Scholarships for Indian Students | Kingsley International"
        description="Discover scholarships for studying abroad. Chevening, DAAD, Eiffel, Holland Scholarship and more. Get expert guidance on scholarship applications."
      />
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Scholarships & Funding
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Discover scholarship opportunities to fund your study abroad dream.
            We help you identify and apply for scholarships that match your profile.
          </p>
        </div>
      </div>

      <main className="container-custom py-12">
        {/* Search and Filter */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search scholarships by name, country, or description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C6A052]"
            >
              <option value="">All Countries</option>
              {countries.map((country) => (
                <option key={country} value={country}>
                  {getCountryFlag(country)} {country.charAt(0).toUpperCase() + country.slice(1)}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Results Count */}
        <p className="text-gray-600 mb-6">
          Showing <span className="font-semibold text-[#0B1F3B]">{filteredScholarships.length}</span> scholarships
        </p>

        {/* Scholarships Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredScholarships.map((scholarship, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-center gap-2 mb-3">
                <Badge className="bg-[#C6A052] text-[#0B1F3B]">
                  {getCountryFlag(scholarship.countrySlug)} {scholarship.country}
                </Badge>
                <Badge variant="outline">{scholarship.level}</Badge>
              </div>
              <h3 className="font-playfair text-lg font-semibold text-[#0B1F3B] mb-2">
                {scholarship.name}
              </h3>
              <p className="text-gray-600 text-sm mb-4">{scholarship.description}</p>
              
              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-[#C6A052]" />
                  <span className="text-gray-600">{scholarship.amount}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#C6A052]" />
                  <span className="text-gray-600">Deadline: {scholarship.deadline}</span>
                </div>
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-[#C6A052]" />
                  <span className="text-gray-600">{scholarship.eligibility}</span>
                </div>
              </div>

              <Link to="/contact">
                <Button 
                  variant="outline" 
                  className="w-full border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]"
                >
                  Get Application Help
                </Button>
              </Link>
            </div>
          ))}
        </div>

        {/* Tips Section */}
        <section className="mb-16">
          <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
            Tips for Scholarship Success
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tips.map((tip, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="w-12 h-12 bg-[#C6A052]/10 rounded-lg flex items-center justify-center mb-4">
                  <tip.icon className="w-6 h-6 text-[#C6A052]" />
                </div>
                <h3 className="font-semibold text-[#0B1F3B] mb-2">{tip.title}</h3>
                <p className="text-gray-600 text-sm">{tip.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Types of Scholarships */}
        <section className="mb-16">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-6">
              Types of Scholarships Available
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-[#0B1F3B] mb-3">
                  <Award className="w-5 h-5 inline mr-2 text-[#C6A052]" />
                  Merit-Based Scholarships
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Awarded based on academic excellence, test scores, and overall achievements. 
                  These recognize outstanding students.
                </p>
                <ul className="space-y-2">
                  {[
                    "Academic achievement scholarships",
                    "Leadership scholarships",
                    "Sports scholarships",
                    "Artistic talent scholarships",
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-[#C6A052]" />
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-[#0B1F3B] mb-3">
                  <DollarSign className="w-5 h-5 inline mr-2 text-[#C6A052]" />
                  Need-Based Scholarships
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Awarded based on financial need. These help make education 
                  accessible to deserving students from all backgrounds.
                </p>
                <ul className="space-y-2">
                  {[
                    "Income-based grants",
                    "Country-specific aid",
                    "Diversity scholarships",
                    "Emergency funding",
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-[#C6A052]" />
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-[#C6A052] rounded-xl p-8 md:p-12 text-center">
          <h2 className="font-playfair text-2xl md:text-3xl font-semibold text-[#0B1F3B] mb-4">
            Need Help with Scholarship Applications?
          </h2>
          <p className="text-[#0B1F3B]/70 max-w-2xl mx-auto mb-6">
            Our scholarship experts can help you identify the right opportunities and 
            craft compelling applications to maximize your chances of success.
          </p>
          <Link to="/contact">
            <Button className="bg-[#0B1F3B] text-white hover:bg-[#1a3a5f]">
              Get Scholarship Guidance
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </section>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
