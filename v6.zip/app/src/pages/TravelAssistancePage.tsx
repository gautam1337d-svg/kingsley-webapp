import { Link } from "react-router-dom";
import {
  Plane,
  Luggage,
  Calendar,
  Shield,
  MapPin,
  CheckCircle,
  ArrowRight,
  Phone,
  Clock,
  Info,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SEO } from "@/components/SEO";

const travelServices = [
  {
    icon: Plane,
    title: "Flight Booking Guidance",
    description: "Expert advice on booking the best flights with student discounts and flexible cancellation policies.",
    features: [
      "Compare prices across multiple airlines",
      "Student fare identification",
      "Multi-city itinerary planning",
      "Group booking coordination"
    ]
  },
  {
    icon: Luggage,
    title: "Student Baggage Benefits",
    description: "Maximize your baggage allowance with airline-specific student perks and excess baggage solutions.",
    features: [
      "Extra baggage allowance (up to 40kg)",
      "Sports equipment provisions",
      "Carry-on optimization tips",
      "Excess baggage pre-booking"
    ]
  },
  {
    icon: Calendar,
    title: "Best Time to Book",
    description: "Strategic booking advice to get the best prices and avoid last-minute price surges.",
    features: [
      "Optimal booking windows (2-3 months ahead)",
      "Off-peak travel recommendations",
      "Price alert setup assistance",
      "Seasonal pricing insights"
    ]
  },
  {
    icon: Shield,
    title: "Travel Insurance",
    description: "Comprehensive travel insurance guidance covering medical, baggage, and trip cancellation.",
    features: [
      "Medical emergency coverage",
      "Trip cancellation protection",
      "Baggage loss/delay coverage",
      "COVID-19 travel coverage"
    ]
  },
  {
    icon: MapPin,
    title: "Airport Pickup Coordination",
    description: "Hassle-free arrival with pre-arranged airport transfers and welcome services.",
    features: [
      "University pickup services",
      "Private transfer booking",
      "Shared shuttle coordination",
      "24/7 arrival support hotline"
    ]
  },
  {
    icon: Phone,
    title: "24/7 Travel Support",
    description: "Round-the-clock assistance for any travel emergencies or last-minute changes.",
    features: [
      "Emergency rebooking assistance",
      "Flight delay/cancellation support",
      "Lost passport guidance",
      "Real-time travel updates"
    ]
  }
];

const bookingTips = [
  {
    title: "Book Early",
    description: "International student fares are typically released 6-11 months in advance. Book 2-3 months before departure for best prices."
  },
  {
    title: "Be Flexible",
    description: "Mid-week departures (Tuesday-Thursday) are often cheaper than weekend flights. Consider nearby airports for better deals."
  },
  {
    title: "Check Student Fares",
    description: "Many airlines offer special student fares with extra baggage and flexible changes. Always verify student status requirements."
  },
  {
    title: "Consider Stopovers",
    description: "Direct flights are convenient but expensive. A single stopover can save 20-40% on ticket prices."
  },
  {
    title: "Read the Fine Print",
    description: "Check cancellation policies, change fees, and refund terms before booking. Student fares often have different conditions."
  }
];

export function TravelAssistancePage() {
  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <SEO 
        title="Travel Assistance for Indian Students | Kingsley International"
        description="Expert travel assistance for students studying abroad. Flight booking, baggage benefits, travel insurance, and 24/7 support."
      />
      <Header />

      {/* Hero Section */}
      <section className="pt-28 pb-16 bg-gradient-to-br from-[#0B1F3B] via-[#1a3a5c] to-[#0B1F3B]">
        <div className="container-custom">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C6A052]/20 rounded-full mb-6">
              <Plane className="w-4 h-4 text-[#C6A052]" />
              <span className="text-[#C6A052] text-sm font-medium">Travel Services</span>
            </div>
            <h1 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
              Travel Assistance for
              <span className="text-[#C6A052]"> Indian Students</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              From flight bookings to airport pickups, we handle every aspect of your journey abroad. 
              Travel smart with student discounts, extra baggage, and 24/7 support.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact">
                <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                  Get Travel Quote
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a href="tel:+919999999999">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                  <Phone className="w-5 h-5 mr-2" />
                  Call Us Now
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-12">
            <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
              Our Services
            </span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3">
              Complete Travel Solutions
            </h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Everything you need for a smooth journey from India to your study destination
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {travelServices.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-card">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-[#C6A052]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#C6A052] transition-colors">
                    <service.icon className="w-7 h-7 text-[#C6A052] group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="font-playfair text-xl font-semibold text-[#0B1F3B] mb-3">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-[#C6A052] mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Tips Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-[#C6A052] font-semibold text-sm uppercase tracking-wider">
                Expert Tips
              </span>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-[#0B1F3B] mt-3 mb-6">
                Smart Booking Strategies
              </h2>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Save money and avoid stress with these proven tips from our travel experts 
                who have helped thousands of Indian students reach their destinations.
              </p>

              <div className="space-y-4">
                {bookingTips.map((tip, index) => (
                  <div key={index} className="flex gap-4 p-4 bg-[#F5F3EE] rounded-xl">
                    <div className="w-8 h-8 bg-[#C6A052] text-white rounded-full flex items-center justify-center flex-shrink-0 font-semibold">
                      {index + 1}
                    </div>
                    <div>
                      <h4 className="font-semibold text-[#0B1F3B] mb-1">{tip.title}</h4>
                      <p className="text-sm text-gray-600">{tip.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#0B1F3B] to-[#1a3a5c] rounded-2xl p-8 text-white">
              <Info className="w-10 h-10 text-[#C6A052] mb-4" />
              <h3 className="font-playfair text-2xl font-bold mb-4">
                Did You Know?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                  <p className="text-gray-300">
                    Students can get up to <strong className="text-white">40kg baggage allowance</strong> with select airlines
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                  <p className="text-gray-300">
                    Booking 2-3 months in advance can save you <strong className="text-white">20-30%</strong> on airfare
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                  <p className="text-gray-300">
                    Many airlines offer <strong className="text-white">free date changes</strong> for student tickets
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#C6A052] mt-0.5 flex-shrink-0" />
                  <p className="text-gray-300">
                    Group bookings (5+ students) can get <strong className="text-white">additional discounts</strong>
                  </p>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-white/20">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[#C6A052]" />
                  <span className="text-sm text-gray-300">
                    Average response time: <strong className="text-white">Under 2 hours</strong>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-[#0B1F3B]">
        <div className="container-custom text-center">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Book Your Flight?
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Let our travel experts find the best deals for your journey. Get personalized 
            assistance with bookings, baggage, and everything in between.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A] font-semibold px-8 py-6 text-lg">
                Request Travel Quote
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
