import { useParams, Link } from "react-router-dom";
import { ArrowLeft, CheckCircle, Phone, ArrowRight } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { MobileBottomCTA } from "@/components/layout/MobileBottomCTA";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const servicesData: Record<
  string,
  {
    title: string;
    subtitle: string;
    description: string;
    features: string[];
    process: { step: number; title: string; description: string }[];
    faq: { question: string; answer: string }[];
  }
> = {
  "career-counselling": {
    title: "Career Counselling",
    subtitle: "Discover Your Path to Success",
    description:
      "Our expert career counsellors help you identify your strengths, explore career options, and create a roadmap for your professional journey. We provide personalized guidance based on your academic background, interests, and career aspirations.",
    features: [
      "One-on-one counselling sessions with certified experts",
      "Psychometric tests and career assessments",
      "Industry insights and job market analysis",
      "Skill gap identification and development plans",
      "Long-term career roadmap creation",
      "Regular progress reviews and adjustments",
    ],
    process: [
      {
        step: 1,
        title: "Initial Assessment",
        description:
          "We evaluate your academic background, interests, and career goals through detailed discussions and assessments.",
      },
      {
        step: 2,
        title: "Career Exploration",
        description:
          "Explore various career paths and industries that align with your profile and aspirations.",
      },
      {
        step: 3,
        title: "Roadmap Creation",
        description:
          "Develop a personalized action plan with clear milestones and achievable goals.",
      },
      {
        step: 4,
        title: "Ongoing Support",
        description:
          "Regular follow-ups and guidance as you progress towards your career objectives.",
      },
    ],
    faq: [
      {
        question: "How long does a career counselling session last?",
        answer:
          "Initial sessions typically last 60-90 minutes. Follow-up sessions are usually 45-60 minutes depending on your needs.",
      },
      {
        question: "Is career counselling only for students?",
        answer:
          "No, we provide career guidance for students, working professionals looking for a change, and anyone seeking clarity about their career path.",
      },
      {
        question: "What psychometric tests do you use?",
        answer:
          "We use internationally recognized assessments including personality tests, aptitude tests, and interest inventories.",
      },
    ],
  },
  "course-selection": {
    title: "Course Selection",
    subtitle: "Find Your Perfect Program",
    description:
      "Choosing the right course is crucial for your academic and career success. Our experts analyze your profile, interests, and goals to recommend programs that offer the best fit and future prospects.",
    features: [
      "Comprehensive profile evaluation",
      "University and course shortlisting",
      "Entry requirements analysis",
      "Scholarship opportunity identification",
      "Career outcome assessment",
      "Alternative pathway suggestions",
    ],
    process: [
      {
        step: 1,
        title: "Profile Analysis",
        description:
          "We review your academic records, test scores, and extracurricular activities.",
      },
      {
        step: 2,
        title: "Requirement Matching",
        description:
          "Identify programs that match your qualifications and aspirations.",
      },
      {
        step: 3,
        title: "Shortlisting",
        description:
          "Create a balanced list of ambitious, target, and safe universities.",
      },
      {
        step: 4,
        title: "Final Selection",
        description:
          "Help you make an informed decision based on all factors.",
      },
    ],
    faq: [
      {
        question: "How many universities should I apply to?",
        answer:
          "We typically recommend 6-8 universities: 2-3 ambitious, 3-4 target, and 1-2 safe options.",
      },
      {
        question: "Can you help with course changes after admission?",
        answer:
          "Yes, we provide guidance on course transfers and changes within the same university if needed.",
      },
      {
        question: "Do you consider scholarship availability?",
        answer:
          "Absolutely! Scholarship opportunities are an important factor in our recommendations.",
      },
    ],
  },
  "application-assistance": {
    title: "Application Assistance",
    subtitle: "Expert Support for Your Applications",
    description:
      "Our team provides comprehensive support throughout the application process, ensuring your applications are complete, compelling, and submitted on time.",
    features: [
      "Document checklist and verification",
      "Statement of Purpose (SOP) writing support",
      "Letter of Recommendation (LOR) guidance",
      "Resume/CV optimization",
      "Application form review",
      "Deadline tracking and submission",
    ],
    process: [
      {
        step: 1,
        title: "Document Collection",
        description: "We help you gather all required documents and transcripts.",
      },
      {
        step: 2,
        title: "SOP & LOR Support",
        description:
          "Craft compelling statements and guide your referees effectively.",
      },
      {
        step: 3,
        title: "Application Review",
        description:
          "Thorough review of all application materials before submission.",
      },
      {
        step: 4,
        title: "Submission & Follow-up",
        description: "Submit applications and track their progress.",
      },
    ],
    faq: [
      {
        question: "How long does the application process take?",
        answer:
          "Typically 4-8 weeks from document collection to submission, depending on the number of applications.",
      },
      {
        question: "Do you write the SOP for me?",
        answer:
          "We provide guidance, review, and editing support. The content should be your own for authenticity.",
      },
      {
        question: "What if I miss a deadline?",
        answer:
          "We maintain a deadline calendar and send reminders. If missed, we explore alternative options or next intake dates.",
      },
    ],
  },
  "visa-assistance": {
    title: "Visa Assistance",
    subtitle: "Navigate Visa Requirements with Confidence",
    description:
      "Our visa experts guide you through the entire visa application process, from documentation to interview preparation, maximizing your chances of approval.",
    features: [
      "Visa category identification",
      "Document preparation and verification",
      "Financial documentation guidance",
      "Visa application form assistance",
      "Interview preparation and mock sessions",
      "Post-visa arrival guidance",
    ],
    process: [
      {
        step: 1,
        title: "Visa Assessment",
        description:
          "Determine the appropriate visa category based on your program and circumstances.",
      },
      {
        step: 2,
        title: "Documentation",
        description:
          "Prepare all required documents including financial proofs and academic records.",
      },
      {
        step: 3,
        title: "Application Filing",
        description: "Complete and submit the visa application accurately.",
      },
      {
        step: 4,
        title: "Interview Prep",
        description:
          "Mock interviews and guidance for the visa interview process.",
      },
    ],
    faq: [
      {
        question: "What is the visa success rate?",
        answer:
          "Our students have a 98% visa success rate due to thorough preparation and documentation.",
      },
      {
        question: "How early should I apply for a visa?",
        answer:
          "We recommend applying 3-4 months before your program start date to allow sufficient processing time.",
      },
      {
        question: "What if my visa is rejected?",
        answer:
          "We analyze the rejection reason, address any issues, and help you reapply with a stronger application.",
      },
    ],
  },
  "scholarship-guidance": {
    title: "Scholarship Guidance",
    subtitle: "Maximize Your Funding Opportunities",
    description:
      "We help you identify and apply for scholarships that match your profile, reducing the financial burden of studying abroad.",
    features: [
      "Scholarship database access",
      "Eligibility assessment",
      "Application strategy development",
      "Essay and application support",
      "Deadline management",
      "Alternative funding options",
    ],
    process: [
      {
        step: 1,
        title: "Profile Evaluation",
        description:
          "Assess your academic achievements and extracurricular activities.",
      },
      {
        step: 2,
        title: "Scholarship Search",
        description: "Identify scholarships that match your profile and needs.",
      },
      {
        step: 3,
        title: "Application Support",
        description:
          "Help prepare compelling scholarship applications and essays.",
      },
      {
        step: 4,
        title: "Follow-up",
        description: "Track applications and assist with any additional requirements.",
      },
    ],
    faq: [
      {
        question: "What types of scholarships are available?",
        answer:
          "Merit-based, need-based, country-specific, subject-specific, and university-specific scholarships.",
      },
      {
        question: "When should I start looking for scholarships?",
        answer:
          "Ideally 12-18 months before your intended start date, as many have early deadlines.",
      },
      {
        question: "Can I apply for multiple scholarships?",
        answer:
          "Yes, you can and should apply for multiple scholarships to maximize your chances.",
      },
    ],
  },
  "education-loans": {
    title: "Education Loans",
    subtitle: "Finance Your Dream Education",
    description:
      "We guide you through the education loan process, helping you secure the best financing options from banks and financial institutions.",
    features: [
      "Loan eligibility assessment",
      "Bank comparison and selection",
      "Documentation support",
      "Application assistance",
      "Interest rate negotiation guidance",
      "Collateral-free loan options",
    ],
    process: [
      {
        step: 1,
        title: "Financial Assessment",
        description: "Evaluate your funding requirements and repayment capacity.",
      },
      {
        step: 2,
        title: "Bank Selection",
        description: "Compare loan options from multiple banks and NBFCs.",
      },
      {
        step: 3,
        title: "Documentation",
        description: "Prepare all required financial and academic documents.",
      },
      {
        step: 4,
        title: "Application & Disbursement",
        description: "Submit applications and follow up for timely disbursement.",
      },
    ],
    faq: [
      {
        question: "What is the typical interest rate for education loans?",
        answer:
          "Interest rates typically range from 8% to 14% depending on the bank, loan amount, and collateral.",
      },
      {
        question: "Can I get a loan without collateral?",
        answer:
          "Yes, many banks offer unsecured education loans up to certain amounts, especially for premier institutions.",
      },
      {
        question: "When do I start repaying the loan?",
        answer:
          "Most education loans have a moratorium period covering the course duration plus 6-12 months.",
      },
    ],
  },
};

export function ServicePage() {
  const { slug } = useParams<{ slug: string }>();
  const service = slug ? servicesData[slug] : null;

  if (!service) {
    return (
      <div className="min-h-screen bg-cream">
        <Header />
        <div className="pt-32 text-center">
          <h1 className="text-2xl font-bold text-navy mb-4">Service Not Found</h1>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream">
      <Header />

      {/* Hero */}
      <div className="pt-28 pb-12 bg-navy">
        <div className="container-custom">
          <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-gold mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-2">
            {service.title}
          </h1>
          <p className="text-gold text-lg">{service.subtitle}</p>
        </div>
      </div>

      <main className="container-custom py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <section className="bg-white rounded-xl p-8 shadow-card">
              <h2 className="font-playfair text-2xl font-semibold text-navy mb-4">
                About This Service
              </h2>
              <p className="text-gray-600 leading-relaxed">
                {service.description}
              </p>
            </section>

            {/* Features */}
            <section className="bg-white rounded-xl p-8 shadow-card">
              <h2 className="font-playfair text-2xl font-semibold text-navy mb-6">
                What We Offer
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {service.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600">{feature}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Process */}
            <section className="bg-white rounded-xl p-8 shadow-card">
              <h2 className="font-playfair text-2xl font-semibold text-navy mb-6">
                Our Process
              </h2>
              <div className="space-y-6">
                {service.process.map((step) => (
                  <div key={step.step} className="flex gap-4">
                    <div className="w-10 h-10 bg-gold text-navy rounded-full flex items-center justify-center font-bold flex-shrink-0">
                      {step.step}
                    </div>
                    <div>
                      <h3 className="font-semibold text-navy mb-1">
                        {step.title}
                      </h3>
                      <p className="text-gray-600 text-sm">
                        {step.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* FAQ */}
            <section className="bg-white rounded-xl p-8 shadow-card">
              <h2 className="font-playfair text-2xl font-semibold text-navy mb-6">
                Frequently Asked Questions
              </h2>
              <Accordion type="single" collapsible className="w-full">
                {service.faq.map((item, idx) => (
                  <AccordionItem key={idx} value={`item-${idx}`}>
                    <AccordionTrigger className="text-left text-navy">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* CTA */}
            <div className="bg-gold rounded-xl p-6 text-navy">
              <h3 className="font-playfair text-lg font-semibold mb-2">
                Get Started Today
              </h3>
              <p className="text-sm mb-4">
                Book a free consultation to learn more about our {service.title}{" "}
                service.
              </p>
              <Link to="/contact">
                <Button className="w-full bg-navy text-white hover:bg-navy-light mb-3">
                  Book Free Consultation
                </Button>
              </Link>
              <a
                href="tel:+919876543210"
                className="flex items-center justify-center gap-2 text-sm font-medium"
              >
                <Phone className="w-4 h-4" />
                +91 98765 43210
              </a>
            </div>

            {/* Other Services */}
            <div className="bg-white rounded-xl p-6 shadow-card">
              <h3 className="font-playfair text-lg font-semibold text-navy mb-4">
                Other Services
              </h3>
              <div className="space-y-2">
                {Object.entries(servicesData)
                  .filter(([key]) => key !== slug)
                  .slice(0, 4)
                  .map(([key, svc]) => (
                    <Link
                      key={key}
                      to={`/services/${key}`}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-cream transition-colors"
                    >
                      <span className="text-sm text-gray-600">{svc.title}</span>
                      <ArrowRight className="w-4 h-4 text-gold" />
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="pb-20 md:pb-0">
        <Footer />
      </div>
      <WhatsAppButton />
      <MobileBottomCTA />
    </div>
  );
}
