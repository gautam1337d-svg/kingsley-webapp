export interface University {
  id: string;
  name: string;
  country: string;
  countryDisplay: string;
  city: string;
  studyLevels: string;
  type: string;
  popularity: string;
  whySelected: string;
  costBand: string;
  visaRiskNotes: string;
  operationalConfidence: string;
  sourceUrl: string;
  lastChecked: string;
  confidence: string;
}

export interface Program {
  id: string;
  country: string;
  countryDisplay: string;
  studyLevel: string;
  universityName: string;
  universityId: string;
  programName: string;
  courseArea: string;
  intakeMonths: string;
  durationMonths: string | number;
  tuitionPerYear: string | number;
  tuitionCurrency: string;
  englishRequirement: string;
  academicRequirement: string;
  typicalIndianProfile: string;
  visaSafetyNotes: string;
  suitabilityTags: string;
  operationalConfidence: string;
  sourceUrl: string;
  lastChecked: string;
  confidence: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  tags: string[];
  imageUrl?: string;
  readTime?: string;
}

export interface SuccessStory {
  id: string;
  name: string;
  photoUrl?: string;
  university: string;
  country: string;
  course: string;
  year: string;
  quote: string;
  fullStory: string;
  results: string;
}

export interface CourseFilters {
  country?: string;
  studyLevel?: string;
  courseArea?: string;
  budgetRange?: string;
  intake?: string;
}

export interface CountryInfo {
  slug: string;
  name: string;
  flag: string;
  description: string;
  whyStudy: string[];
  quickFacts: {
    label: string;
    value: string;
  }[];
  admissionRequirements: {
    level: string;
    requirements: string[];
  }[];
  costOfLiving: {
    category: string;
    range: string;
  }[];
  visaInfo: {
    title: string;
    content: string;
  }[];
  topUniversities: string[];
  popularCourses: string[];
}

export interface ServiceInfo {
  slug: string;
  title: string;
  subtitle: string;
  description: string;
  features: string[];
  process: {
    step: number;
    title: string;
    description: string;
  }[];
  faq: {
    question: string;
    answer: string;
  }[];
}
