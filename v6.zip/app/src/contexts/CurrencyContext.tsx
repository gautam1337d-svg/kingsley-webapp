import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";

interface ExchangeRates {
  [currency: string]: number; // Rate to convert 1 unit of currency to INR
}

interface CurrencyContextType {
  rates: ExchangeRates;
  loading: boolean;
  error: string | null;
  convertToINR: (amount: number, currency: string) => number | null;
  formatINR: (amount: number | null) => string;
  isReady: boolean;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

// Fallback rates (hardcoded conservative estimates)
const FALLBACK_RATES: ExchangeRates = {
  GBP: 105,    // British Pound
  EUR: 90,     // Euro
  USD: 83,     // US Dollar
  AUD: 55,     // Australian Dollar
  NZD: 50,     // New Zealand Dollar
  CAD: 61,     // Canadian Dollar
  NOK: 7.5,    // Norwegian Krone
  SEK: 7.8,    // Swedish Krona
  DKK: 12,     // Danish Krone
  CHF: 95,     // Swiss Franc
  HUF: 0.23,   // Hungarian Forint
  PLN: 21,     // Polish Zloty
  CZK: 3.6,    // Czech Koruna
  SGD: 62,     // Singapore Dollar
  JPY: 0.56,   // Japanese Yen
  INR: 1,      // Indian Rupee (base)
};

const CACHE_KEY = "kingsley_exchange_rates";
const CACHE_TIMESTAMP_KEY = "kingsley_exchange_rates_timestamp";
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

// Currency symbols mapping
const CURRENCY_SYMBOLS: Record<string, string> = {
  GBP: "£",
  EUR: "€",
  USD: "$",
  AUD: "A$",
  NZD: "NZ$",
  CAD: "C$",
  NOK: "kr",
  SEK: "kr",
  DKK: "kr",
  CHF: "CHF",
  HUF: "Ft",
  PLN: "zł",
  CZK: "Kč",
  SGD: "S$",
  JPY: "¥",
  INR: "₹",
};

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [rates, setRates] = useState<ExchangeRates>(FALLBACK_RATES);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);

  // Fetch exchange rates from API
  useEffect(() => {
    async function fetchRates() {
      try {
        // Check cache first
        const cachedRates = localStorage.getItem(CACHE_KEY);
        const cachedTimestamp = localStorage.getItem(CACHE_TIMESTAMP_KEY);
        
        if (cachedRates && cachedTimestamp) {
          const timestamp = parseInt(cachedTimestamp, 10);
          const now = Date.now();
          
          // Use cache if it's less than 24 hours old
          if (now - timestamp < CACHE_DURATION) {
            setRates(JSON.parse(cachedRates));
            setLoading(false);
            setIsReady(true);
            return;
          }
        }

        // Fetch from exchangerate.host API (free, no API key needed)
        const response = await fetch(
          "https://api.exchangerate.host/latest?base=INR&symbols=GBP,EUR,USD,AUD,NZD,CAD,NOK,SEK,DKK,CHF,HUF,PLN,CZK,SGD,JPY"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch exchange rates");
        }

        const data = await response.json();
        
        // API returns rates as "how many units of foreign currency per 1 INR"
        // We need to invert them to get "how many INR per 1 unit of foreign currency"
        const invertedRates: ExchangeRates = { INR: 1 };
        
        Object.entries(data.rates as Record<string, number>).forEach(([currency, rate]) => {
          if (rate > 0) {
            invertedRates[currency] = 1 / rate;
          }
        });

        // Merge with fallback rates for any missing currencies
        const mergedRates = { ...FALLBACK_RATES, ...invertedRates };
        
        // Save to cache
        localStorage.setItem(CACHE_KEY, JSON.stringify(mergedRates));
        localStorage.setItem(CACHE_TIMESTAMP_KEY, Date.now().toString());
        
        setRates(mergedRates);
        setError(null);
      } catch (err) {
        console.error("Exchange rate fetch error:", err);
        setError("Using fallback rates");
        // Keep using fallback rates
      } finally {
        setLoading(false);
        setIsReady(true);
      }
    }

    fetchRates();
  }, []);

  // Convert amount from foreign currency to INR
  const convertToINR = useCallback((amount: number, currency: string): number | null => {
    if (!amount || isNaN(amount)) return null;
    if (currency === "INR") return amount;
    
    const rate = rates[currency.toUpperCase()];
    if (!rate) return null;
    
    return Math.round(amount * rate);
  }, [rates]);

  // Format INR amount in lakhs
  const formatINR = useCallback((amount: number | null): string => {
    if (amount === null || isNaN(amount)) return "N/A";
    
    const lakhs = amount / 100000;
    
    if (lakhs >= 1) {
      return `₹${lakhs.toFixed(2)} Lakhs`;
    } else {
      return `₹${amount.toLocaleString("en-IN")}`;
    }
  }, []);

  return (
    <CurrencyContext.Provider
      value={{
        rates,
        loading,
        error,
        convertToINR,
        formatINR,
        isReady,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
}

export { CURRENCY_SYMBOLS, FALLBACK_RATES };
