import { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

// Lazy load pages for better performance
const HomePage = lazy(() => import("@/pages/HomePage").then(m => ({ default: m.HomePage })));
const FindYourCoursePage = lazy(() => import("@/pages/FindYourCoursePage").then(m => ({ default: m.FindYourCoursePage })));
const CountryPage = lazy(() => import("@/pages/CountryPage").then(m => ({ default: m.CountryPage })));
const UniversityPage = lazy(() => import("@/pages/UniversityPage").then(m => ({ default: m.UniversityPage })));
const ServicePage = lazy(() => import("@/pages/ServicePage").then(m => ({ default: m.ServicePage })));
const ContactPage = lazy(() => import("@/pages/ContactPage").then(m => ({ default: m.ContactPage })));
const AboutPage = lazy(() => import("@/pages/AboutPage").then(m => ({ default: m.AboutPage })));
const BlogPage = lazy(() => import("@/pages/BlogPage").then(m => ({ default: m.BlogPage })));
const ArticlePage = lazy(() => import("@/pages/ArticlePage").then(m => ({ default: m.ArticlePage })));
const SuccessStoriesPage = lazy(() => import("@/pages/SuccessStoriesPage").then(m => ({ default: m.SuccessStoriesPage })));
const VisaGuidancePage = lazy(() => import("@/pages/VisaGuidancePage").then(m => ({ default: m.VisaGuidancePage })));
const VisaPage = lazy(() => import("@/pages/VisaPage").then(m => ({ default: m.VisaPage })));
const ScholarshipsPage = lazy(() => import("@/pages/ScholarshipsPage").then(m => ({ default: m.ScholarshipsPage })));

// New Service Pages
const TravelAssistancePage = lazy(() => import("@/pages/TravelAssistancePage").then(m => ({ default: m.TravelAssistancePage })));
const ForexAssistancePage = lazy(() => import("@/pages/ForexAssistancePage").then(m => ({ default: m.ForexAssistancePage })));
const AccommodationSupportPage = lazy(() => import("@/pages/AccommodationSupportPage").then(m => ({ default: m.AccommodationSupportPage })));
const PreDepartureGuidancePage = lazy(() => import("@/pages/PreDepartureGuidancePage").then(m => ({ default: m.PreDepartureGuidancePage })));

// Loading fallback
function PageLoader() {
  return (
    <div className="min-h-screen bg-[#F5F3EE] flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin w-12 h-12 border-4 border-[#C6A052] border-t-transparent rounded-full mx-auto mb-4" />
        <p className="text-gray-600">Loading...</p>
      </div>
    </div>
  );
}

// 404 Page
function NotFoundPage() {
  return (
    <div className="min-h-screen bg-[#F5F3EE]">
      <Header />
      <div className="pt-32 pb-20 text-center">
        <h1 className="font-playfair text-6xl font-bold text-[#C6A052] mb-4">404</h1>
        <h2 className="font-playfair text-2xl font-semibold text-[#0B1F3B] mb-4">Page Not Found</h2>
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="flex gap-4 justify-center">
          <Link to="/">
            <Button className="bg-[#C6A052] text-[#0B1F3B] hover:bg-[#E5C27A]">
              Go Home
            </Button>
          </Link>
          <Link to="/find-your-course">
            <Button variant="outline" className="border-[#C6A052] text-[#C6A052] hover:bg-[#C6A052] hover:text-[#0B1F3B]">
              Browse Courses
            </Button>
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/find-your-course" element={<FindYourCoursePage />} />
          <Route path="/country/:slug" element={<CountryPage />} />
          <Route path="/university/:id" element={<UniversityPage />} />
          <Route path="/services/:slug" element={<ServicePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:slug" element={<ArticlePage />} />
          <Route path="/success-stories" element={<SuccessStoriesPage />} />
          <Route path="/visa-guidance" element={<VisaGuidancePage />} />
          <Route path="/visa/:countrySlug" element={<VisaPage />} />
          <Route path="/scholarships" element={<ScholarshipsPage />} />
          
          {/* New Service Pages */}
          <Route path="/travel-assistance" element={<TravelAssistancePage />} />
          <Route path="/forex-assistance" element={<ForexAssistancePage />} />
          <Route path="/accommodation-support" element={<AccommodationSupportPage />} />
          <Route path="/pre-departure-guidance" element={<PreDepartureGuidancePage />} />
          
          {/* Legacy redirects */}
          <Route path="/services" element={<HomePage />} />
          <Route path="/resources" element={<BlogPage />} />
          
          {/* 404 catch-all */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
