import xlsx from 'xlsx';
import fs from 'fs';
import path from 'path';

const uploadDir = '/mnt/okcomputer/upload';
const outputDir = './public/data';

const files = [
  { file: 'Aus University Info.xlsx', country: 'australia' },
  { file: 'Austria University Info.xlsx', country: 'austria' },
  { file: 'Belgium University Info.xlsx', country: 'belgium' },
  { file: 'DE University Info.xlsx', country: 'germany' },
  { file: 'Finland University Info.xlsx', country: 'finland' },
  { file: 'FR University Info.xlsx', country: 'france' },
  { file: 'Hungary University Info.xlsx', country: 'hungary' },
  { file: 'Ireland University Info.xlsx', country: 'ireland' },
  { file: 'Italy University Info.xlsx', country: 'italy' },
  { file: 'NL University Info.xlsx', country: 'netherlands' },
  { file: 'Norway University Info.xlsx', country: 'norway' },
  { file: 'NZ University Info.xlsx', country: 'newzealand' },
  { file: 'Portugal University Info.xlsx', country: 'portugal' },
  { file: 'Spain University Info.xlsx', country: 'spain' },
  { file: 'Sweden University Info.xlsx', country: 'sweden' },
  { file: 'UK University Info.xlsx', country: 'uk' },
];

const allUniversities = [];
const allPrograms = [];

files.forEach(({ file, country }) => {
  const filePath = path.join(uploadDir, file);
  
  if (!fs.existsSync(filePath)) {
    console.log(`Skipping ${file} - not found`);
    return;
  }

  console.log(`Processing ${file}...`);
  
  const workbook = xlsx.readFile(filePath);
  
  // Parse Universities
  const uniSheet = workbook.Sheets['Universities_Master'];
  if (uniSheet) {
    const universities = xlsx.utils.sheet_to_json(uniSheet);
    universities.forEach(uni => {
      allUniversities.push({
        id: slugify(uni.University_Name || ''),
        name: uni.University_Name || '',
        country: country,
        countryDisplay: uni.Country || '',
        city: uni.City || '',
        studyLevels: uni.Study_Level_Supported || '',
        type: uni['University_Type (Public / Private)'] || '',
        popularity: uni['Indian_Student_Popularity (High / Medium / Low)'] || '',
        whySelected: uni.Why_Selected || '',
        costBand: uni.Cost_Band || '',
        visaRiskNotes: uni.Visa_Risk_Notes || '',
        operationalConfidence: uni.Operational_Confidence || '',
        sourceUrl: uni.Source_URL || '',
        lastChecked: uni.Last_Checked_Date || '',
        confidence: uni.Confidence || ''
      });
    });
    console.log(`  - ${universities.length} universities`);
  }
  
  // Parse Programs
  const progSheet = workbook.Sheets['Programs_Master'];
  if (progSheet) {
    const programs = xlsx.utils.sheet_to_json(progSheet);
    programs.forEach(prog => {
      allPrograms.push({
        id: `${slugify(prog.University_Name || '')}-${slugify(prog.Program_Name || '')}`,
        country: country,
        countryDisplay: prog.Country || '',
        studyLevel: prog.Study_Level || '',
        universityName: prog.University_Name || '',
        universityId: slugify(prog.University_Name || ''),
        programName: prog.Program_Name || '',
        courseArea: prog.Course_Area || '',
        intakeMonths: prog.Intake_Months || '',
        durationMonths: prog.Duration_Months || '',
        tuitionPerYear: prog.Tuition_Per_Year || '',
        tuitionCurrency: prog.Tuition_Currency || '',
        englishRequirement: prog.English_Requirement_Summary || '',
        academicRequirement: prog.Academic_Requirement_Summary || '',
        typicalIndianProfile: prog.Typical_Indian_Profile || '',
        visaSafetyNotes: prog.Visa_Safety_Notes || '',
        suitabilityTags: prog.Suitability_Tags || '',
        operationalConfidence: prog.Operational_Confidence || '',
        sourceUrl: prog.Source_URL || '',
        lastChecked: prog.Last_Checked_Date || '',
        confidence: prog.Confidence || ''
      });
    });
    console.log(`  - ${programs.length} programs`);
  }
});

// Ensure output directory exists
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Write combined files
fs.writeFileSync(
  path.join(outputDir, 'universities.json'),
  JSON.stringify(allUniversities, null, 2)
);

fs.writeFileSync(
  path.join(outputDir, 'programs.json'),
  JSON.stringify(allPrograms, null, 2)
);

// Write individual country files
const countries = [...new Set(allUniversities.map(u => u.country))];
countries.forEach(country => {
  const countryUnis = allUniversities.filter(u => u.country === country);
  const countryProgs = allPrograms.filter(p => p.country === country);
  
  fs.writeFileSync(
    path.join(outputDir, `${country}-universities.json`),
    JSON.stringify(countryUnis, null, 2)
  );
  
  fs.writeFileSync(
    path.join(outputDir, `${country}-programs.json`),
    JSON.stringify(countryProgs, null, 2)
  );
});

console.log(`\n✅ Parsed ${allUniversities.length} universities and ${allPrograms.length} programs`);
console.log(`📁 Data saved to ${outputDir}`);

function slugify(str) {
  if (!str) return '';
  return str
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
